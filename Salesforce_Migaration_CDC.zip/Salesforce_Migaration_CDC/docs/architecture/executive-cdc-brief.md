# Executive CDC Architecture Brief

## Objective

This design creates a controlled Salesforce-to-Snowflake change-tracking layer that can be monitored and explained at business and technical levels. The goal is to identify what changed, when it changed, which object changed, and whether the change is a source-side Salesforce delta or a downstream Snowflake audit event.

---

## 1. Business context

Salesforce is the operational system of record. Business data changes continuously across accounts, contacts, opportunities, activities, and revenue objects. The project needs to:

- pull only the rows that changed
- preserve a reliable watermark for each object
- store the latest state in Snowflake
- allow downstream monitoring and reconciliation
- expose recent changes in a dashboard

This makes the solution both operationally efficient and audit-friendly.

---

## 2. Technical pattern

The repo already follows a standard incremental CDC model for Salesforce.

### Source-side pattern

1. Read the last successful watermark from `CONTROL_WATERMARK`.
2. Query Salesforce where `SystemModstamp > watermark`.
3. Load the changed rows into a Snowflake stage table.
4. Merge the stage data into the final table.
5. Update the watermark only after a successful load.

This is the correct approach for Salesforce, because the source is not a relational database with native row-level triggers that we can subscribe to in the same way as a SQL engine.

### Snowflake-side pattern

Once data is in Snowflake, the next layer is the downstream delta tracker:

- `CHANGE_TRACKING = TRUE`
- `STREAM` on the target table
- `TASK` to move stream rows into a `CDC_AUDIT` table
- Streamlit dashboard reads the `CDC_AUDIT` data

This creates a clean operational model: source delta first, then Snowflake delta visibility.

---

## 3. Why `SystemModstamp` is the core field

`SystemModstamp` is the right incremental field for Salesforce because it captures the last system-level change time for a record.

Benefits:

- reliable for incremental polling
- works across many objects
- suitable for watermark logic
- supports incremental loads that are significantly smaller than full-table reloads

Where software needs deletes, `IsDeleted` is used in the source-side query. For objects without `IsDeleted`, the delete pattern must be handled through a full diff or reconciliation step.

---

## 4. Recommended architecture

```mermaid
flowchart LR
    SF[Salesforce Objects] -->|SystemModstamp > watermark| PY[Python Orchestrator]
    PY --> STG[Snowflake STG_* tables]
    STG -->|MERGE| RAW[Snowflake RAW / target tables]
    RAW --> STREAM[Snowflake STREAM objects]
    STREAM --> TASK[Scheduled Snowflake TASK]
    TASK --> AUDIT[CDC_AUDIT table]
    AUDIT --> APP[Streamlit dashboard]
    PY --> WM[CONTROL_WATERMARK]
    WM --> APP
```

This gives a layered design:

- object-level source extraction
- target-table merge
- downstream audit/change capture
- explanation layer for ops and data teams

---

## 5. Data model for monitoring

A practical audit table should contain:

- `table_name`
- `change_type` (`INSERT`, `UPDATE`, `DELETE`)
- `record_id`
- `change_ts`
- `source_system`
- `payload`

This is enough to answer the operational questions:

- which table changed?
- what row changed?
- when did it change?
- was it an insert, update, or delete?
- what was the transformed payload?

---

## 6. Real STG_SF interpretation

The broader STG_SF analysis confirmed a key design fact: the Snowflake schema is a landing layer populated by SnapLogic, not by database-native CDC triggers. That means:

- the source ingestion is external to Snowflake
- the Snowflake `STREAM` layer is the right place for downstream auditing
- the repo’s incremental Python pattern remains valid as the source-side design
- the Snowflake tracking layer is a monitoring and reconciliation layer on top of the raw landing tables

In other words, the architecture is not "Salesforce trigger-based CDC" but "incremental pull + Snowflake change capture".

---

## 7. What tables to monitor

The repo already uses a standard pattern for `Account`, `Contact`, and `Opportunity`, and the broader schema extends that idea to many more tables.

Important examples:

- `ACCOUNT`
- `CONTACT`
- `OPPORTUNITY`
- `EVENT`
- `TASK`
- `LEAD`
- `USER`
- `PROPERTY__C`
- `BUDGET_TARGET__C`
- `OPPORTUNITY_TEAM_INSTALLMENTS__C`

The critical implementation rule is: monitor the source delta with `SystemModstamp`, and monitor the Snowflake delta with `STREAM`/`TASK`/audit logic.

---

## 8. Risks and exceptions

Certain tables require special handling:

- objects without `IsDeleted` need diff-based delete detection
- `UserRole` has no delete flag in the standard field set
- `OpportunityShare` does not carry the same creation metadata as the main objects
- `ACCOUNT1` is a mirror/snapshot and should not be treated as a separate business object

These are not blockers; they just require explicit handling in the metadata and monitoring model.

---

## 9. Implementation roadmap

1. Keep the current incremental Salesforce extraction logic.
2. Keep the Snowflake merge and watermark logic.
3. Add a `CDC_AUDIT` table and feed it with Snowflake `STREAM`s.
4. Build the Streamlit dashboard against that audit table.
5. Add new objects to metadata with the standard CDC field pattern.
6. Reconcile source counts against Snowflake row counts in a scheduled validation step.

---

## 10. Executive summary

This project is correctly designed for a modern Salesforce-to-Snowflake CDC pipeline. It uses the right source-side approach for Salesforce, stores the correct delta window metadata, and adds a Snowflake monitoring layer to answer change-tracking questions operationally.

The architecture is simple, scalable, and understandable: pull changed rows, merge them, capture Snowflake-side deltas, and visualize them.
