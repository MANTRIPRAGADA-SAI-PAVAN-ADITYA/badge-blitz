# Salesforce to Snowflake CDC Plan Summary

## 1. What the repo is already doing correctly

This repository is aligned with the correct incremental CDC pattern for Salesforce:

- source-side delta is driven by `SystemModstamp`
- soft deletes are handled through `IsDeleted`
- changed rows are staged into Snowflake staging tables
- final tables are updated using `MERGE`
- a control watermark table tracks the last processed timestamp

The core repo implementation is in:

- [app/metadata.py](../../app/metadata.py)
- [app/pipeline.py](../../app/pipeline.py)
- [app/orchestrator.py](../../app/orchestrator.py)
- [sql/snowflake_streams_tasks.sql](../../sql/snowflake_streams_tasks.sql)
- [config/settings.py](../../config/settings.py)

This matches the general Salesforce pattern: pull only changed records, not the full object every time.

---

## 2. Why `SystemModstamp` is the right field

`SystemModstamp` is the best choice for incremental loads because it reflects when Salesforce last changed a record, including changes that may not be visible in ordinary business timestamps.

It is the correct field for:

- incremental pull windows
- watermark tracking
- last successful extraction boundaries

The repo already makes this explicit in the orchestrator and metadata layers.

---

## 3. The real CDC pattern used here

### Source-based CDC

The Python pipeline pattern is:

1. read the last watermark from `CONTROL_WATERMARK`
2. query Salesforce where `SystemModstamp > watermark`
3. load changed data into a Snowflake stage table
4. merge into the target table
5. advance the watermark

This is the core architecture already implemented in the repo.

### Snowflake change capture

After rows arrive in Snowflake, the repo can optionally enable:

- `CHANGE_TRACKING`
- `STREAM`
- `TASK`
- downstream audit table

That part is already described in [sql/snowflake_streams_tasks.sql](../../sql/snowflake_streams_tasks.sql).

---

## 4. What is correct about the STG_SF analysis

The broader STG_SF findings are also consistent with the repo direction:

- the main source pattern is still incremental Salesforce extraction using `SystemModstamp`
- `IsDeleted` is needed for soft deletes
- Snowflake `STREAM` objects are the right way to detect downstream changes after rows land in Snowflake
- the `STG_SF` schema is a raw landing layer; the mapping logic is controlled externally by SnapLogic, not inside Snowflake itself

The strongest conclusion is:

- repo architecture = correct for Salesforce-to-Snowflake CDC
- STG_SF specific load = external ingestion layer, so Snowflake-native CDC is downstream capture, not source capture

---

## 5. Recommended target design

### Option A — current repo path (best default)

Use the repo’s existing approach:

- Salesforce object query with `SystemModstamp > watermark`
- stage rows in Snowflake
- merge into target table
- optional Snowflake `STREAM` on the target table for downstream change tracking

This is the clearest and safest design for this project.

### Option B — STG_SF / SnapLogic environment

If the environment already loads raw tables into `STG_SF` using SnapLogic, then add a second layer:

- create Snowflake `STREAM` objects on the staging tables
- record changes in a `CDC_AUDIT` table
- build Streamlit or BI dashboards on that audit table

This gives operational visibility without replacing the source ingestion logic.

---

## 6. Recommended tables and fields

The repo is already structured around these standard Salesforce CDC fields:

- `Id`
- `SystemModstamp`
- `IsDeleted`
- `LastModifiedDate`
- `CreatedDate`
- `CreatedById`
- `LastModifiedById`

For objects without `IsDeleted` (for example, `UserRole`), the design should skip the delete-query path and instead handle deletes by full ID diff or by a separate reconciliation process.

---

## 7. Final takeaway

The architecture is sound for a Salesforce-to-Snowflake CDC and change-tracking solution:

- source delta = `SystemModstamp`
- delete handling = `IsDeleted` when available
- Snowflake delta tracking = `STREAM` + `TASK` + audit table
- dashboard layer = Streamlit reading the `CDC_AUDIT` table

This is the right design for both the repo as written and the larger STG_SF schema that was analyzed.

---

## 8. Implementation roadmap

1. keep the current incremental extraction logic in the Python app
2. keep the staging / merge pattern for Salesforce objects
3. add `STREAM` objects on each Snowflake target table
4. populate a shared `CDC_AUDIT` table for monitoring
5. build the Streamlit dashboard on top of that audit table
6. extend the object metadata list when new Salesforce objects are added

---

## 9. Validation status

I checked the repo’s actual code and IDE state:

- [app/metadata.py](../../app/metadata.py) — no editor errors reported
- [app/pipeline.py](../../app/pipeline.py) — no editor errors reported
- [tests/test_metadata.py](../../tests/test_metadata.py) — no editor errors reported

The terminal test command was not executed because the session explicitly skipped running it, so I am not claiming a full pytest pass in this session.
