# STG_SF Schema Reference & CDC Field Mapping

## Overview

`STG_SF` is the Salesforce staging schema (CBRE commercial real estate org).
It holds 25 tables, all `TEXT` columns (no types applied — a raw staging
layer). This document consolidates the schema, its relationships, and what
each table needs to support CDC, replacing the illustrative 3-object example
used in [architecture-slide.md](architecture-slide.md) and
[cdc-streamlit-dashboard.md](cdc-streamlit-dashboard.md) with the real schema.

## How STG_SF is actually loaded

**No native Snowflake object (Stream, Task, Pipe, or stored procedure) loads
STG_SF.** The schema has two OAuth security integrations —
`SNAPLOGIC_OAUTH` (prod) and `DEV_SNAPLOGIC_OAUTH` (dev) — confirming that
**SnapLogic** (an iPaaS/ETL tool) pulls each Salesforce object and writes
rows into `STG_SF.<TABLE>` over JDBC using a Snowflake Snap, running under
roles `PROD_PACIFICDM_DB_STG_SF_FULL_ROLE` / `PROD_PACIFICDM_DB_STG_SF_RW_ROLE`.

Practical consequence:
- `STG_SF.<TABLE>` is already the **landing/target layer** — there is no
  separate `STG_`/`RAW_` split inside this schema the way the pipeline in
  this repo does it.
- The Salesforce-field → Snowflake-column mapping lives inside SnapLogic
  pipeline definitions, not in any queryable Snowflake object. It cannot be
  inspected from Snowflake — only from SnapLogic Designer.
- Because the mapping is opaque to Snowflake, **the only reliable CDC
  strategy here is downstream**: track changes that land in `STG_SF.*` using
  Snowflake `STREAM`s, rather than trying to intercept SnapLogic's load.

## Table inventory

| Table | Rows | Domain |
|---|---|---|
| `ACCOUNT` | 1.3M | Client companies |
| `ACCOUNT1` | 1.3M | Mirror/snapshot of `ACCOUNT` (not a distinct Salesforce object) |
| `ACCOUNTCONTACTRELATION` | 2.1M | Account ↔ Contact junction |
| `ACCOUNTTEAMMEMBER` | 43K | Account team assignments |
| `ACCOUNT_WITH_SPOCS__C` | 84K | Account ↔ SPOC junction |
| `BUDGET_TARGET__C` | 494K | Revenue targets per user |
| `CONTACT` | 1.9M | People/contacts |
| `CONTACT_RELATIONSHIP__C` | 525K | Contact-to-contact relationships |
| `EVENT` | 1.5M | Calendar events/meetings |
| `LEAD` | 1.3M | Leads (pre-conversion) |
| `OPPORTUNITY` | 1.6M | Deals/opportunities |
| `OPPORTUNITYSHARE` | 9.4M | Opportunity sharing rules |
| `OPPORTUNITYTEAMMEMBER` | 4.2M | Deal team members |
| `OPPORTUNITY_INSTALLMENTS__C` | 2.1M | Fee installments on deals |
| `OPPORTUNITY_TEAM_INSTALLMENTS__C` | 2.5M | Installments per team member |
| `PERMISSIONSET` | 657 | SF permission sets |
| `PERMISSIONSETGROUP` | 24 | SF permission set groups |
| `PROFILE` | 107 | SF user profiles |
| `PROPERTY__C` | 738K | Real estate properties |
| `RECORDTYPE` | 175 | Record type definitions |
| `SPOC__C` | 22K | Single Point of Contact records |
| `TASK` | 2.1M | Task activities |
| `TEAM_MEMBER_FUMO_SPLIT__C` | 4.4M | FUMO revenue splits |
| `USER` | 48K | Salesforce users |
| `USERROLE` | 2.4K | Role hierarchy |

## Relationship map

```mermaid
erDiagram
    USER ||--o{ USER : "ManagerId (self)"
    USER }o--|| USERROLE : "UserRoleId"
    USER }o--|| PROFILE : "ProfileId"
    USERROLE ||--o{ USERROLE : "ParentRoleId (self)"
    PERMISSIONSET }o--|| PROFILE : "ProfileId"
    PERMISSIONSET }o--|| PERMISSIONSETGROUP : "PermissionSetGroupId"

    ACCOUNT ||--o{ ACCOUNT : "ParentId (self)"
    ACCOUNT }o--|| USER : "OwnerId"
    ACCOUNT }o--|| RECORDTYPE : "RecordTypeId"

    CONTACT }o--|| ACCOUNT : "AccountId"
    CONTACT ||--o{ CONTACT : "ReportsToId (self)"
    CONTACT }o--|| USER : "OwnerId"

    ACCOUNTCONTACTRELATION }o--|| ACCOUNT : "AccountId"
    ACCOUNTCONTACTRELATION }o--|| CONTACT : "ContactId"
    ACCOUNTTEAMMEMBER }o--|| ACCOUNT : "AccountId"
    ACCOUNTTEAMMEMBER }o--|| USER : "UserId"

    SPOC__C }o--|| ACCOUNT : "Account__c"
    SPOC__C }o--|| USER : "OwnerId"
    SPOC__C }o--|| CONTACT : "EMEA_SPOC_Contact__c"
    ACCOUNT_WITH_SPOCS__C }o--|| ACCOUNT : "Account__c"
    ACCOUNT_WITH_SPOCS__C }o--|| SPOC__C : "SPOC__c"

    OPPORTUNITY }o--|| ACCOUNT : "AccountId"
    OPPORTUNITY }o--|| CONTACT : "ContactId"
    OPPORTUNITY }o--|| USER : "OwnerId"
    OPPORTUNITY }o--|| PROPERTY__C : "Target/Prior Property"
    OPPORTUNITYSHARE }o--|| OPPORTUNITY : "OpportunityId"
    OPPORTUNITYSHARE }o--|| USER : "UserOrGroupId"
    OPPORTUNITYTEAMMEMBER }o--|| OPPORTUNITY : "OpportunityId"
    OPPORTUNITYTEAMMEMBER }o--|| USER : "UserId"

    OPPORTUNITY_INSTALLMENTS__C }o--|| OPPORTUNITY : "Opportunity_Id__c"
    OPPORTUNITY_INSTALLMENTS__C }o--|| ACCOUNT : "Paying_Account__c"
    OPPORTUNITY_TEAM_INSTALLMENTS__C }o--|| OPPORTUNITY_INSTALLMENTS__C : "Opportunity_Installment_Id__c"
    OPPORTUNITY_TEAM_INSTALLMENTS__C }o--|| OPPORTUNITY : "Opportunity__c"
    OPPORTUNITY_TEAM_INSTALLMENTS__C }o--|| USER : "CBRE_Professional__c"
    OPPORTUNITY_TEAM_INSTALLMENTS__C }o--|| BUDGET_TARGET__C : "BudgetTarget__c"
    TEAM_MEMBER_FUMO_SPLIT__C }o--|| OPPORTUNITY : "Opportunity__c"
    TEAM_MEMBER_FUMO_SPLIT__C }o--|| OPPORTUNITYTEAMMEMBER : "Opportunity_Team_Member_Id__c"

    LEAD }o--|| ACCOUNT : "ConvertedAccountId"
    LEAD }o--|| CONTACT : "ConvertedContactId"
    LEAD }o--|| OPPORTUNITY : "ConvertedOpportunityId"

    BUDGET_TARGET__C }o--|| USER : "OwnerId / CBRE_Professional__c"
    BUDGET_TARGET__C }o--|| RECORDTYPE : "RecordTypeId"
```

Polymorphic fields (need conditional join logic, not FK constraints):
- `EVENT.WhoId` / `TASK.WhoId` → `CONTACT` or `LEAD`
- `EVENT.WhatId` / `TASK.WhatId` → `ACCOUNT` or `OPPORTUNITY`

Universal audit columns present on nearly every table: `OWNERID`,
`CREATEDBYID`, `LASTMODIFIEDBYID` → all point to `USER.ID`.

## CDC field-presence matrix

| Field | Purpose | Present everywhere? |
|---|---|---|
| `ID` | Primary key — required for `MERGE`/upsert dedup | ✅ all 25 tables |
| `SYSTEMMODSTAMP` | Salesforce's system-level "last changed" timestamp — the correct incremental watermark field (updates on *any* change, including rollups/formula recalcs; not user-editable) | ✅ all 25 tables |
| `LASTMODIFIEDDATE` | Business-level last-modified timestamp — use for audit display only, **not** as the watermark | ✅ all 25 tables |
| `ISDELETED` | Soft-delete flag — required to propagate deletes (Salesforce returns deleted rows as `IsDeleted=true` rather than omitting them, until physically purged) | ⚠️ missing on `USERROLE` |
| `CREATEDDATE` | Record creation timestamp — backfill ordering/audit | ⚠️ missing on `OPPORTUNITYSHARE` |
| `CREATEDBYID` / `LASTMODIFIEDBYID` | Audit trail → join to `USER.ID` | ⚠️ `CREATEDBYID` missing on `OPPORTUNITYSHARE` |

**Minimum viable CDC field set per table:** `ID`, `SYSTEMMODSTAMP`, `ISDELETED`
(where present).

Exceptions to design around:
- **`USERROLE`** has no `ISDELETED` → no delete signal from the field
  itself. Deletes must be detected by periodically diffing the full set of
  `ID`s (role hierarchy is tiny — 2.4K rows — so a full-table ID diff on
  each run is cheap), or by trusting the loader's full-refresh behavior.
- **`OPPORTUNITYSHARE`** has no `CREATEDDATE`/`CREATEDBYID` → drop them from
  any field list; it also has no `OwnerId` (sharing records use
  `UserOrGroupId` instead).
- **`ACCOUNT1`** is a mirrored/snapshot copy of `ACCOUNT`, not a distinct
  Salesforce object — it has no SOQL source object to drive an incremental
  pull from, so it is excluded from the CDC field mapping below and from
  `app/metadata.py`.

## Snowflake `CHANGE_TRACKING` status (as found)

| Already `ON` (7) | Needs `ALTER ... SET CHANGE_TRACKING = TRUE` (18) |
|---|---|
| `ACCOUNT`, `OPPORTUNITY`, `OPPORTUNITY_INSTALLMENTS__C`, `OPPORTUNITY_TEAM_INSTALLMENTS__C`, `PROPERTY__C`, `RECORDTYPE`, `USER` | `ACCOUNT1`, `ACCOUNTCONTACTRELATION`, `ACCOUNTTEAMMEMBER`, `ACCOUNT_WITH_SPOCS__C`, `BUDGET_TARGET__C`, `CONTACT`, `CONTACT_RELATIONSHIP__C`, `EVENT`, `LEAD`, `OPPORTUNITYSHARE`, `OPPORTUNITYTEAMMEMBER`, `PERMISSIONSET`, `PERMISSIONSETGROUP`, `PROFILE`, `SPOC__C`, `TASK`, `TEAM_MEMBER_FUMO_SPLIT__C`, `USERROLE` |

## Two CDC patterns — which applies here

| | Pattern A — Snowflake Streams + Tasks | Pattern B — Python watermark + `MERGE` loader |
|---|---|---|
| Captures changes | Inside Snowflake, after data lands in `STG_SF.*` | From Salesforce, before data lands in Snowflake |
| Applicable here? | **Yes — this is what's needed**, since SnapLogic already loads `STG_SF.*` and there's nothing to hook into upstream of it | Only relevant if SnapLogic is ever replaced/supplemented by a custom loader |
| Implementation | `sql/snowflake_streams_tasks.sql` in this repo | `app/metadata.py` + `app/pipeline.py` in this repo |
| Delete handling | Automatic — Snowflake `STREAM.METADATA$ACTION='DELETE'` fires on any row removal, regardless of Salesforce `ISDELETED` | Depends on Salesforce `IsDeleted`/`getDeleted()`; breaks down for `USERROLE` |

Given SnapLogic owns ingestion, **Pattern A is the primary, directly
actionable pattern** for STG_SF. Pattern B has been extended in this repo's
`app/metadata.py` as a documented fallback/reference in case a custom loader
is ever needed for these objects.

## Recommended `MERGE` shape (Pattern B, for reference)

```sql
MERGE INTO STG_SF.ACCOUNT t
USING staging_batch s
ON t.ID = s.ID
WHEN MATCHED AND s.ISDELETED = 'true' THEN DELETE
WHEN MATCHED THEN UPDATE SET t.* = s.*
WHEN NOT MATCHED THEN INSERT (...) VALUES (...)
```

Key Snowflake building blocks either pattern needs: `MERGE`, a
watermark/control table (`MAX(SYSTEMMODSTAMP)` per object), `STREAM` +
`TASK` + `SYSTEM$STREAM_HAS_DATA()` if chaining a second incremental hop
downstream of `STG_SF`.

See [sql/snowflake_streams_tasks.sql](../../sql/snowflake_streams_tasks.sql)
for the full Pattern A rollout across all 24 automatable tables, and
[app/metadata.py](../../app/metadata.py) for the Pattern B object
configuration.
