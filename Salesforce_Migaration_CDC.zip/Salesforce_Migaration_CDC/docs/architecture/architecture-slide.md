# Salesforce to Snowflake Incremental Architecture

## Slide title
Salesforce → Snowflake Incremental CDC Pattern

## Executive summary
- Salesforce remains the system of record
- Python orchestrator runs four times per day
- Only changed records are pulled using SystemModstamp
- Snowflake staging table receives the delta
- Snowflake final table is updated using MERGE
- Watermark tracks the latest successful load
- Snowflake Streams/Tasks can handle downstream CDC

## Flow
1. Salesforce objects change
2. Python orchestrator wakes at 00:00, 06:00, 12:00, 18:00
3. Read last watermark from CONTROL_WATERMARK
4. Query Salesforce with SystemModstamp > watermark
5. Load changed rows into STG_<Object>
6. MERGE into RAW_<Object>
7. Update watermark
8. Optional Snowflake Stream/Task for downstream processing

## Key design choices
- No Salesforce-side event trigger required
- Keeps the design simple and operationally stable
- Best fit for 4-load-per-day business requirement
- Works for org-wide Azure repo and Python orchestration

## Data flow
Salesforce → Python → Snowflake Stage → Snowflake Final → Watermark → Downstream CDC → Reporting

## Why this works
- Uses the best delta field: SystemModstamp
- Supports delete handling with IsDeleted or getDeleted
- Minimizes data movement and cost
- Keeps pipeline deterministic and controllable

## Production notes
- Keep credentials in Azure Key Vault or secure pipeline variables
- Track run status in logs and control table
- Add retry and alerting around failed runs
- Extend metadata config for each object
