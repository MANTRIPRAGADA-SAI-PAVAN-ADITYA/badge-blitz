# Code-ready repo layout for the architecture

This repo is structured to follow the exact flow below:

Salesforce source
  -> Python orchestrator (4x/day)
  -> Snowflake staging tables
  -> Snowflake final tables
  -> watermark table
  -> optional Snowflake Streams/Tasks
  -> downstream reporting

## Current repo layout

```text
Salesforce_Migaration_CDC/
├── app/
│   ├── __init__.py
│   ├── __main__.py
│   ├── azure_runner.py
│   ├── main.py
│   ├── metadata.py
│   ├── orchestrator.py
│   ├── pipeline.py
│   ├── salesforce_client.py
│   └── snowflake_client.py
├── config/
│   ├── __init__.py
│   └── settings.py
├── docs/
│   └── architecture/
│       ├── architecture-diagram.svg
│       ├── architecture-slide.md
│       └── repo-layout.md
├── sql/
│   ├── __init__.py
│   └── snowflake_streams_tasks.sql
├── tests/
│   ├── test_incremental_loader.py
│   └── test_metadata.py
├── .env.example
├── .gitignore
├── azure-pipelines.yml
├── README.md
├── requirements.txt
└── salesforce_cdc/
    ├── __init__.py
    └── orchestrator.py
```

## Responsibility split

- app/orchestrator.py
  - run windows and SOQL generation
- app/pipeline.py
  - incremental job execution per object
- app/salesforce_client.py
  - Salesforce API connection and delta queries
- app/snowflake_client.py
  - Snowflake staging, merge, watermark logic
- app/metadata.py
  - object metadata and per-table config
- sql/snowflake_streams_tasks.sql
  - optional Snowflake CDC downstream pattern
- config/settings.py
  - null-safe configuration loader

## Execution model

1. Scheduler triggers Python app
2. app/main.py iterates object metadata
3. Each object runs through IncrementalPipeline
4. Salesforce records are queried using SystemModstamp
5. Data is loaded into Snowflake staging tables
6. Snowflake merge updates the final table
7. Watermark is refreshed
8. Optional streams/tasks handle downstream reads

## Production next step

Add real Salesforce object names, field lists, Snowflake target table names, and secure credentials before deploying to Azure.
