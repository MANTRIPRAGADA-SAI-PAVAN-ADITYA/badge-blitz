import React, { useState } from 'react'
import { api } from '../api'
import { Err, Pill, Table, fmtTime, useLoad } from '../components.jsx'

const SF_ID = /^[A-Za-z0-9]{15,18}$/

export default function InvestigatePage() {
  const objects = useLoad(() => api.objects())
  const [recordId, setRecordId] = useState('')
  const [object, setObject] = useState('')
  const [result, setResult] = useState(null)
  const [history, setHistory] = useState(null)
  const [error, setError] = useState(null)
  const [busy, setBusy] = useState(false)
  const [onlyDiff, setOnlyDiff] = useState(false)

  const validId = SF_ID.test(recordId.trim())
  const run = async (fn) => {
    setBusy(true); setError(null)
    try { await fn() } catch (e) { setError(e) } finally { setBusy(false) }
  }
  const findHistory = () => run(async () => { setResult(null); setHistory(await api.history(recordId.trim())) })
  const compare = () => run(async () => { setHistory(null); setResult(await api.compare(object, recordId.trim())) })

  const fields = result ? result.fields.filter((f) => !onlyDiff || f.status === 'different') : []
  return (
    <>
      <h1>Investigate</h1>
      <p className="muted">Paste a Salesforce record Id to see every change the pipeline logged for it, or compare what Salesforce holds right now with what Snowflake holds, field by field.</p>
      <Err error={error || objects.error} />

      <div className="card">
        <div className="row">
          <input className="grow mono" style={{ minWidth: 260 }} placeholder="Record Id, e.g. 0015000000AbCdE" value={recordId} onChange={(e) => setRecordId(e.target.value)} />
          <button className="btn" disabled={!validId || busy} onClick={findHistory}>Change history</button>
          <select value={object} onChange={(e) => setObject(e.target.value)}>
            <option value="">Object…</option>
            {(objects.data || []).map((o) => <option key={o.object_name} value={o.object_name}>{o.object_name}</option>)}
          </select>
          <button className="btn primary" disabled={!validId || !object || busy} onClick={compare}>Compare Salesforce ↔ Snowflake</button>
        </div>
        {recordId && !validId && <p className="muted">A Salesforce Id is 15 or 18 letters and digits.</p>}
        {busy && <p className="muted">Working…</p>}
      </div>

      {history && (
        <div className="card">
          <h2>Change history for <span className="mono">{recordId}</span></h2>
          <Table
            columns={[
              { key: 'change_ts', label: 'When', render: (r) => fmtTime(r.change_ts) },
              { key: 'object_name', label: 'Object' },
              { key: 'change_type', label: 'Change', render: (r) => <Pill value={r.change_type} /> },
              { key: 'run_id', label: 'Run', render: (r) => <span className="mono">{r.run_id}</span> },
              { key: 'trigger_type', label: 'Trigger' },
              { key: 'triggered_by', label: 'By' },
            ]}
            rows={history}
            empty="The pipeline has never logged a change for this Id. If it exists in Salesforce, its object may not be enabled, or it has not changed since the last full load."
          />
        </div>
      )}

      {result && (
        <>
          <div className="card">
            <div className="row">
              <h2 className="grow">{result.object_name} · <span className="mono">{result.record_id}</span></h2>
              <Pill value={result.in_salesforce ? 'match' : 'different'}>{result.in_salesforce ? 'in Salesforce' : 'not in Salesforce'}</Pill>
              <Pill value={result.in_snowflake ? 'match' : 'different'}>{result.in_snowflake ? 'in Snowflake' : 'not in Snowflake'}</Pill>
              <Pill value={result.differences ? 'different' : 'match'}>{result.differences ? `${result.differences} differing field(s)` : 'identical'}</Pill>
            </div>
            {!result.in_snowflake && result.in_salesforce && <div className="note">The record exists in Salesforce but not in Snowflake. Run the object (or a full refresh) to load it.</div>}
            {result.in_snowflake && !result.in_salesforce && <div className="note">The record is in Snowflake but no longer in Salesforce — it was hard-deleted. Run with “Also detect hard deletes”.</div>}
            <label className="chk" style={{ margin: '8px 0' }}>
              <input type="checkbox" checked={onlyDiff} onChange={(e) => setOnlyDiff(e.target.checked)} /> Only differences
            </label>
            <div className="scroll" style={{ maxHeight: 520 }}>
              <table className="diff">
                <thead><tr><th>Field</th><th>Salesforce</th><th>Snowflake</th><th></th></tr></thead>
                <tbody>
                  {fields.map((f) => (
                    <tr key={f.field} className={f.status}>
                      <td>{f.field}</td><td>{f.salesforce ?? '—'}</td><td>{f.snowflake ?? '—'}</td>
                      <td><Pill value={f.status} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          <div className="card">
            <h2>Logged changes</h2>
            <Table
              columns={[
                { key: 'change_ts', label: 'When', render: (r) => fmtTime(r.change_ts) },
                { key: 'object_name', label: 'Object' },
                { key: 'change_type', label: 'Change', render: (r) => <Pill value={r.change_type} /> },
                { key: 'run_id', label: 'Run', render: (r) => <span className="mono">{r.run_id}</span> },
              ]}
              rows={result.history}
              empty="No logged changes for this record."
            />
          </div>
        </>
      )}
    </>
  )
}
