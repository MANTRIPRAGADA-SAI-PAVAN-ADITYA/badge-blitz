import React, { useState } from 'react'
import { api } from '../api'
import LogViewer from '../LogViewer.jsx'
import { DataTable, Drawer, Err, Pill, StackedBars, Table, fmtNum, fmtTime, useLoad } from '../components.jsx'

function RunDetail({ run }) {
  const [tab, setTab] = useState('log')
  const [type, setType] = useState('ALL')
  const events = useLoad(() => api.events(run.run_id), [run.run_id])
  const changes = useLoad(() => (tab === 'ids' ? api.changes(run.run_id, run.object_name, type) : Promise.resolve(null)), [tab, type, run.run_id])
  const rows = useLoad(() => (tab === 'rows' ? api.rows(run.run_id, run.object_name, type) : Promise.resolve(null)), [tab, type, run.run_id])

  return (
    <>
      <div className="row">
        <Pill value={run.status} />
        <span className="muted">{fmtTime(run.started_at)} → {fmtTime(run.ended_at)}</span>
        <span className="muted">by {run.triggered_by || '—'} ({run.trigger_type})</span>
      </div>
      <div className="grid kpis" style={{ marginTop: 12 }}>
        <div className="kpi"><b>{fmtNum(run.rows_extracted)}</b><span>extracted</span></div>
        <div className="kpi"><b>{fmtNum(run.rows_inserted)}</b><span>inserted</span></div>
        <div className="kpi"><b>{fmtNum(run.rows_updated)}</b><span>updated</span></div>
        <div className="kpi"><b>{fmtNum(run.rows_deleted)}</b><span>deleted</span></div>
      </div>
      <p className="muted mono">watermark {run.watermark_from || 'start'} → {run.watermark_to || '—'}</p>
      {run.error_message && <div className="err"><b>Error:</b> {run.error_message}</div>}

      <div className="tabs">
        {[['log', 'Log'], ['ids', 'Changed record Ids'], ['rows', 'Current row data']].map(([id, label]) => (
          <button key={id} className={tab === id ? 'on' : ''} onClick={() => setTab(id)}>{label}</button>
        ))}
      </div>
      {tab !== 'log' && (
        <div className="row" style={{ marginBottom: 8 }}>
          {['ALL', 'INSERT', 'UPDATE', 'DELETE'].map((t) => (
            <label key={t} className="chk"><input type="radio" checked={type === t} onChange={() => setType(t)} />{t}</label>
          ))}
        </div>
      )}
      {tab === 'log' && (
        <>
          <Err error={events.error} />
          <LogViewer events={events.data || []} height={520} filename={`cdc-${run.object_name}-${run.run_id}`}
            empty={events.loading ? 'Loading…' : 'No log lines were recorded for this run.'} />
          <p className="small muted">All objects of this run share one log; filter by object above, or open <a href="#logs">Logs</a> to search every run.</p>
        </>
      )}
      {tab === 'ids' && (
        <>
          <Err error={changes.error} />
          <Table
            columns={[
              { key: 'record_id', label: 'Record Id', render: (r) => <span className="mono">{r.record_id}</span> },
              { key: 'change_type', label: 'Change', render: (r) => <Pill value={r.change_type} /> },
              { key: 'change_ts', label: 'When', render: (r) => fmtTime(r.change_ts) },
            ]}
            rows={changes.data}
            empty={changes.loading ? 'Loading…' : 'No changed records.'}
          />
        </>
      )}
      {tab === 'rows' && (
        <>
          <Err error={rows.error} />
          {rows.loading ? <p className="muted">Loading…</p> : <DataTable rows={rows.data} />}
          <p className="muted">Shows what the target table holds now for the records this run changed (max 500).</p>
        </>
      )}
    </>
  )
}

export default function MonitorPage() {
  const [hours, setHours] = useState(24)
  const [statusFilter, setStatusFilter] = useState('')
  const [open, setOpen] = useState(null)
  const summary = useLoad(() => api.summary(hours), [hours])
  const health = useLoad(() => api.health())
  const runs = useLoad(() => api.runs({ hours, status: statusFilter }), [hours, statusFilter])
  const t = summary.data?.totals

  const refresh = () => { summary.reload(); health.reload(); runs.reload() }
  const count = (state) => (health.data || []).filter((h) => h.state === state).length

  return (
    <>
      <div className="row">
        <h1 className="grow">Monitor & logs</h1>
        <select value={hours} onChange={(e) => setHours(Number(e.target.value))}>
          {[[6, '6 hours'], [24, '24 hours'], [72, '3 days'], [168, '7 days'], [720, '30 days']].map(([h, l]) => <option key={h} value={h}>Last {l}</option>)}
        </select>
        <button className="btn" onClick={refresh}>Refresh</button>
      </div>
      <Err error={summary.error || health.error || runs.error} />

      <div className="grid kpis">
        <div className="kpi"><b style={{ color: 'var(--ins)' }}>{fmtNum(t?.inserted)}</b><span>inserted</span></div>
        <div className="kpi"><b style={{ color: 'var(--upd)' }}>{fmtNum(t?.updated)}</b><span>updated</span></div>
        <div className="kpi"><b style={{ color: 'var(--del)' }}>{fmtNum(t?.deleted)}</b><span>deleted</span></div>
        <div className="kpi"><b>{fmtNum(t?.object_runs)}</b><span>object runs</span></div>
        <div className="kpi"><b style={{ color: t?.failures ? 'var(--bad)' : undefined }}>{fmtNum(t?.failures)}</b><span>failures</span></div>
      </div>

      <div className="card">
        <h2>Object health</h2>
        <p className="muted">{count('healthy')} healthy · {count('stale')} stale (no success for 8h+) · {count('failing')} failing · {count('never_run')} never run</p>
        <Table
          columns={[
            { key: 'object_name', label: 'Object', render: (h) => <b>{h.object_name}</b> },
            { key: 'state', label: 'State', render: (h) => <Pill value={h.state} /> },
            { key: 'last_success', label: 'Last success', render: (h) => (h.last_success ? `${fmtTime(h.last_success)} (${h.hours_since_success}h ago)` : '—') },
            { key: 'watermark', label: 'Watermark', render: (h) => <span className="mono">{h.watermark || '—'}</span> },
            { key: 'last_error', label: 'Last error', render: (h) => (h.state === 'failing' ? h.last_error : '') },
          ]}
          rows={(health.data || []).filter((h) => h.enabled || h.last_status)}
          empty={health.loading ? 'Loading…' : 'No enabled objects.'}
        />
      </div>

      <div className="card">
        <h2>Changes over time</h2>
        <StackedBars data={summary.data?.timeline} label={(d) => new Date(d.bucket).toLocaleString([], { month: 'short', day: 'numeric', hour: hours <= 48 ? '2-digit' : undefined })} />
      </div>
      <div className="card">
        <h2>Changes by object</h2>
        <StackedBars data={summary.data?.by_object} label={(d) => d.object_name} />
      </div>

      <div className="card">
        <div className="row">
          <h2 className="grow">Run history</h2>
          <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
            <option value="">All statuses</option><option value="SUCCESS">Success</option><option value="FAILED">Failed</option><option value="RUNNING">Running</option>
          </select>
        </div>
        <p className="muted">Click a run to see its log, the records it changed and their current data.</p>
        <Table
          onRow={setOpen}
          columns={[
            { key: 'started_at', label: 'Started', render: (r) => fmtTime(r.started_at) },
            { key: 'object_name', label: 'Object', render: (r) => <b>{r.object_name}</b> },
            { key: 'status', label: 'Status', render: (r) => <Pill value={r.status} /> },
            { key: 'trigger_type', label: 'Trigger' },
            { key: 'rows_inserted', label: 'Ins', num: true },
            { key: 'rows_updated', label: 'Upd', num: true },
            { key: 'rows_deleted', label: 'Del', num: true },
            { key: 'error_message', label: 'Error', render: (r) => (r.error_message || '').slice(0, 80) },
          ]}
          rows={runs.data}
          empty={runs.loading ? 'Loading…' : 'No runs in this window.'}
          max={560}
        />
      </div>

      {open && (
        <Drawer title={`${open.object_name} — run ${open.run_id}`} onClose={() => setOpen(null)}>
          <RunDetail run={open} />
        </Drawer>
      )}
    </>
  )
}
