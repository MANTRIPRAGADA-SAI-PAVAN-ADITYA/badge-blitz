import React, { useState } from 'react'
import { api } from '../api'
import LogViewer from '../LogViewer.jsx'
import { Err, useLoad } from '../components.jsx'

/** Search the persisted log of every run: by time window, level, object, run id and text. */
export default function LogsPage() {
  const objects = useLoad(() => api.objects())
  const [f, setF] = useState({ hours: 24, level: 'WARN,ERROR', object: '', run_id: '', q: '', limit: 2000 })
  const [applied, setApplied] = useState(f)
  const logs = useLoad(() => api.logs(applied), [JSON.stringify(applied)])
  const set = (patch) => setF({ ...f, ...patch })
  const apply = (e) => { e?.preventDefault(); setApplied(f) }

  // newest first from the API -> oldest first on screen, so it reads like a normal log
  const events = [...(logs.data || [])].reverse()

  return (
    <>
      <h1>Logs</h1>
      <p className="muted">Every line of every run — scheduled or manual — is saved. Search across runs to find what happened and when.</p>
      <Err error={logs.error || objects.error} />

      <form className="card" onSubmit={apply}>
        <div className="row">
          <label>Time window&nbsp;
            <select value={f.hours} onChange={(e) => set({ hours: Number(e.target.value) })}>
              {[[1, '1 hour'], [6, '6 hours'], [24, '24 hours'], [72, '3 days'], [168, '7 days'], [720, '30 days']].map(([h, l]) => <option key={h} value={h}>Last {l}</option>)}
            </select>
          </label>
          <label>Level&nbsp;
            <select value={f.level} onChange={(e) => set({ level: e.target.value })}>
              <option value="">All</option><option value="WARN,ERROR">Warnings &amp; errors</option><option value="ERROR">Errors only</option><option value="INFO">Info only</option>
            </select>
          </label>
          <label>Object&nbsp;
            <select value={f.object} onChange={(e) => set({ object: e.target.value })}>
              <option value="">All</option>
              {(objects.data || []).map((o) => <option key={o.object_name} value={o.object_name}>{o.object_name}</option>)}
            </select>
          </label>
          <input placeholder="Run id" className="mono" style={{ width: 130 }} value={f.run_id} onChange={(e) => set({ run_id: e.target.value.trim() })} />
          <input placeholder="Contains text…" className="grow" value={f.q} onChange={(e) => set({ q: e.target.value })} />
          <label>Max lines&nbsp;
            <select value={f.limit} onChange={(e) => set({ limit: Number(e.target.value) })}>
              {[500, 2000, 5000, 20000].map((n) => <option key={n} value={n}>{n.toLocaleString()}</option>)}
            </select>
          </label>
          <button className="btn primary" type="submit">Search</button>
          <button className="btn" type="button" onClick={logs.reload}>Refresh</button>
        </div>
        {applied.run_id && (
          <p className="small muted" style={{ marginBottom: 0 }}>
            Showing run <span className="mono">{applied.run_id}</span> — <a onClick={() => { const n = { ...f, run_id: '' }; setF(n); setApplied(n) }}>show all runs</a>
          </p>
        )}
      </form>

      <LogViewer
        events={events}
        height={620}
        showDate
        filename="cdc-logs"
        onRun={(id) => { const n = { ...f, run_id: id, hours: 720, level: '' }; setF(n); setApplied(n) }}
        empty={logs.loading ? 'Searching…' : 'No log lines match. Try a longer time window or clear the filters.'}
      />
      {logs.data && logs.data.length >= applied.limit && (
        <p className="note">Showing the newest {applied.limit.toLocaleString()} matching lines. Narrow the filters or raise “Max lines” to see more.</p>
      )}
    </>
  )
}
