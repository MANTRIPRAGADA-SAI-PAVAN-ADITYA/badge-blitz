import React, { useEffect, useRef, useState } from 'react'
import { api } from '../api'
import { Err, Pill, Table, fmtTime, useLoad, usePoll } from '../components.jsx'

export default function RunPage() {
  const objects = useLoad(() => api.objects())
  const [run, setRun] = useState({ running: false })
  const [picked, setPicked] = useState(null) // null = all enabled
  const [fullRefresh, setFullRefresh] = useState(false)
  const [reconcile, setReconcile] = useState(false)
  const [error, setError] = useState(null)
  const logRef = useRef(null)

  const refresh = () => api.runState().then(setRun, setError)
  useEffect(() => { refresh() }, [])
  usePoll(refresh, 1500, run.running)
  useEffect(() => { if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight }, [run.log])

  const enabled = (objects.data || []).filter((o) => o.enabled)
  const selected = picked ?? enabled.map((o) => o.object_name)
  const toggle = (name) =>
    setPicked(selected.includes(name) ? selected.filter((n) => n !== name) : [...selected, name])

  const start = async () => {
    setError(null)
    try { setRun(await api.startRun({ objects: selected, full_refresh: fullRefresh, reconcile })) } catch (e) { setError(e) }
  }
  const stop = async () => setRun(await api.stopRun())

  return (
    <>
      <h1>Run pipeline</h1>
      <p className="muted">Fetches changed rows from Salesforce and merges them into Snowflake. The same code runs on the 6-hourly schedule.</p>
      <Err error={objects.error || error} />

      <div className="card">
        <h2>Objects to run</h2>
        {enabled.length === 0 && <div className="note">No objects are enabled. Enable some on the Objects page first.</div>}
        <div className="row">
          {enabled.map((o) => (
            <label key={o.object_name} className="chk">
              <input type="checkbox" disabled={run.running} checked={selected.includes(o.object_name)} onChange={() => toggle(o.object_name)} />
              {o.object_name}
            </label>
          ))}
        </div>
        <h3>Options</h3>
        <div className="row">
          <label className="chk" title="Re-read every row, ignoring the watermark. Safe (merge is idempotent) but slow.">
            <input type="checkbox" disabled={run.running} checked={fullRefresh} onChange={(e) => setFullRefresh(e.target.checked)} />
            Full refresh
          </label>
          <label className="chk" title="Find rows purged from Salesforce's recycle bin by comparing Ids. Always on for objects without IsDeleted.">
            <input type="checkbox" disabled={run.running} checked={reconcile} onChange={(e) => setReconcile(e.target.checked)} />
            Also detect hard deletes
          </label>
        </div>
        <div className="row" style={{ marginTop: 16 }}>
          <button className="btn primary" disabled={run.running || selected.length === 0} onClick={start}>
            {run.running ? 'Running…' : `Run ${selected.length} object${selected.length === 1 ? '' : 's'}`}
          </button>
          <button className="btn" disabled={!run.running} onClick={stop}>Stop after current object</button>
          {run.running && <span className="muted">started {fmtTime(run.started_at)}</span>}
        </div>
      </div>

      {run.error && <div className="err">{run.error}</div>}
      {run.summary && (
        <div className="card">
          <h2>Result — run <span className="mono">{run.summary.run_id}</span> {run.summary.failed ? <Pill value="FAILED">{run.summary.failed} failed</Pill> : <Pill value="SUCCESS">all succeeded</Pill>}</h2>
          <Table
            columns={[
              { key: 'object', label: 'Object' },
              { key: 'status', label: 'Status', render: (r) => <Pill value={r.status} /> },
              { key: 'extracted', label: 'Extracted', num: true },
              { key: 'inserted', label: 'Inserted', num: true },
              { key: 'updated', label: 'Updated', num: true },
              { key: 'deleted', label: 'Deleted', num: true },
              { key: 'error', label: 'Error' },
            ]}
            rows={run.summary.results}
          />
        </div>
      )}
      {run.log && run.log.length > 0 && (
        <div className="card">
          <h2>Live log</h2>
          <div className="log" ref={logRef}>{run.log.join('\n')}</div>
        </div>
      )}
    </>
  )
}
