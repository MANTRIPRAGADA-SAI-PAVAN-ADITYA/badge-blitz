import React, { useEffect, useState } from 'react'
import { api } from './api'
import { Err } from './components.jsx'
import RunPage from './pages/RunPage.jsx'
import ObjectsPage from './pages/ObjectsPage.jsx'
import MonitorPage from './pages/MonitorPage.jsx'
import InvestigatePage from './pages/InvestigatePage.jsx'
import LogsPage from './pages/LogsPage.jsx'

const PAGES = [
  ['run', 'Run pipeline', RunPage],
  ['objects', 'Objects', ObjectsPage],
  ['monitor', 'Monitor & logs', MonitorPage],
  ['logs', 'Logs', LogsPage],
  ['investigate', 'Investigate', InvestigatePage],
]

export default function App() {
  const [status, setStatus] = useState(null)
  const [error, setError] = useState(null)
  const [busy, setBusy] = useState(false)
  const [page, setPage] = useState(() => window.location.hash.slice(1) || 'run')

  useEffect(() => {
    const onHash = () => setPage(window.location.hash.slice(1) || 'run')
    window.addEventListener('hashchange', onHash)
    return () => window.removeEventListener('hashchange', onHash)
  }, [])
  useEffect(() => { api.status().then(setStatus, setError) }, [])

  const connect = async () => {
    setBusy(true); setError(null)
    try { setStatus(await api.connect()) } catch (e) { setError(e) } finally { setBusy(false) }
  }
  const disconnect = async () => setStatus(await api.disconnect())
  const go = (id) => { window.location.hash = id }

  if (!status) return <div className="main"><Err error={error} /><p className="muted">Loading…</p></div>

  if (!status.connected) {
    return (
      <div className="main" style={{ maxWidth: 640, margin: '8vh auto' }}>
        <h1>Salesforce → Snowflake CDC</h1>
        <p className="muted">Control centre for the incremental migration pipeline.</p>
        <div className="card">
          <p><b>Source</b> <span className="mono">{status.salesforce_login_url}</span></p>
          <p><b>Target</b> <span className="mono">{status.snowflake_target}</span> as <span className="mono">{status.snowflake_user}</span> ({status.snowflake_auth})</p>
          {status.problems.map((p) => <div key={p} className="note">{p}</div>)}
          {status.problems.length > 0 && <p className="muted">Copy <span className="mono">.env.example</span> to <span className="mono">.env</span>, fill it in and restart the server.</p>}
          <Err error={error} />
          <button className="btn primary" disabled={busy || status.problems.length > 0} onClick={connect}>
            {busy ? 'Connecting… (a browser window may open for SSO)' : 'Connect'}
          </button>
        </div>
      </div>
    )
  }

  const Current = (PAGES.find(([id]) => id === page) || PAGES[0])[2]
  return (
    <div className="shell">
      <aside className="side">
        <div className="brand">CDC Control Centre<small>Salesforce → Snowflake</small></div>
        <nav className="nav">
          {PAGES.map(([id, label]) => (
            <button key={id} className={page === id ? 'on' : ''} onClick={() => go(id)}>{label}</button>
          ))}
        </nav>
        <div className="conn">
          <div><b>Snowflake</b></div>
          <div className="mono">{status.session?.database}.{status.session?.schema}</div>
          <div className="mono">{status.session?.role}</div>
          <div style={{ marginTop: 6 }}><b>Salesforce</b></div>
          <div className="mono" style={{ wordBreak: 'break-all' }}>{status.salesforce_login_url}</div>
          <div style={{ marginTop: 8 }}><a onClick={disconnect}>Disconnect</a></div>
        </div>
      </aside>
      <main className="main"><Current go={go} /></main>
    </div>
  )
}
