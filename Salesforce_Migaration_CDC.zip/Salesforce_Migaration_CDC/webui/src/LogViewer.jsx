import React, { useEffect, useMemo, useRef, useState } from 'react'
import { Pill, Table, fmtNum } from './components.jsx'

/** Live events ({ts, object, level, message}) and persisted ones ({event_ts, object_name, run_id, ...}) -> one shape. */
export const normEvent = (e) => ({
  ts: e.ts || e.event_ts || '',
  level: (e.level || 'INFO').toUpperCase(),
  object: e.object ?? e.object_name ?? null,
  run: e.run_id || null,
  message: e.message || '',
})

const escapeRe = (t) => t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')

function Highlight({ text, q }) {
  if (!q) return text
  const parts = text.split(new RegExp(`(${escapeRe(q)})`, 'ig'))
  return parts.map((p, i) => (p.toLowerCase() === q.toLowerCase() ? <mark key={i}>{p}</mark> : p))
}

const timeOf = (ts) => (ts ? new Date(ts).toLocaleTimeString([], { hour12: false }) : '')
const dayOf = (ts) => (ts ? new Date(ts).toLocaleDateString([], { month: 'short', day: 'numeric' }) : '')

/**
 * Searchable, filterable log. Used for the live run log, a past run's log and the cross-run log search.
 * Filters: level chips, object, text. Actions: follow the tail, wrap lines, copy, download.
 */
export default function LogViewer({
  events, live = false, height = 440, onRun, showDate = false, empty = 'No log lines yet.', filename = 'cdc-log',
}) {
  const lines = useMemo(() => (events || []).map(normEvent), [events])
  const [levels, setLevels] = useState({ INFO: true, WARN: true, ERROR: true })
  const [obj, setObj] = useState('')
  const [q, setQ] = useState('')
  const [follow, setFollow] = useState(true)
  const [wrap, setWrap] = useState(true)
  const box = useRef(null)

  const counts = useMemo(() => lines.reduce((a, l) => ({ ...a, [l.level]: (a[l.level] || 0) + 1 }), {}), [lines])
  const objects = useMemo(() => [...new Set(lines.map((l) => l.object).filter(Boolean))].sort(), [lines])
  const shown = useMemo(() => {
    const needle = q.trim().toLowerCase()
    return lines.filter(
      (l) => levels[l.level] !== false
        && (!obj || l.object === obj || (obj === '(general)' && !l.object))
        && (!needle || l.message.toLowerCase().includes(needle)),
    )
  }, [lines, levels, obj, q])

  useEffect(() => {
    if (live && follow && box.current) box.current.scrollTop = box.current.scrollHeight
  }, [shown.length, live, follow])

  const asText = () => shown.map((l) => `${l.ts} ${l.level.padEnd(5)} ${l.run ? `${l.run} ` : ''}${l.message}`).join('\n')
  const copy = async () => { try { await navigator.clipboard.writeText(asText()) } catch { /* clipboard unavailable */ } }
  const download = () => {
    const url = URL.createObjectURL(new Blob([asText()], { type: 'text/plain' }))
    const a = Object.assign(document.createElement('a'), { href: url, download: `${filename}.txt` })
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="logview" style={{ '--lt': showDate ? '132px' : '70px' }}>
      <div className="logbar">
        {['INFO', 'WARN', 'ERROR'].map((lv) => (
          <button key={lv} className={`chip ${lv} ${levels[lv] ? 'on' : ''}`} onClick={() => setLevels({ ...levels, [lv]: !levels[lv] })}>
            {lv.toLowerCase()} <b>{counts[lv] || 0}</b>
          </button>
        ))}
        <select value={obj} onChange={(e) => setObj(e.target.value)}>
          <option value="">All objects</option>
          {objects.map((o) => <option key={o} value={o}>{o}</option>)}
          <option value="(general)">(general)</option>
        </select>
        <input className="grow" placeholder="Search log…" value={q} onChange={(e) => setQ(e.target.value)} />
        {live && <label className="chk small"><input type="checkbox" checked={follow} onChange={(e) => setFollow(e.target.checked)} />follow</label>}
        <label className="chk small"><input type="checkbox" checked={wrap} onChange={(e) => setWrap(e.target.checked)} />wrap</label>
        <button className="btn small" onClick={copy}>Copy</button>
        <button className="btn small" onClick={download} disabled={!shown.length}>Download</button>
      </div>
      <div className="logbody" ref={box} style={{ maxHeight: height }}>
        {shown.length === 0 && <div className="logempty">{lines.length ? 'No lines match the filters.' : empty}</div>}
        {shown.map((l, i) => (
          <div key={i} className={`logline ${l.level} ${wrap ? 'wrap' : ''}`}>
            <span className="lt">{showDate && <>{dayOf(l.ts)} </>}{timeOf(l.ts)}</span>
            <span className={`lv ${l.level}`}>{l.level}</span>
            <span className="lm">
              {onRun && l.run && <a className="lr" onClick={() => onRun(l.run)}>{l.run}</a>}
              <Highlight text={l.message} q={q.trim()} />
            </span>
          </div>
        ))}
      </div>
      <div className="logfoot">{shown.length.toLocaleString()} of {lines.length.toLocaleString()} lines</div>
    </div>
  )
}

/** Per-object progress read from the live log: state, task progress, rows so far, last message. */
export function objectProgress(events) {
  const out = {}
  for (const raw of events || []) {
    const e = normEvent(raw)
    if (!e.object) continue
    const o = (out[e.object] ||= { object: e.object, state: 'running', done: 0, total: 0, rows: 0, last: '' })
    o.last = e.message.replace(/^\[[^\]]+\]\s*/, '')
    const task = e.message.match(/task (\d+)\/(\d+) done/)
    if (task) { o.done = Number(task[1]); o.total = Number(task[2]) }
    const sofar = e.message.match(/\|\s*([\d,]+) rows so far/)
    if (sofar) o.rows = Number(sofar[1].replace(/,/g, ''))
    if (/\] done in \d+s/.test(e.message)) o.state = 'done'
    else if (/\] FAILED/.test(e.message)) o.state = 'failed'
    else if (/\] skipped/.test(e.message)) o.state = 'skipped'
  }
  return Object.values(out)
}

export function ObjectProgress({ events }) {
  const rows = objectProgress(events)
  if (rows.length === 0) return null
  const tone = { running: 'RUNNING', done: 'SUCCESS', failed: 'FAILED', skipped: 'SKIPPED' }
  return (
    <Table
      columns={[
        { key: 'object', label: 'Object', render: (r) => <b>{r.object}</b> },
        { key: 'state', label: 'State', render: (r) => <Pill value={tone[r.state]}>{r.state}</Pill> },
        {
          key: 'progress',
          label: 'Tasks',
          render: (r) => (r.total ? (
            <div style={{ minWidth: 140 }}>
              <div className="bar"><i style={{ width: `${Math.round((100 * r.done) / r.total)}%` }} /></div>
              <span className="small">{r.done} / {r.total}</span>
            </div>
          ) : '—'),
        },
        { key: 'rows', label: 'Rows', num: true, render: (r) => fmtNum(r.rows || null) },
        { key: 'last', label: 'Latest', render: (r) => <span className="small">{r.last}</span> },
      ]}
      rows={rows}
    />
  )
}
