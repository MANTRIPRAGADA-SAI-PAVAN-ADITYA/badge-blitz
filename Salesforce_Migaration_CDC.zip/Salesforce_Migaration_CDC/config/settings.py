import os
from dataclasses import dataclass, field
from typing import Optional

from dotenv import load_dotenv

load_dotenv()


def _env(name: str, default: Optional[str] = None) -> Optional[str]:
    value = os.getenv(name)
    return value if value not in (None, "") else default


@dataclass(frozen=True)
class SalesforceConfig:
    username: Optional[str] = field(default_factory=lambda: _env("SF_USERNAME"))
    password: Optional[str] = field(default_factory=lambda: _env("SF_PASSWORD"))
    security_token: Optional[str] = field(
        default_factory=lambda: _env("SF_SECURITY_TOKEN") or _env("SF_TOKEN")
    )
    access_token: Optional[str] = field(default_factory=lambda: _env("SF_ACCESS_TOKEN") or _env("SF_SESSION_ID"))
    session_id: Optional[str] = field(default_factory=lambda: _env("SF_SESSION_ID"))
    instance_url: Optional[str] = field(default_factory=lambda: _env("SF_INSTANCE_URL"))
    client_id: Optional[str] = field(default_factory=lambda: _env("SF_CLIENT_ID") or _env("SF_CONSUMER_KEY"))
    client_secret: Optional[str] = field(default_factory=lambda: _env("SF_CLIENT_SECRET") or _env("SF_CONSUMER_SECRET"))
    consumer_key: Optional[str] = field(default_factory=lambda: _env("SF_CONSUMER_KEY") or _env("SF_CLIENT_ID"))
    private_key: Optional[str] = field(default_factory=lambda: _env("SF_PRIVATE_KEY"))
    private_key_file: Optional[str] = field(default_factory=lambda: _env("SF_PRIVATE_KEY_FILE"))
    login_url: Optional[str] = field(default_factory=lambda: _env("SF_LOGIN_URL", "https://login.salesforce.com"))
    auth_mode: str = field(default_factory=lambda: (_env("SF_AUTH_MODE") or "password").strip().lower())

    def has_password_auth(self) -> bool:
        return bool(self.username and self.password)

    def uses_token_auth(self) -> bool:
        return bool((self.access_token or self.session_id) and self.instance_url)

    def uses_client_credentials(self) -> bool:
        return bool(self.client_id and self.client_secret and self.login_url)

    def uses_jwt_auth(self) -> bool:
        return bool(
            self.username
            and (self.client_id or self.consumer_key)
            and (self.private_key or self.private_key_file)
        )

    def has_api_credentials(self) -> bool:
        return self.has_password_auth() or self.uses_token_auth() or self.uses_client_credentials() or self.uses_jwt_auth()


@dataclass(frozen=True)
class SnowflakeConfig:
    account: Optional[str] = field(default_factory=lambda: _env("SNOWFLAKE_ACCOUNT"))
    user: Optional[str] = field(default_factory=lambda: _env("SNOWFLAKE_USER"))
    password: Optional[str] = field(default_factory=lambda: _env("SNOWFLAKE_PASSWORD"))
    role: Optional[str] = field(default_factory=lambda: _env("SNOWFLAKE_ROLE"))
    warehouse: Optional[str] = field(default_factory=lambda: _env("SNOWFLAKE_WAREHOUSE"))
    database: Optional[str] = field(default_factory=lambda: _env("SNOWFLAKE_DATABASE"))
    schema: Optional[str] = field(default_factory=lambda: _env("SNOWFLAKE_SCHEMA"))
    authenticator: Optional[str] = field(default_factory=lambda: (_env("SNOWFLAKE_AUTHENTICATOR") or "").strip() or None)
    token: Optional[str] = field(default_factory=lambda: _env("SNOWFLAKE_TOKEN") or _env("SNOWFLAKE_OAUTH_TOKEN"))
    private_key: Optional[str] = field(default_factory=lambda: _env("SNOWFLAKE_PRIVATE_KEY"))
    private_key_file: Optional[str] = field(default_factory=lambda: _env("SNOWFLAKE_PRIVATE_KEY_FILE") or _env("SNOWFLAKE_P8_PATH"))
    private_key_passphrase: Optional[str] = field(
        default_factory=lambda: _env("SNOWFLAKE_PRIVATE_KEY_PASSPHRASE") or _env("SNOWFLAKE_P8_PASSPHRASE")
    )
    private_key_file_pwd: Optional[str] = field(
        default_factory=lambda: _env("SNOWFLAKE_PRIVATE_KEY_FILE_PWD") or _env("SNOWFLAKE_PRIVATE_KEY_PASSPHRASE") or _env("SNOWFLAKE_P8_PASSPHRASE")
    )

    def uses_browser_sso(self) -> bool:
        return bool(self.account and self.user and self.authenticator and self.authenticator.lower() == "externalbrowser")

    def uses_oauth_token(self) -> bool:
        return bool(self.account and self.user and self.token and self.authenticator and self.authenticator.lower() == "oauth")

    def can_connect(self) -> bool:
        return bool(
            self.account
            and self.user
            and (
                self.password
                or self.token
                or self.private_key
                or self.private_key_file
                or self.uses_browser_sso()
            )
        )


@dataclass(frozen=True)
class AppConfig:
    salesforce: SalesforceConfig = field(default_factory=SalesforceConfig)
    snowflake: SnowflakeConfig = field(default_factory=SnowflakeConfig)
    run_times: tuple[str, ...] = ("00:00", "06:00", "12:00", "18:00")


CONFIG = AppConfig()
