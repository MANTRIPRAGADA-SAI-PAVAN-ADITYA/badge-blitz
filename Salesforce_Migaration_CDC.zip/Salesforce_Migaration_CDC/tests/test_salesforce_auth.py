from unittest.mock import patch

from app.salesforce_client import SalesforceClient
from config.settings import AppConfig, SalesforceConfig


def test_client_credentials_uses_org_my_salesforce_host_for_sandbox():
    config = SalesforceConfig(
        login_url="https://cbrecrm--uat1.sandbox.lightning.force.com",
        client_id="client-id",
        client_secret="client-secret",
    )

    with patch("app.salesforce_client.CONFIG", AppConfig(salesforce=config)):
        with patch("app.salesforce_client.requests.post") as mock_post:
            mock_post.return_value.raise_for_status.return_value = None
            mock_post.return_value.json.return_value = {
                "access_token": "token-123",
                "instance_url": "https://cbrecrm--uat1.sandbox.my.salesforce.com",
            }

            SalesforceClient()

            assert mock_post.call_args[0][0] == (
                "https://cbrecrm--uat1.sandbox.my.salesforce.com/services/oauth2/token"
            )
