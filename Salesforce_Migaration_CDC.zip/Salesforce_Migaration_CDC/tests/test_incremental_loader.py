from salesforce_cdc.orchestrator import get_run_windows, build_soql_query


def test_build_soql_query_uses_system_modstamp_watermark():
    query = build_soql_query(
        object_name="Account",
        fields=["Id", "Name", "SystemModstamp", "IsDeleted"],
        watermark="2024-01-01T00:00:00.000+0000",
    )

    assert "SELECT Id, Name, SystemModstamp, IsDeleted" in query
    assert "WHERE SystemModstamp > 2024-01-01T00:00:00.000+0000" in query
    assert "FROM Account" in query


def test_get_run_windows_has_four_daily_runs():
    windows = get_run_windows()
    assert len(windows) == 4
    assert windows == ["00:00", "06:00", "12:00", "18:00"]
