import csv
import gzip

import pytest

from app import loader
from app.loader import (Partition, bulk_csv_rows, plan_partitions, to_text, with_retries, write_rows_gz)
from app.orchestrator import build_partition_query

IDS = [f"001{i:012d}" for i in range(25)]


def test_partitions_cover_every_id_exactly_once():
    parts = plan_partitions(IDS, 10)
    assert len(parts) == 3
    assert parts[0].lo is None and parts[-1].hi is None
    assert all(a.hi == b.lo for a, b in zip(parts, parts[1:]))           # contiguous, no gaps/overlap

    def owner(i):
        return [p.index for p in parts if (p.lo is None or i >= p.lo) and (p.hi is None or i < p.hi)]
    assert all(len(owner(i)) == 1 for i in IDS)
    sizes = [sum(owner(i) == [p.index] for i in IDS) for p in parts]
    assert sizes == [10, 10, 5]


def test_small_objects_are_a_single_open_partition():
    assert plan_partitions(IDS[:10], 10) == [Partition(0)]
    assert plan_partitions([], 10) == [Partition(0)]


def test_partition_bounds_must_look_like_salesforce_ids():
    with pytest.raises(ValueError):
        Partition(0, lo="x' OR Name != '")


def test_partition_query_combines_watermark_and_id_range():
    q = build_partition_query("Account", ["Id", "Name"], "2024-01-01T00:00:00.000Z", "SystemModstamp",
                              "001000000000010", "001000000000020")
    assert q == ("SELECT Id, Name FROM Account WHERE SystemModstamp > 2024-01-01T00:00:00.000Z "
                 "AND Id >= '001000000000010' AND Id < '001000000000020'")
    assert build_partition_query("Account", ["Id"], None, None) == "SELECT Id FROM Account"


def test_gzip_csv_roundtrips_nulls_commas_quotes_and_newlines(tmp_path):
    path = str(tmp_path / "f.csv.gz")
    rows = [["1", None, 'a,b', 'say "hi"', "two\nlines", ""]]
    assert write_rows_gz(path, iter(rows)) == 1
    with gzip.open(path, "rt", encoding="utf-8", newline="") as handle:
        back = [[None if v == r"\N" else v for v in r] for r in csv.reader(handle)]
    assert back == rows


def test_bulk_csv_is_reordered_and_normalised(tmp_path):
    path = tmp_path / "bulk.csv"
    path.write_text('Name,Id,SystemModstamp,IsDeleted\n"A, Inc",001,2024-05-02T11:30:00.000+0000,false\n,002,,true\n',
                    encoding="utf-8")
    types = {"Id": "id", "Name": "string", "SystemModstamp": "datetime", "IsDeleted": "boolean"}
    rows = list(bulk_csv_rows(str(path), ["Id", "Name", "SystemModstamp", "IsDeleted"], types))
    assert rows == [["001", "A, Inc", "2024-05-02T11:30:00.000+00:00", "false"], ["002", None, None, "true"]]


def test_bulk_csv_missing_column_is_an_error(tmp_path):
    path = tmp_path / "bulk.csv"
    path.write_text("Id\n001\n", encoding="utf-8")
    with pytest.raises(ValueError, match="missing column"):
        list(bulk_csv_rows(str(path), ["Id", "Name"], {"Id": "id", "Name": "string"}))


def test_retries_back_off_then_give_up(monkeypatch):
    monkeypatch.setattr(loader, "RETRY_DELAY", 0)
    calls = []

    def always_fails():
        calls.append(1)
        raise TimeoutError("slow")

    with pytest.raises(TimeoutError):
        with_retries(always_fails, attempts=3)
    assert len(calls) == 3


def test_permanent_errors_fail_immediately(monkeypatch):
    monkeypatch.setattr(loader, "RETRY_DELAY", 0)
    calls = []

    class SalesforceMalformedRequest(Exception):
        pass

    def bad_query():
        calls.append(1)
        raise SalesforceMalformedRequest("INVALID_FIELD")

    with pytest.raises(SalesforceMalformedRequest):
        with_retries(bad_query, attempts=3)
    assert len(calls) == 1


def test_tuning_knobs_read_the_environment(monkeypatch):
    monkeypatch.setenv("CDC_SF_CONCURRENCY", "7")
    monkeypatch.setenv("CDC_PARTITION_ROWS", "123")
    monkeypatch.setenv("CDC_OBJECT_WORKERS", "0")          # never below 1
    assert loader.sf_concurrency() == 7 and loader.partition_rows() == 123 and loader.object_workers() == 1


def test_to_text_matches_between_rest_and_bulk_paths():
    assert to_text("2024-05-02T11:30:00.123+0000", "datetime") == "2024-05-02T11:30:00.123+00:00"
