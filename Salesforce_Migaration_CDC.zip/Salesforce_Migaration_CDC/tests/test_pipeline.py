import csv
import gzip
import os
import re
from datetime import datetime, timedelta, timezone

import pytest

from app import loader
from app.metadata import ObjectConfig
from app.orchestrator import build_soql_query, parse_sf_datetime, to_soql_datetime
from app.pipeline import IncrementalPipeline, build_plan, chunk_fields, run_objects, to_text

DESCRIBE = [
    {"name": "Id", "type": "id"},
    {"name": "Name", "type": "string"},
    {"name": "Amount", "type": "currency"},
    {"name": "IsDeleted", "type": "boolean"},
    {"name": "SystemModstamp", "type": "datetime"},
    {"name": "BillingAddress", "type": "address"},
]


@pytest.fixture(autouse=True)
def fast_retries(monkeypatch):
    monkeypatch.setattr(loader, "RETRY_DELAY", 0)


class FakeDb:
    """Records SQL and 'loads' the CSV files the pipeline PUTs, so tests can inspect them."""

    def __init__(self, columns=None):
        self.columns = columns or []
        self.sql = []
        self.copies = []          # (table, columns, rows)
        self.removed_dirs = []
        self.watermark = None
        self._pending = {}

    def execute(self, sql, params=None):
        self.sql.append((" ".join(sql.split()), params))
        return 0

    def put_file(self, path, stage_dir):
        with gzip.open(path, "rt", encoding="utf-8", newline="") as handle:
            self._pending[(stage_dir, os.path.basename(path))] = [
                [None if v == r"\N" else v for v in row] for row in csv.reader(handle)]

    def copy_csv(self, table, columns, stage_dir, file_name):
        self.copies.append((table, list(columns), self._pending.pop((stage_dir, file_name))))

    def remove_stage_dir(self, stage_dir):
        self.removed_dirs.append(stage_dir)

    def fetch_one(self, sql, params=None):
        sql = " ".join(sql.split())
        if "FROM CDC_WATERMARK" in sql:
            return (self.watermark,) if self.watermark else None
        return (0,)

    def fetch_all(self, sql, params=None):
        if "GROUP BY CHANGE_TYPE" in sql:
            return [("INSERT", 2), ("UPDATE", 1), ("DELETE", 1)]
        return []

    def table_columns(self, table):
        return self.columns

    def all_sql(self):
        return "\n".join(s for s, _ in self.sql)

    def rows_for(self, table_prefix):
        return [r for t, _, rows in self.copies if t.startswith(table_prefix) for r in rows]


class FakeSf:
    def __init__(self, records, fields=DESCRIBE):
        self.records, self.fields = records, fields
        self.queries = []
        self.estimate = None

    def describe_fields(self, _name):
        return self.fields

    def count(self, obj, where="", include_deleted=False):
        return self.estimate if self.estimate is not None else len(self.records)

    def query_ids(self, obj, where="", include_deleted=False):
        yield from sorted(r["Id"] for r in self.records)

    def _in_range(self, soql):
        lo = re.search(r"Id >= '(\w+)'", soql)
        hi = re.search(r"Id < '(\w+)'", soql)
        return [r for r in self.records
                if (not lo or r["Id"] >= lo.group(1)) and (not hi or r["Id"] < hi.group(1))]

    def query_iter(self, soql, include_deleted=False):
        self.queries.append((soql, include_deleted))
        yield from self._in_range(soql)

    def bulk_download(self, obj, soql, directory, include_deleted=False, max_records=50000):
        self.queries.append((soql, include_deleted))
        cols = soql[len("SELECT "):soql.index(" FROM ")].split(", ")
        path = os.path.join(directory, f"bulk_{len(self.queries)}.csv")
        with open(path, "w", newline="", encoding="utf-8") as handle:
            writer = csv.writer(handle)
            writer.writerow(cols)
            for r in self._in_range(soql):
                writer.writerow(["" if r.get(c) is None else
                                 ("true" if r[c] is True else "false" if r[c] is False else r[c]) for c in cols])
        return [path]


RECORDS = [
    {"Id": "001000000000001", "Name": "A", "Amount": 1.5, "IsDeleted": False, "SystemModstamp": "2024-05-01T10:00:00.000+0000"},
    {"Id": "001000000000002", "Name": "B,\"quoted\"\nline", "Amount": None, "IsDeleted": True, "SystemModstamp": "2024-05-02T11:30:00.123+0000"},
]


def run_one(db, sf, config=None, **kwargs):
    return IncrementalPipeline(config or ObjectConfig("Account"), sf, db, "run1", log=lambda m: None, **kwargs).run()


# ---- queries & values -----------------------------------------------------------
def test_soql_has_watermark_filter_and_ordering():
    q = build_soql_query("Account", ["Id", "Name"], "2024-01-01T00:00:00.000Z")
    assert q == "SELECT Id, Name FROM Account WHERE SystemModstamp > 2024-01-01T00:00:00.000Z ORDER BY SystemModstamp ASC"
    assert "WHERE" not in build_soql_query("Account", ["Id"], None)


def test_datetime_roundtrip():
    dt = parse_sf_datetime("2024-05-02T11:30:00.123+0000")
    assert dt == datetime(2024, 5, 2, 11, 30, 0, 123000, tzinfo=timezone.utc)
    assert to_soql_datetime(dt) == "2024-05-02T11:30:00.123Z"
    assert parse_sf_datetime("2024-05-02T11:30:00Z").hour == 11


def test_to_text_normalises_values():
    assert to_text(True, "boolean") == "true"
    assert to_text(None, "string") is None
    assert to_text("2024-05-02T11:30:00.123+0000", "datetime") == "2024-05-02T11:30:00.123+00:00"
    assert to_text(3, "int") == "3"


# ---- planning -----------------------------------------------------------------
def test_plan_skips_compound_fields_and_finds_watermark():
    plan = build_plan(ObjectConfig("Account"), DESCRIBE)
    assert "BillingAddress" not in plan.fields
    assert plan.watermark_field == "SystemModstamp" and plan.has_is_deleted


def test_plan_without_systemmodstamp_or_isdeleted():
    share = [{"name": "Id", "type": "id"}, {"name": "LastModifiedDate", "type": "datetime"}]
    plan = build_plan(ObjectConfig("OpportunityShare"), share)
    assert plan.watermark_field == "LastModifiedDate" and not plan.has_is_deleted


def test_plan_field_restriction_keeps_cdc_fields_and_rejects_unknown():
    plan = build_plan(ObjectConfig("Account", fields=["Name"]), DESCRIBE)
    assert plan.fields == ["Name", "Id", "SystemModstamp", "IsDeleted"]
    with pytest.raises(ValueError, match="unknown field"):
        build_plan(ObjectConfig("Account", fields=["Nope"]), DESCRIBE)


def test_wide_objects_split_into_column_groups_without_losing_columns():
    fields = ["Id", "SystemModstamp"] + [f"Field_{i}__c" for i in range(40)]
    groups = chunk_fields(fields, ["Id", "SystemModstamp"], max_chars=200)
    assert len(groups) > 1
    assert all(g[:2] == ["Id", "SystemModstamp"] for g in groups)
    assert sorted({f for g in groups for f in g}) == sorted(fields)
    assert all(len(", ".join(g)) <= 200 for g in groups)


# ---- a normal run -------------------------------------------------------------
def test_first_run_creates_table_loads_files_merges_and_sets_watermark():
    db, sf = FakeDb(), FakeSf(RECORDS)
    result = run_one(db, sf)
    sql = db.all_sql()

    assert "CREATE TABLE ACCOUNT" in sql and '"AMOUNT" FLOAT' in sql and '"ISDELETED" BOOLEAN' in sql
    assert "CREATE OR REPLACE TRANSIENT TABLE CDC_STG_ACCOUNT_run1" in sql
    assert sf.queries[0][1] is True                              # queryAll -> soft deletes included
    assert "WHERE" not in sf.queries[0][0]                       # no watermark yet = full load

    table, cols, rows = db.copies[0]
    assert table == "CDC_STG_ACCOUNT_run1" and cols[0] == "Id"
    assert len(rows) == 2 and rows[1][cols.index("Name")] == 'B,"quoted"\nline'   # CSV quoting survives
    assert rows[1][cols.index("Amount")] is None                                  # NULL survives
    assert rows[0][cols.index("SystemModstamp")] == "2024-05-01T10:00:00.000+00:00"

    assert "MERGE INTO ACCOUNT" in sql and "QUALIFY ROW_NUMBER()" in sql and "INSERT INTO CDC_CHANGE_LOG" in sql
    assert (result["inserted"], result["updated"], result["deleted"]) == (2, 1, 1)
    assert [p for s, p in db.sql if s.startswith("UPDATE CDC_RUN_LOG")][0][0] == "SUCCESS"


def test_watermark_is_run_start_minus_overlap_not_max_seen(monkeypatch):
    monkeypatch.setenv("CDC_OVERLAP_SECONDS", "300")
    db = FakeDb()
    before = datetime.now(timezone.utc)
    run_one(db, FakeSf(RECORDS))
    value = [p for s, p in db.sql if "MERGE INTO CDC_WATERMARK" in s][0][2]
    stamp = parse_sf_datetime(value)
    assert before - timedelta(seconds=301) <= stamp <= before - timedelta(seconds=299) + timedelta(seconds=5)
    assert stamp.year > 2024          # i.e. NOT the 2024 SystemModstamp of the rows


def test_watermark_advances_even_when_nothing_changed():
    db = FakeDb()
    run_one(db, FakeSf([]))
    assert any("MERGE INTO CDC_WATERMARK" in s for s, _ in db.sql)
    assert "MERGE INTO ACCOUNT" not in db.all_sql()


def test_incremental_run_uses_stored_watermark_and_existing_table():
    db = FakeDb(columns=["ID", "NAME", "AMOUNT", "ISDELETED", "SYSTEMMODSTAMP"])
    db.watermark = "2024-05-01T00:00:00.000Z"
    sf = FakeSf(RECORDS)
    run_one(db, sf)
    assert "WHERE SystemModstamp > 2024-05-01T00:00:00.000Z" in sf.queries[0][0]
    assert "CREATE TABLE ACCOUNT" not in db.all_sql()


def test_merge_never_overwrites_a_newer_row_and_ignores_reread_rows_in_the_change_log():
    db = FakeDb(columns=["ID", "NAME", "AMOUNT", "ISDELETED", "SYSTEMMODSTAMP"])
    run_one(db, FakeSf(RECORDS))
    sql = db.all_sql()
    assert "WHEN MATCHED AND" in sql and "TRY_TO_TIMESTAMP_TZ" in sql
    change_insert = [s for s, _ in db.sql if s.startswith("INSERT INTO CDC_CHANGE_LOG")][0]
    assert " > TRY_TO_TIMESTAMP_TZ(t." in change_insert           # only strictly newer rows are logged


def test_temporary_objects_are_cleaned_up_even_on_failure():
    class Boom(FakeSf):
        def query_iter(self, soql, include_deleted=False):
            raise ValueError("INVALID_FIELD")
            yield

    db = FakeDb()
    with pytest.raises(ValueError):
        run_one(db, Boom([]))
    assert "DROP TABLE IF EXISTS CDC_STG_ACCOUNT_run1" in db.all_sql()
    assert db.removed_dirs == ["@~/cdc/run1/ACCOUNT/"]
    assert "MERGE INTO CDC_WATERMARK" not in db.all_sql()          # watermark untouched
    finish = [p for s, p in db.sql if s.startswith("UPDATE CDC_RUN_LOG")][0]
    assert finish[0] == "FAILED" and "INVALID_FIELD" in finish[-3]


# ---- schema evolution ----------------------------------------------------------
def test_existing_table_gets_missing_columns_added():
    db = FakeDb(columns=["ID", "NAME", "ISDELETED", "SYSTEMMODSTAMP"])
    run_one(db, FakeSf(RECORDS))
    sql = db.all_sql()
    assert 'ALTER TABLE ACCOUNT ADD COLUMN IF NOT EXISTS "AMOUNT" FLOAT' in sql
    assert '"AMOUNT"' in sql.split("MERGE INTO ACCOUNT")[1]


def test_missing_columns_skipped_when_schema_evolution_disabled(monkeypatch):
    monkeypatch.setenv("CDC_ADD_MISSING_COLUMNS", "false")
    db = FakeDb(columns=["ID", "NAME", "ISDELETED", "SYSTEMMODSTAMP"])
    run_one(db, FakeSf(RECORDS))
    assert "ALTER TABLE" not in db.all_sql()
    assert '"AMOUNT"' not in db.all_sql().split("MERGE INTO ACCOUNT")[1]


# ---- scale: partitions, column groups, bulk, retries --------------------------------
def make_records(n):
    return [{"Id": f"001{i:012d}", "Name": f"N{i}", "Amount": float(i), "IsDeleted": False,
             "SystemModstamp": "2024-05-01T10:00:00.000+0000"} for i in range(n)]


def test_big_objects_are_split_by_id_range_and_every_row_loaded_exactly_once(monkeypatch):
    monkeypatch.setenv("CDC_PARTITION_ROWS", "10")
    records = make_records(25)
    db, sf = FakeDb(), FakeSf(records)
    result = run_one(db, sf)

    ranged = [q for q, _ in sf.queries if "Id <" in q or "Id >=" in q]
    assert len(sf.queries) == 3 and len(ranged) == 3             # 25 rows / 10 per partition
    loaded = [r[0] for r in db.rows_for("CDC_STG_ACCOUNT_run1")]
    assert sorted(loaded) == sorted(r["Id"] for r in records)    # nothing lost, nothing duplicated
    assert result["extracted"] == 25


def test_objects_at_or_below_the_threshold_are_not_split(monkeypatch):
    monkeypatch.setenv("CDC_PARTITION_ROWS", "10")
    sf = FakeSf(make_records(10))
    run_one(FakeDb(), sf)
    assert len(sf.queries) == 1 and "Id >=" not in sf.queries[0][0]


def test_wide_object_column_groups_are_loaded_separately_and_joined(monkeypatch):
    monkeypatch.setattr("app.pipeline.MAX_SOQL_CHARS", 90)
    fields = DESCRIBE[:5] + [{"name": f"Extra_{i}__c", "type": "string"} for i in range(12)]
    records = [dict(r, **{f"Extra_{i}__c": "x" for i in range(12)}) for r in RECORDS]
    db, sf = FakeDb(), FakeSf(records, fields)
    run_one(db, sf)

    assert len(sf.queries) > 1                                   # several column-group queries
    group_tables = {t for t, _, _ in db.copies}
    assert "CDC_STG_ACCOUNT_run1" in group_tables and "CDC_STG_ACCOUNT_run1_P1" in group_tables
    loaded_cols = {c.upper() for _, cols, _ in db.copies for c in cols}
    assert {f"EXTRA_{i}__C" for i in range(12)} <= loaded_cols   # every column made it
    assert "MERGE INTO CDC_STG_ACCOUNT_run1 s USING" in db.all_sql()


def test_bulk_strategy_reads_csv_and_normalises_values():
    sf = FakeSf(RECORDS)
    db = FakeDb()
    run_one(db, sf, ObjectConfig("Account", load_strategy="bulk"))
    _, cols, rows = db.copies[0]
    assert rows[1][cols.index("Amount")] is None                 # empty cell -> NULL
    assert rows[0][cols.index("SystemModstamp")] == "2024-05-01T10:00:00.000+00:00"
    assert rows[1][cols.index("IsDeleted")] == "true"


def test_auto_strategy_switches_to_bulk_for_large_loads(monkeypatch):
    monkeypatch.setenv("CDC_BULK_THRESHOLD", "5")
    logs = []
    IncrementalPipeline(ObjectConfig("Account"), FakeSf(make_records(8)), FakeDb(), "r", log=logs.append).run()
    assert any("via BULK" in m for m in logs)


def test_bulk_failure_falls_back_to_rest():
    class NoBulk(FakeSf):
        def bulk_download(self, *a, **k):
            raise RuntimeError("Bulk API not enabled")

    db = FakeDb()
    result = run_one(db, NoBulk(RECORDS), ObjectConfig("Account", load_strategy="bulk"))
    assert result["extracted"] == 2


def test_transient_errors_are_retried_permanent_ones_are_not():
    calls = {"n": 0}

    class Flaky(FakeSf):
        def query_iter(self, soql, include_deleted=False):
            calls["n"] += 1
            if calls["n"] == 1:
                raise ConnectionError("reset by peer")
            yield from self.records

    assert run_one(FakeDb(), Flaky(RECORDS))["extracted"] == 2 and calls["n"] == 2


def test_concurrent_salesforce_requests_are_capped(monkeypatch):
    import threading, time
    monkeypatch.setenv("CDC_PARTITION_ROWS", "5")
    monkeypatch.setenv("CDC_SF_CONCURRENCY", "2")
    active, peak, lock = [0], [0], threading.Lock()

    class Slow(FakeSf):
        def query_iter(self, soql, include_deleted=False):
            with lock:
                active[0] += 1
                peak[0] = max(peak[0], active[0])
            time.sleep(0.05)
            rows = list(self._in_range(soql))
            with lock:
                active[0] -= 1
            yield from rows

    run_one(FakeDb(), Slow(make_records(30)))
    assert 1 < peak[0] <= 2          # parallel, but never above the cap


# ---- hard deletes -----------------------------------------------------------------
def test_objects_without_isdeleted_reconcile_deletes_by_id_diff():
    fields = [{"name": "Id", "type": "id"}, {"name": "Name", "type": "string"},
              {"name": "SystemModstamp", "type": "datetime"}]
    recs = [{"Id": "001000000000001", "Name": "A", "SystemModstamp": "2024-05-01T10:00:00.000+0000"}]
    db = FakeDb()
    run_one(db, FakeSf(recs, fields), ObjectConfig("UserRole"))
    assert any(t.startswith("CDC_IDS_USERROLE") for t, _, _ in db.copies)
    sql = db.all_sql()
    assert "DELETE FROM USERROLE WHERE" in sql and "NOT IN (SELECT ID FROM CDC_IDS_USERROLE_run1)" in sql


def test_reconcile_refuses_to_wipe_a_table_when_salesforce_returns_no_ids():
    class TableHasRows(FakeDb):
        def fetch_one(self, sql, params=None):
            return (5,) if "COUNT(*) FROM USERROLE" in " ".join(sql.split()) else super().fetch_one(sql, params)

    fields = [{"name": "Id", "type": "id"}, {"name": "SystemModstamp", "type": "datetime"}]
    db = TableHasRows()
    with pytest.raises(RuntimeError, match="Refusing to delete everything"):
        run_one(db, FakeSf([], fields), ObjectConfig("UserRole"))
    assert "DELETE FROM USERROLE" not in db.all_sql()


# ---- many objects ---------------------------------------------------------------------
def test_one_failing_object_does_not_stop_the_others():
    class Selective(FakeSf):
        def describe_fields(self, name):
            if name == "Bad__c":
                raise RuntimeError("INVALID_TYPE")
            return DESCRIBE

    summary = run_objects(
        [ObjectConfig("Bad__c"), ObjectConfig("Account")], Selective(RECORDS), FakeDb(), log=lambda m: None
    )
    assert [r["status"] for r in summary.results] == ["FAILED", "SUCCESS"]     # input order kept
    assert summary.failed == 1


def test_objects_run_in_parallel_and_all_complete():
    summary = run_objects([ObjectConfig(n) for n in ("Account", "Contact", "Lead", "Task")],
                          FakeSf(RECORDS), FakeDb(), log=lambda m: None, workers=3)
    assert [r["object"] for r in summary.results] == ["Account", "Contact", "Lead", "Task"]
    assert summary.failed == 0
