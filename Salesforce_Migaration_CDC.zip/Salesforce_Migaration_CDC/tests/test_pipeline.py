from datetime import datetime, timezone

import pytest

from app.metadata import ObjectConfig
from app.orchestrator import build_soql_query, parse_sf_datetime, to_soql_datetime
from app.pipeline import IncrementalPipeline, build_plan, run_objects, to_text

DESCRIBE = [
    {"name": "Id", "type": "id"},
    {"name": "Name", "type": "string"},
    {"name": "Amount", "type": "currency"},
    {"name": "IsDeleted", "type": "boolean"},
    {"name": "SystemModstamp", "type": "datetime"},
    {"name": "BillingAddress", "type": "address"},
]


class FakeDb:
    def __init__(self, columns=None):
        self.columns = columns or []
        self.sql = []
        self.batches = []
        self.watermark = None

    def execute(self, sql, params=None):
        self.sql.append((" ".join(sql.split()), params))
        return 0

    def executemany(self, sql, rows):
        self.batches.append((sql, list(rows)))

    def fetch_one(self, sql, params=None):
        sql = " ".join(sql.split())
        if "FROM CDC_WATERMARK" in sql:
            return (self.watermark,) if self.watermark else None
        if "STATUS = 'RUNNING'" in sql:
            return (0,)
        return (0,)

    def fetch_all(self, sql, params=None):
        if "GROUP BY CHANGE_TYPE" in sql:
            return [("INSERT", 2), ("UPDATE", 1), ("DELETE", 1)]
        return []

    def table_columns(self, table):
        return self.columns

    def all_sql(self):
        return "\n".join(s for s, _ in self.sql)


class FakeSf:
    def __init__(self, records, fields=DESCRIBE):
        self.records, self.fields = records, fields
        self.queries = []

    def describe_fields(self, _name):
        return self.fields

    def query_iter(self, soql, include_deleted=False):
        self.queries.append((soql, include_deleted))
        yield from self.records


RECORDS = [
    {"Id": "001A", "Name": "A", "Amount": 1.5, "IsDeleted": False, "SystemModstamp": "2024-05-01T10:00:00.000+0000"},
    {"Id": "001B", "Name": "B", "Amount": None, "IsDeleted": True, "SystemModstamp": "2024-05-02T11:30:00.123+0000"},
]


def test_soql_has_watermark_filter_and_ordering():
    q = build_soql_query("Account", ["Id", "Name"], "2024-01-01T00:00:00.000Z")
    assert q == "SELECT Id, Name FROM Account WHERE SystemModstamp > 2024-01-01T00:00:00.000Z ORDER BY SystemModstamp ASC"
    assert "WHERE" not in build_soql_query("Account", ["Id"], None)


def test_datetime_roundtrip():
    dt = parse_sf_datetime("2024-05-02T11:30:00.123+0000")
    assert dt == datetime(2024, 5, 2, 11, 30, 0, 123000, tzinfo=timezone.utc)
    assert to_soql_datetime(dt) == "2024-05-02T11:30:00.123Z"
    assert parse_sf_datetime("2024-05-02T11:30:00Z").hour == 11


def test_to_text_normalises_values():
    assert to_text(True, "boolean") == "true"
    assert to_text(None, "string") is None
    assert to_text("2024-05-02T11:30:00.123+0000", "datetime") == "2024-05-02T11:30:00.123+00:00"
    assert to_text(3, "int") == "3"


def test_plan_skips_compound_fields_and_finds_watermark():
    plan = build_plan(ObjectConfig("Account"), DESCRIBE)
    assert "BillingAddress" not in plan.fields
    assert plan.watermark_field == "SystemModstamp" and plan.has_is_deleted


def test_plan_without_systemmodstamp_or_isdeleted():
    share = [{"name": "Id", "type": "id"}, {"name": "LastModifiedDate", "type": "datetime"}]
    plan = build_plan(ObjectConfig("OpportunityShare"), share)
    assert plan.watermark_field == "LastModifiedDate" and not plan.has_is_deleted


def test_plan_field_restriction_keeps_cdc_fields_and_rejects_unknown():
    plan = build_plan(ObjectConfig("Account", fields=["Name"]), DESCRIBE)
    assert plan.fields == ["Name", "Id", "SystemModstamp", "IsDeleted"]
    with pytest.raises(ValueError, match="unknown field"):
        build_plan(ObjectConfig("Account", fields=["Nope"]), DESCRIBE)


def test_first_run_creates_table_loads_merges_and_advances_watermark():
    db, sf = FakeDb(), FakeSf(RECORDS)
    result = IncrementalPipeline(ObjectConfig("Account"), sf, db, "run1", log=lambda m: None).run()
    sql = db.all_sql()

    assert "CREATE TABLE ACCOUNT" in sql and '"AMOUNT" FLOAT' in sql and '"ISDELETED" BOOLEAN' in sql
    assert sf.queries[0][1] is True                       # queryAll -> soft deletes included
    assert "WHERE" not in sf.queries[0][0]                # no watermark yet = full load
    assert len(db.batches[0][1]) == 2
    assert "MERGE INTO ACCOUNT" in sql and "QUALIFY ROW_NUMBER()" in sql
    assert "INSERT INTO CDC_CHANGE_LOG" in sql
    wm = [p for s, p in db.sql if "MERGE INTO CDC_WATERMARK" in s][0]
    assert wm == ("Account", "SystemModstamp", "2024-05-02T11:30:00.123Z")
    assert result["inserted"] == 2 and result["updated"] == 1 and result["deleted"] == 1
    finish = [p for s, p in db.sql if s.startswith("UPDATE CDC_RUN_LOG")][0]
    assert finish[0] == "SUCCESS"


def test_incremental_run_uses_stored_watermark():
    db, sf = FakeDb(columns=["ID", "NAME", "AMOUNT", "ISDELETED", "SYSTEMMODSTAMP"]), FakeSf(RECORDS)
    db.watermark = "2024-05-01T00:00:00.000Z"
    IncrementalPipeline(ObjectConfig("Account"), sf, db, "run2", log=lambda m: None).run()
    assert "WHERE SystemModstamp > 2024-05-01T00:00:00.000Z" in sf.queries[0][0]
    assert "CREATE TABLE ACCOUNT" not in db.all_sql()     # existing table reused


def test_existing_table_gets_missing_columns_added():
    db = FakeDb(columns=["ID", "NAME", "ISDELETED", "SYSTEMMODSTAMP"])
    IncrementalPipeline(ObjectConfig("Account"), FakeSf(RECORDS), db, "r", log=lambda m: None).run()
    sql = db.all_sql()
    assert 'ALTER TABLE ACCOUNT ADD COLUMN IF NOT EXISTS "AMOUNT" FLOAT' in sql
    assert '"AMOUNT"' in sql.split("MERGE INTO ACCOUNT")[1]      # ...and the new column is loaded


def test_missing_columns_skipped_when_schema_evolution_disabled(monkeypatch):
    monkeypatch.setenv("CDC_ADD_MISSING_COLUMNS", "false")
    db = FakeDb(columns=["ID", "NAME", "ISDELETED", "SYSTEMMODSTAMP"])
    IncrementalPipeline(ObjectConfig("Account"), FakeSf(RECORDS), db, "r", log=lambda m: None).run()
    assert "ALTER TABLE" not in db.all_sql()
    assert '"AMOUNT"' not in db.all_sql().split("MERGE INTO ACCOUNT")[1]


def test_wide_objects_are_fetched_in_column_groups_and_rejoined():
    from app.pipeline import chunk_fields
    fields = ["Id", "SystemModstamp"] + [f"Field_{i}__c" for i in range(40)]
    groups = chunk_fields(fields, ["Id", "SystemModstamp"], max_chars=200)
    assert len(groups) > 1
    assert all(g[:2] == ["Id", "SystemModstamp"] for g in groups)
    assert sorted({f for g in groups for f in g}) == sorted(fields)       # no column lost
    assert all(len(", ".join(g)) <= 200 for g in groups)


def test_failure_is_logged_and_does_not_advance_watermark():
    class Boom(FakeSf):
        def query_iter(self, soql, include_deleted=False):
            raise RuntimeError("API limit")
            yield

    db = FakeDb()
    with pytest.raises(RuntimeError):
        IncrementalPipeline(ObjectConfig("Account"), Boom([]), db, "r", log=lambda m: None).run()
    assert "MERGE INTO CDC_WATERMARK" not in db.all_sql()
    finish = [p for s, p in db.sql if s.startswith("UPDATE CDC_RUN_LOG")][0]
    assert finish[0] == "FAILED" and "API limit" in finish[-3]


def test_one_failing_object_does_not_stop_the_others():
    class Selective(FakeSf):
        def describe_fields(self, name):
            if name == "Bad__c":
                raise RuntimeError("INVALID_TYPE")
            return DESCRIBE

    summary = run_objects(
        [ObjectConfig("Bad__c"), ObjectConfig("Account")], Selective(RECORDS), FakeDb(), log=lambda m: None
    )
    assert [r["status"] for r in summary.results] == ["FAILED", "SUCCESS"]
    assert summary.failed == 1
