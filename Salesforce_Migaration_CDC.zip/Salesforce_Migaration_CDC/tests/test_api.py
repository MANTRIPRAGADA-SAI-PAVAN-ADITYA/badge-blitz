import json

import pytest
from fastapi.testclient import TestClient

from app import api
from tests.fakes import FakeDb, FakeRunner, FakeService


@pytest.fixture
def client(tmp_path):
    path = tmp_path / "objects.json"
    path.write_text(json.dumps({"objects": [
        {"object_name": "Account", "target_table": "ACCOUNT", "enabled": True, "fields": [], "note": ""},
        {"object_name": "Contact", "target_table": "CONTACT", "enabled": False, "fields": [], "note": ""}]}))
    api.state.db, api.state.service, api.state.runner = FakeDb(), FakeService(path), FakeRunner()
    yield TestClient(api.app)
    api.state.db = api.state.service = api.state.runner = None


def test_requires_connection_before_use():
    api.state.service = None
    assert TestClient(api.app).get("/api/objects").status_code == 409


def test_status_reports_session(client):
    body = client.get("/api/status").json()
    assert body["connected"] is True and body["session"]["schema"] == "SCRATCH"


def test_add_enable_remove_object(client):
    assert client.post("/api/objects", json={"object_name": "Case"}).json()["target_table"] == "CASE"
    assert client.post("/api/objects", json={"object_name": "Case"}).status_code == 400          # duplicate
    assert client.post("/api/objects", json={"object_name": "Nope__c"}).status_code == 400       # not in Salesforce
    assert client.post("/api/objects", json={"object_name": "x; DROP"}).status_code == 400       # injection-shaped
    assert client.post("/api/objects", json={"object_name": "Account2", "fields": ["Bogus"]}).status_code == 400
    client.patch("/api/objects/Contact", json={"enabled": True})
    assert {o["object_name"]: o["enabled"] for o in client.get("/api/objects").json()}["Contact"] is True
    client.delete("/api/objects/Case")
    assert "Case" not in [o["object_name"] for o in client.get("/api/objects").json()]


def test_run_starts_only_requested_objects_and_blocks_second_run(client):
    body = client.post("/api/run", json={"objects": ["Contact"], "full_refresh": True}).json()
    assert api.state.runner.started_with == (["Contact"], True, False)
    assert body["summary"]["run_id"] == "demo123"
    api.state.runner.running = True
    assert client.post("/api/run", json={}).status_code == 409


def test_run_defaults_to_enabled_objects(client):
    client.post("/api/run", json={})
    assert api.state.runner.started_with[0] == ["Account"]


def test_monitoring_and_investigation_endpoints(client):
    assert client.get("/api/summary?hours=24").json()["totals"]["inserted"] == 10
    assert {h["state"] for h in client.get("/api/health").json()} == {"healthy", "failing"}
    assert len(client.get("/api/runs?status=FAILED").json()) == 1
    assert client.get("/api/runs/demo123/events?object=Account").json()[0]["message"].startswith("[Account]")
    assert client.get("/api/records/Account/0015000000AbCdE/compare").json()["differences"] == 1
    assert client.get("/api/objects/Account/columns").json()["missing"] == 1
    assert client.get("/api/objects/Account/count-compare").json()["in_sync"] is True


def test_load_strategy_can_be_set_and_is_validated(client):
    assert client.post("/api/objects", json={"object_name": "Case", "load_strategy": "bulk"}).json()["load_strategy"] == "bulk"
    assert client.post("/api/objects", json={"object_name": "Lead", "load_strategy": "turbo"}).status_code == 400
    assert client.patch("/api/objects/Contact", json={"load_strategy": "rest"}).json()["load_strategy"] == "rest"
    assert client.patch("/api/objects/Contact", json={"load_strategy": "turbo"}).status_code == 400


def test_log_search_passes_filters_and_levels(client):
    body = client.get("/api/logs?hours=72&level=WARN,ERROR&object=Contact&q=invalid&limit=50").json()
    assert [r["object_name"] for r in body] == ["Contact"]
    assert api.state.service.last_search == dict(hours=72, run_id=None, object_name="Contact",
                                                 levels=["WARN", "ERROR"], text="invalid", limit=50)


def test_run_state_exposes_structured_events(client):
    client.post("/api/run", json={})
    events = client.get("/api/run").json()["events"]
    assert {e["level"] for e in events} == {"INFO", "WARN"} and "task 1/2 done" in events[0]["message"]
