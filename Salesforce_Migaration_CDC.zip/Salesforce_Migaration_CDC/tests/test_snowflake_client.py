from app.snowflake_client import SnowflakeClient


def test_table_columns_uppercases_and_binds_table_name():
    client = SnowflakeClient.__new__(SnowflakeClient)
    seen = {}

    def fake_fetch_all(sql, params=None):
        seen["params"] = params
        return [("id",), ("Name",)]

    client.fetch_all = fake_fetch_all

    assert client.table_columns("account") == ["ID", "NAME"]
    assert seen["params"] == ("ACCOUNT",)
