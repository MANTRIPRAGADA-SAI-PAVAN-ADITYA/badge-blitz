from config.settings import SalesforceConfig, SnowflakeConfig


def test_salesforce_config_detects_token_auth(monkeypatch):
    monkeypatch.setenv("SF_USERNAME", "user@example.com")
    monkeypatch.setenv("SF_ACCESS_TOKEN", "token-123")
    monkeypatch.setenv("SF_INSTANCE_URL", "https://mydomain.my.salesforce.com")
    monkeypatch.delenv("SF_PASSWORD", raising=False)

    config = SalesforceConfig()

    assert config.has_api_credentials() is True
    assert config.uses_token_auth() is True


def test_snowflake_config_allows_externalbrowser_auth(monkeypatch):
    monkeypatch.setenv("SNOWFLAKE_ACCOUNT", "demo")
    monkeypatch.setenv("SNOWFLAKE_USER", "user")
    monkeypatch.setenv("SNOWFLAKE_AUTHENTICATOR", "externalbrowser")
    monkeypatch.delenv("SNOWFLAKE_PASSWORD", raising=False)

    config = SnowflakeConfig()

    assert config.can_connect() is True
    assert config.uses_browser_sso() is True


def test_salesforce_config_detects_client_credentials_auth(monkeypatch):
    monkeypatch.setenv("SF_CLIENT_ID", "consumer-key")
    monkeypatch.setenv("SF_CLIENT_SECRET", "consumer-secret")
    monkeypatch.setenv("SF_LOGIN_URL", "https://test.salesforce.com")
    monkeypatch.delenv("SF_PASSWORD", raising=False)
    monkeypatch.delenv("SF_ACCESS_TOKEN", raising=False)

    config = SalesforceConfig()

    assert config.uses_client_credentials() is True
    assert config.has_api_credentials() is True
