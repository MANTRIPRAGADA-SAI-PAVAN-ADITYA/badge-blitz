from pathlib import Path

import pandas as pd

from app.salesforce_client import SalesforceClient

sf = SalesforceClient()
account_desc = sf.client.Account.describe()
field_names = [field["name"] for field in account_desc.get("fields", [])]

if not field_names:
    raise ValueError("No Account fields returned from Salesforce describe call.")

chunk_size = 200
combined_rows = []
for i in range(0, len(field_names), chunk_size):
    fields_chunk = field_names[i : i + chunk_size]
    soql = (
        f"SELECT {', '.join(fields_chunk)} FROM Account "
        "WHERE SystemModstamp >= 2026-09-20T00:00:00.000Z "
        "ORDER BY SystemModstamp"
    )
    rows = sf.query(soql)
    combined_rows.extend(rows)

cleaned = [{k: v for k, v in row.items() if k != "attributes"} for row in combined_rows]
out_dir = Path("output")
out_dir.mkdir(exist_ok=True)
df = pd.DataFrame(cleaned)

csv_path = out_dir / "account_demo.csv"
df.to_csv(csv_path, index=False)
print(f"ROWS {len(df)}")
print(f"CSV {csv_path}")

if len(df) <= 1_048_576:
    xlsx_path = out_dir / "account_demo.xlsx"
    df.to_excel(xlsx_path, index=False)
    print(f"XLSX {xlsx_path}")
else:
    print("XLSX_SKIPPED_TOO_LARGE")
