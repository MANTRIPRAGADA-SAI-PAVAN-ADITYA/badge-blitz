"""Scheduled / CLI entry point.  ``python -m app.main --help``

The Azure pipeline calls this on a schedule; the Streamlit UI calls the same
``run_objects`` function for manual runs, so both behave identically.
"""
from __future__ import annotations

import argparse
import getpass
import sys
from typing import List, Optional

from app.metadata import ObjectRegistry
from app.pipeline import run_objects
from app.salesforce_client import SalesforceClient
from app.snowflake_client import SnowflakeClient
from config.settings import CONFIG


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Salesforce -> Snowflake incremental CDC")
    parser.add_argument("--objects", help="Comma-separated object names (default: all enabled)")
    parser.add_argument("--full-refresh", action="store_true", help="Ignore watermarks and reload everything")
    parser.add_argument("--reconcile", action="store_true", help="Also detect hard deletes via ID diff")
    parser.add_argument("--trigger", default="scheduled", choices=["scheduled", "manual"])
    args = parser.parse_args(argv)

    if not CONFIG.salesforce.has_api_credentials():
        print("Salesforce authentication is not configured (see .env.example).")
        return 2
    if not CONFIG.snowflake.can_connect():
        print("Snowflake authentication is not configured (see .env.example).")
        return 2

    db = SnowflakeClient()
    try:
        registry = ObjectRegistry(db)
        configs = registry.list(enabled_only=True)
        if args.objects:
            wanted = {n.strip().lower() for n in args.objects.split(",") if n.strip()}
            configs = [c for c in registry.list() if c.object_name.lower() in wanted]
        if not configs:
            print("No objects enabled. Enable some in the UI (Objects tab) or config/objects.json.")
            return 0

        summary = run_objects(
            configs, SalesforceClient(), db,
            trigger=args.trigger, user=getpass.getuser(),
            full_refresh=args.full_refresh, reconcile=args.reconcile,
        )
        print(f"Run {summary.run_id}: {len(summary.results)} objects, {summary.failed} failed")
        return 1 if summary.failed else 0
    finally:
        db.close()


if __name__ == "__main__":
    sys.exit(main())
