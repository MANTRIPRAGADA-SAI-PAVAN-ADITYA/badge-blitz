"""Control tables: watermark, run log and change log (all in the current schema).

These are what the Streamlit monitor reads, so every run - scheduled or manual -
leaves a complete, queryable trail.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from app.snowflake_client import SnowflakeClient

DDL = [
    """
    CREATE TABLE IF NOT EXISTS CDC_WATERMARK (
        OBJECT_NAME      VARCHAR NOT NULL,
        WATERMARK_FIELD  VARCHAR,
        LAST_VALUE       VARCHAR,
        UPDATED_AT       TIMESTAMP_LTZ DEFAULT CURRENT_TIMESTAMP()
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS CDC_RUN_LOG (
        RUN_ID          VARCHAR NOT NULL,
        OBJECT_NAME     VARCHAR NOT NULL,
        TRIGGER_TYPE    VARCHAR,
        TRIGGERED_BY    VARCHAR,
        STARTED_AT      TIMESTAMP_LTZ,
        ENDED_AT        TIMESTAMP_LTZ,
        STATUS          VARCHAR,
        ROWS_EXTRACTED  NUMBER DEFAULT 0,
        ROWS_INSERTED   NUMBER DEFAULT 0,
        ROWS_UPDATED    NUMBER DEFAULT 0,
        ROWS_DELETED    NUMBER DEFAULT 0,
        WATERMARK_FROM  VARCHAR,
        WATERMARK_TO    VARCHAR,
        ERROR_MESSAGE   VARCHAR
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS CDC_RUN_EVENTS (
        RUN_ID       VARCHAR NOT NULL,
        EVENT_TS     TIMESTAMP_LTZ DEFAULT CURRENT_TIMESTAMP(),
        OBJECT_NAME  VARCHAR,
        MESSAGE      VARCHAR
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS CDC_CHANGE_LOG (
        RUN_ID       VARCHAR NOT NULL,
        OBJECT_NAME  VARCHAR NOT NULL,
        RECORD_ID    VARCHAR NOT NULL,
        CHANGE_TYPE  VARCHAR NOT NULL,   -- INSERT / UPDATE / DELETE
        CHANGE_TS    TIMESTAMP_LTZ DEFAULT CURRENT_TIMESTAMP()
    )
    """,
]


def ensure_control_tables(db: SnowflakeClient) -> None:
    for statement in DDL:
        db.execute(statement)


def get_watermark(db: SnowflakeClient, object_name: str) -> Optional[str]:
    row = db.fetch_one("SELECT LAST_VALUE FROM CDC_WATERMARK WHERE OBJECT_NAME = %s", (object_name,))
    return row[0] if row else None


def set_watermark(db: SnowflakeClient, object_name: str, field: str, value: str) -> None:
    db.execute(
        """
        MERGE INTO CDC_WATERMARK t
        USING (SELECT %s AS OBJECT_NAME, %s AS WATERMARK_FIELD, %s AS LAST_VALUE) s
        ON t.OBJECT_NAME = s.OBJECT_NAME
        WHEN MATCHED THEN UPDATE SET WATERMARK_FIELD = s.WATERMARK_FIELD,
             LAST_VALUE = s.LAST_VALUE, UPDATED_AT = CURRENT_TIMESTAMP()
        WHEN NOT MATCHED THEN INSERT (OBJECT_NAME, WATERMARK_FIELD, LAST_VALUE)
             VALUES (s.OBJECT_NAME, s.WATERMARK_FIELD, s.LAST_VALUE)
        """,
        (object_name, field, value),
    )


def reset_watermark(db: SnowflakeClient, object_name: str) -> None:
    db.execute("DELETE FROM CDC_WATERMARK WHERE OBJECT_NAME = %s", (object_name,))


def start_run(db: SnowflakeClient, run_id: str, object_name: str, trigger: str, user: str, wm_from: Optional[str]) -> None:
    db.execute(
        """
        INSERT INTO CDC_RUN_LOG (RUN_ID, OBJECT_NAME, TRIGGER_TYPE, TRIGGERED_BY, STARTED_AT, STATUS, WATERMARK_FROM)
        VALUES (%s, %s, %s, %s, CURRENT_TIMESTAMP(), 'RUNNING', %s)
        """,
        (run_id, object_name, trigger, user, wm_from),
    )


def finish_run(db: SnowflakeClient, run_id: str, object_name: str, status: str, stats: Dict[str, Any],
               wm_to: Optional[str] = None, error: Optional[str] = None) -> None:
    db.execute(
        """
        UPDATE CDC_RUN_LOG SET ENDED_AT = CURRENT_TIMESTAMP(), STATUS = %s,
            ROWS_EXTRACTED = %s, ROWS_INSERTED = %s, ROWS_UPDATED = %s, ROWS_DELETED = %s,
            WATERMARK_TO = %s, ERROR_MESSAGE = %s
        WHERE RUN_ID = %s AND OBJECT_NAME = %s
        """,
        (status, stats.get("extracted", 0), stats.get("inserted", 0), stats.get("updated", 0),
         stats.get("deleted", 0), wm_to, (error or "")[:4000] or None, run_id, object_name),
    )


def log_event(db: SnowflakeClient, run_id: str, message: str, object_name: Optional[str] = None) -> None:
    """Persist a log line so any past run can be investigated later. Never raises."""
    try:
        db.execute(
            "INSERT INTO CDC_RUN_EVENTS (RUN_ID, OBJECT_NAME, MESSAGE) VALUES (%s, %s, %s)",
            (run_id, object_name, message[:4000]),
        )
    except Exception:  # logging must never break a run
        pass


def recent_runs(db: SnowflakeClient, limit: int = 200) -> List[tuple]:
    return db.fetch_all(
        """
        SELECT RUN_ID, OBJECT_NAME, TRIGGER_TYPE, TRIGGERED_BY, STARTED_AT, ENDED_AT, STATUS,
               ROWS_EXTRACTED, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED,
               WATERMARK_FROM, WATERMARK_TO, ERROR_MESSAGE
        FROM CDC_RUN_LOG ORDER BY STARTED_AT DESC LIMIT %s
        """,
        (limit,),
    )


RUN_LOG_COLUMNS = [
    "RUN_ID", "OBJECT_NAME", "TRIGGER_TYPE", "TRIGGERED_BY", "STARTED_AT", "ENDED_AT", "STATUS",
    "ROWS_EXTRACTED", "ROWS_INSERTED", "ROWS_UPDATED", "ROWS_DELETED",
    "WATERMARK_FROM", "WATERMARK_TO", "ERROR_MESSAGE",
]
