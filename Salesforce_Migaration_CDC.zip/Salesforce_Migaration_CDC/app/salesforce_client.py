from __future__ import annotations

from typing import Any, Dict, Iterator, List

import requests
from simple_salesforce import Salesforce

from config.settings import CONFIG


class SalesforceClient:
    """Thin wrapper around the Salesforce API used for incremental extraction."""

    def __init__(self):
        self.client = self._connect()

    def _salesforce_domain(self) -> str:
        login_url = (CONFIG.salesforce.login_url or "https://login.salesforce.com").lower()
        if "sandbox" in login_url or "test.salesforce.com" in login_url:
            return "test"
        return "login"

    def _token_url_for_login(self, login_url: str) -> str:
        login_url = login_url.rstrip("/")

        if "sandbox.lightning.force.com" in login_url:
            return login_url.replace(".sandbox.lightning.force.com", ".sandbox.my.salesforce.com") + "/services/oauth2/token"
        if "lightning.force.com" in login_url:
            return login_url.replace(".lightning.force.com", ".my.salesforce.com") + "/services/oauth2/token"
        if "my.salesforce.com" in login_url or "test.salesforce.com" in login_url:
            return f"{login_url}/services/oauth2/token"
        if "sandbox" in login_url:
            return "https://test.salesforce.com/services/oauth2/token"
        return f"{login_url}/services/oauth2/token"

    def _fetch_client_credentials_token(self) -> tuple[str, str]:
        config = CONFIG.salesforce
        login_url = config.login_url 
        token_url = self._token_url_for_login(login_url)
        response = requests.post(
            token_url,
            data={
                "grant_type": "client_credentials",
                "client_id": config.client_id,
                "client_secret": config.client_secret,
            },
            timeout=30,
        )
        response.raise_for_status()
        payload = response.json()
        access_token = payload.get("access_token")
        instance_url = payload.get("instance_url")
        if not access_token or not instance_url:
            raise ValueError("OAuth client-credentials flow did not return access_token or instance_url.")
        return access_token, instance_url

    def _connect(self) -> Salesforce:
        config = CONFIG.salesforce

        if config.uses_client_credentials():
            access_token, instance_url = self._fetch_client_credentials_token()
            return Salesforce(
                session_id=access_token,
                instance_url=instance_url,
                version="59.0",
            )

        if config.uses_token_auth():
            return Salesforce(
                session_id=config.access_token or config.session_id,
                instance_url=config.instance_url,
                version="59.0",
            )

        if config.has_password_auth():
            return Salesforce(
                username=config.username,
                password=config.password,
                security_token=config.security_token,
                domain=self._salesforce_domain(),
            )

        if config.uses_jwt_auth():
            return Salesforce(
                username=config.username,
                consumer_key=config.client_id or config.consumer_key,
                privatekey=config.private_key,
                privatekey_file=config.private_key_file,
                domain=self._salesforce_domain(),
            )

        raise ValueError(
            "Salesforce authentication is not configured. "
            "Use SF_USERNAME+SF_PASSWORD, SF_ACCESS_TOKEN+SF_INSTANCE_URL, SF_SESSION_ID+SF_INSTANCE_URL, "
            "or SF_CLIENT_ID + SF_CLIENT_SECRET (client credentials) for OAuth-based auth."
        )

    def query(self, soql: str, include_deleted: bool = False) -> List[Dict[str, Any]]:
        return list(self.query_iter(soql, include_deleted=include_deleted))

    def query_iter(self, soql: str, include_deleted: bool = False) -> Iterator[Dict[str, Any]]:
        """Stream records page by page. ``include_deleted`` uses queryAll, which
        also returns soft-deleted rows (IsDeleted = true)."""
        for record in self.client.query_all_iter(soql, include_deleted=include_deleted):
            yield record

    def count(self, object_name: str) -> int:
        """Live (non-deleted) row count: SELECT COUNT() returns totalSize with no records."""
        return int(self.client.query(f"SELECT COUNT() FROM {object_name}")["totalSize"])

    def describe_object(self, object_name: str) -> Dict[str, Any]:
        return getattr(self.client, object_name).describe()

    def describe_fields(self, object_name: str) -> List[Dict[str, Any]]:
        return self.describe_object(object_name)["fields"]

    def list_objects(self) -> List[Dict[str, Any]]:
        """Queryable objects in the org (for the UI's object picker)."""
        sobjects = self.client.describe()["sobjects"]
        return [
            {"name": o["name"], "label": o["label"], "custom": o["custom"]}
            for o in sobjects
            if o.get("queryable")
        ]
