from __future__ import annotations

from typing import Any, List, Optional, Sequence

import snowflake.connector

from config.settings import CONFIG


class SnowflakeClient:
    """Thin Snowflake helper. All values go through bind parameters; identifiers
    interpolated into SQL are validated upstream (see app.metadata)."""

    def __init__(self):
        self.conn = self._connect()

    def _connect(self):
        config = CONFIG.snowflake
        if not config.can_connect():
            raise ValueError(
                "Snowflake authentication is not configured. "
                "Set SNOWFLAKE_USER and either SNOWFLAKE_PASSWORD, SNOWFLAKE_TOKEN, SNOWFLAKE_PRIVATE_KEY(_FILE), "
                "or SNOWFLAKE_AUTHENTICATOR=externalbrowser for SSO."
            )

        connect_kwargs = {
            "account": config.account,
            "user": config.user,
            "role": config.role,
            "warehouse": config.warehouse,
            "database": config.database,
            "schema": config.schema,
        }

        if config.password:
            connect_kwargs["password"] = config.password
        if config.authenticator:
            connect_kwargs["authenticator"] = config.authenticator
        if config.token:
            connect_kwargs["token"] = config.token

        # Browser SSO: do not also pass key-based auth arguments. Cache the SSO
        # token so repeated connections don't each pop a browser window.
        if config.authenticator and config.authenticator.lower() == "externalbrowser":
            connect_kwargs["client_store_temporary_credential"] = True
            return snowflake.connector.connect(**connect_kwargs)

        if config.private_key:
            connect_kwargs["private_key"] = config.private_key
        if config.private_key_file:
            connect_kwargs["private_key_file"] = config.private_key_file
        if config.private_key_file_pwd:
            connect_kwargs["private_key_file_pwd"] = config.private_key_file_pwd.encode("utf-8")
        if config.private_key_passphrase:
            connect_kwargs["private_key_passphrase"] = config.private_key_passphrase.encode("utf-8")

        return snowflake.connector.connect(**connect_kwargs)

    def close(self) -> None:
        try:
            self.conn.close()
        except Exception:  # pragma: no cover - best effort
            pass

    # ---- query helpers ------------------------------------------------
    def execute(self, sql: str, params: Optional[Sequence[Any]] = None) -> int:
        """Run a statement; returns the affected row count."""
        with self.conn.cursor() as cur:
            cur.execute(sql, params)
            return cur.rowcount or 0

    def executemany(self, sql: str, rows: Sequence[Sequence[Any]]) -> None:
        if not rows:
            return
        with self.conn.cursor() as cur:
            cur.executemany(sql, rows)

    def fetch_one(self, sql: str, params: Optional[Sequence[Any]] = None):
        with self.conn.cursor() as cur:
            cur.execute(sql, params)
            return cur.fetchone()

    def fetch_all(self, sql: str, params: Optional[Sequence[Any]] = None) -> List[tuple]:
        with self.conn.cursor() as cur:
            cur.execute(sql, params)
            return cur.fetchall()

    def fetch_dicts(self, sql: str, params: Optional[Sequence[Any]] = None) -> List[dict]:
        """Rows as dicts keyed by column name (upper case)."""
        with self.conn.cursor() as cur:
            cur.execute(sql, params)
            names = [d[0] for d in cur.description]
            return [dict(zip(names, row)) for row in cur.fetchall()]

    # ---- schema helpers -----------------------------------------------
    def table_columns(self, table_name: str) -> List[str]:
        """Upper-case column names of a table in the current schema ([] if absent)."""
        rows = self.fetch_all(
            "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS "
            "WHERE TABLE_SCHEMA = CURRENT_SCHEMA() AND TABLE_NAME = %s ORDER BY ORDINAL_POSITION",
            (table_name.upper(),),
        )
        return [r[0].upper() for r in rows]

    def whoami(self) -> dict:
        row = self.fetch_one(
            "SELECT CURRENT_USER(), CURRENT_ROLE(), CURRENT_WAREHOUSE(), CURRENT_DATABASE(), CURRENT_SCHEMA()"
        )
        return dict(zip(["user", "role", "warehouse", "database", "schema"], row))
