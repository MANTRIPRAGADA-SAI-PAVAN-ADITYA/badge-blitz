"""Object registry: which Salesforce objects the pipeline syncs.

The registry is the single place that decides what gets loaded. It is edited
from the Streamlit UI (or ``config/objects.json`` locally), never in code.

Storage:
  * Snowflake table ``CDC_OBJECT_CONFIG`` when a Snowflake client is supplied
    (the hosted / shared case - survives redeploys and is visible to everyone).
  * ``config/objects.json`` otherwise (local runs, tests, first-time bootstrap).
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

DEFAULTS_PATH = Path(__file__).resolve().parent.parent / "config" / "objects.json"

LOAD_STRATEGIES = ("auto", "rest", "bulk")
_IDENTIFIER = re.compile(r"^[A-Za-z][A-Za-z0-9_]*$")


def validate_identifier(name: str, what: str = "identifier") -> str:
    """Salesforce API names and Snowflake table names are interpolated into SQL,
    so only plain ``[A-Za-z][A-Za-z0-9_]*`` identifiers are ever accepted."""
    if not isinstance(name, str) or not _IDENTIFIER.match(name.strip()):
        raise ValueError(f"Invalid {what}: {name!r}")
    return name.strip()


@dataclass
class ObjectConfig:
    object_name: str
    target_table: str = ""
    enabled: bool = True
    # Empty = sync every queryable field found via describe(). Set to restrict.
    fields: List[str] = field(default_factory=list)
    note: str = ""
    # auto = REST normally, Bulk API 2.0 for big loads; or force "rest" / "bulk".
    load_strategy: str = "auto"

    def __post_init__(self) -> None:
        if self.load_strategy not in LOAD_STRATEGIES:
            raise ValueError(f"load_strategy must be one of {', '.join(LOAD_STRATEGIES)}")
        self.object_name = validate_identifier(self.object_name, "Salesforce object name")
        self.target_table = validate_identifier(
            self.target_table or self.object_name.upper(), "target table name"
        ).upper()
        self.fields = [validate_identifier(f, "field name") for f in self.fields if f and f.strip()]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "object_name": self.object_name,
            "target_table": self.target_table,
            "enabled": self.enabled,
            "fields": list(self.fields),
            "note": self.note,
            "load_strategy": self.load_strategy,
        }


class ObjectRegistry:
    """Add / remove / enable objects. Backed by Snowflake or a JSON file."""

    TABLE = "CDC_OBJECT_CONFIG"

    def __init__(self, snowflake: Optional[Any] = None, path: Optional[Path] = None):
        self.sf_db = snowflake
        self.path = Path(path) if path else DEFAULTS_PATH
        if self.sf_db is not None:
            self._ensure_table()

    # ---- public API -------------------------------------------------
    def list(self, enabled_only: bool = False) -> List[ObjectConfig]:
        configs = self._read()
        return [c for c in configs if c.enabled] if enabled_only else configs

    def get(self, object_name: str) -> Optional[ObjectConfig]:
        for cfg in self._read():
            if cfg.object_name.lower() == object_name.lower():
                return cfg
        return None

    def upsert(self, cfg: ObjectConfig, user: str = "") -> None:
        if self.sf_db is None:
            items = [c for c in self._read() if c.object_name.lower() != cfg.object_name.lower()]
            items.append(cfg)
            self._write_json(items)
            return
        self.sf_db.execute(
            f"""
            MERGE INTO {self.TABLE} t
            USING (SELECT %s AS OBJECT_NAME, %s AS TARGET_TABLE, %s AS ENABLED,
                          %s AS FIELDS, %s AS NOTE, %s AS LOAD_STRATEGY, %s AS UPDATED_BY) s
            ON UPPER(t.OBJECT_NAME) = UPPER(s.OBJECT_NAME)
            WHEN MATCHED THEN UPDATE SET TARGET_TABLE = s.TARGET_TABLE, ENABLED = s.ENABLED,
                 FIELDS = s.FIELDS, NOTE = s.NOTE, LOAD_STRATEGY = s.LOAD_STRATEGY, UPDATED_BY = s.UPDATED_BY,
                 UPDATED_AT = CURRENT_TIMESTAMP()
            WHEN NOT MATCHED THEN INSERT (OBJECT_NAME, TARGET_TABLE, ENABLED, FIELDS, NOTE, LOAD_STRATEGY, UPDATED_BY)
                 VALUES (s.OBJECT_NAME, s.TARGET_TABLE, s.ENABLED, s.FIELDS, s.NOTE, s.LOAD_STRATEGY, s.UPDATED_BY)
            """,
            (cfg.object_name, cfg.target_table, cfg.enabled, ",".join(cfg.fields), cfg.note, cfg.load_strategy, user),
        )

    def set_enabled(self, object_name: str, enabled: bool, user: str = "") -> None:
        cfg = self.get(object_name)
        if cfg is None:
            raise KeyError(object_name)
        cfg.enabled = enabled
        self.upsert(cfg, user)

    def remove(self, object_name: str) -> None:
        """Stop syncing an object. The Snowflake data table is NOT dropped."""
        if self.sf_db is None:
            self._write_json([c for c in self._read() if c.object_name.lower() != object_name.lower()])
            return
        self.sf_db.execute(
            f"DELETE FROM {self.TABLE} WHERE UPPER(OBJECT_NAME) = UPPER(%s)", (object_name,)
        )

    # ---- storage ----------------------------------------------------
    def _ensure_table(self) -> None:
        self.sf_db.execute(
            f"""
            CREATE TABLE IF NOT EXISTS {self.TABLE} (
                OBJECT_NAME  VARCHAR NOT NULL,
                TARGET_TABLE VARCHAR NOT NULL,
                ENABLED      BOOLEAN DEFAULT TRUE,
                FIELDS       VARCHAR,
                NOTE         VARCHAR,
                UPDATED_BY   VARCHAR,
                UPDATED_AT   TIMESTAMP_LTZ DEFAULT CURRENT_TIMESTAMP()
            )
            """
        )
        # Tables created before load strategies existed get the column added.
        self.sf_db.execute(f"ALTER TABLE {self.TABLE} ADD COLUMN IF NOT EXISTS LOAD_STRATEGY VARCHAR DEFAULT 'auto'")
        # First use: seed from the shipped defaults so the list is never empty.
        if self.sf_db.fetch_one(f"SELECT COUNT(*) FROM {self.TABLE}")[0] == 0:
            for cfg in self._read_json():
                self.upsert(cfg, "seed")

    def _read(self) -> List[ObjectConfig]:
        if self.sf_db is None:
            return self._read_json()
        rows = self.sf_db.fetch_all(
            f"SELECT OBJECT_NAME, TARGET_TABLE, ENABLED, FIELDS, NOTE, LOAD_STRATEGY FROM {self.TABLE} ORDER BY OBJECT_NAME"
        )
        return [
            ObjectConfig(
                object_name=r[0],
                target_table=r[1],
                enabled=bool(r[2]),
                fields=[f for f in (r[3] or "").split(",") if f.strip()],
                note=r[4] or "",
                load_strategy=r[5] or "auto",
            )
            for r in rows
        ]

    def _read_json(self) -> List[ObjectConfig]:
        if not self.path.exists():
            return []
        data = json.loads(self.path.read_text(encoding="utf-8"))
        return [ObjectConfig(**item) for item in data.get("objects", [])]

    def _write_json(self, items: List[ObjectConfig]) -> None:
        items = sorted(items, key=lambda c: c.object_name.lower())
        self.path.write_text(
            json.dumps({"objects": [c.to_dict() for c in items]}, indent=2) + "\n", encoding="utf-8"
        )


def get_object_configs(registry: Optional[ObjectRegistry] = None, enabled_only: bool = True) -> List[ObjectConfig]:
    return (registry or ObjectRegistry()).list(enabled_only=enabled_only)
