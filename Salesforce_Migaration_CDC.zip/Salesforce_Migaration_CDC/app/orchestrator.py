from __future__ import annotations

from datetime import datetime, timezone
from typing import Iterable, List, Optional


def get_run_windows() -> List[str]:
    """Return the 4 daily run windows used by the orchestrator."""
    return ["00:00", "06:00", "12:00", "18:00"]


def build_soql_query(
    object_name: str,
    fields: Iterable[str],
    watermark: Optional[str] = None,
    watermark_field: str = "SystemModstamp",
) -> str:
    """Fetch rows changed after ``watermark`` (everything when it is None).

    Ordered by the watermark field so the highest value seen is always the
    last one, and a failed run can be resumed safely.
    """
    field_list = ", ".join(fields)
    soql = f"SELECT {field_list} FROM {object_name}"
    if watermark:
        soql += f" WHERE {watermark_field} > {watermark}"
    return soql + f" ORDER BY {watermark_field} ASC"


def build_delete_soql_query(object_name: str, watermark: str) -> str:
    """Soft-deleted rows only (kept for reference; the pipeline now uses queryAll)."""
    return (
        f"SELECT Id, SystemModstamp, IsDeleted "
        f"FROM {object_name} "
        f"WHERE IsDeleted = true AND SystemModstamp > {watermark}"
    )


def is_run_time_due(current_time: datetime) -> bool:
    """Check whether the given time matches one of the four scheduled windows."""
    return current_time.strftime("%H:%M") in get_run_windows()


def parse_sf_datetime(value: str) -> datetime:
    """Parse Salesforce's ``2024-01-01T10:00:00.000+0000`` (also ``Z`` / ``+00:00``)."""
    text = value.strip()
    if text.endswith("Z"):
        text = text[:-1] + "+0000"
    if len(text) > 5 and text[-3] == ":" and text[-6] in "+-":
        text = text[:-3] + text[-2:]
    fmt = "%Y-%m-%dT%H:%M:%S.%f%z" if "." in text else "%Y-%m-%dT%H:%M:%S%z"
    return datetime.strptime(text, fmt).astimezone(timezone.utc)


def to_soql_datetime(value: datetime) -> str:
    """Format a datetime as a SOQL literal, e.g. 2024-01-01T10:00:00.000Z."""
    value = value.astimezone(timezone.utc)
    return value.strftime("%Y-%m-%dT%H:%M:%S.") + f"{value.microsecond // 1000:03d}Z"
