import pandas as pd
import streamlit as st

st.set_page_config(page_title="Salesforce CDC Monitor", layout="wide")


def build_demo_data() -> pd.DataFrame:
    rows = [
        {"table_name": "ACCOUNT", "change_type": "INSERT", "record_id": "001A1", "change_ts": "2026-09-25 00:10:00", "source_system": "Salesforce"},
        {"table_name": "ACCOUNT", "change_type": "UPDATE", "record_id": "001A2", "change_ts": "2026-09-25 02:35:00", "source_system": "Salesforce"},
        {"table_name": "CONTACT", "change_type": "INSERT", "record_id": "003A1", "change_ts": "2026-09-25 03:20:00", "source_system": "Salesforce"},
        {"table_name": "OPPORTUNITY", "change_type": "UPDATE", "record_id": "006A4", "change_ts": "2026-09-25 05:42:00", "source_system": "Salesforce"},
        {"table_name": "OPPORTUNITY", "change_type": "DELETE", "record_id": "006A5", "change_ts": "2026-09-25 06:05:00", "source_system": "Salesforce"},
        {"table_name": "USER", "change_type": "UPDATE", "record_id": "005A7", "change_ts": "2026-09-25 08:15:00", "source_system": "Salesforce"},
        {"table_name": "TASK", "change_type": "INSERT", "record_id": "00T1", "change_ts": "2026-09-25 09:00:00", "source_system": "Salesforce"},
        {"table_name": "LEAD", "change_type": "UPDATE", "record_id": "00Q9", "change_ts": "2026-09-25 10:00:00", "source_system": "Salesforce"},
    ]
    df = pd.DataFrame(rows)
    df["change_ts"] = pd.to_datetime(df["change_ts"])
    return df


df = build_demo_data()

st.title("Salesforce CDC Monitor")

with st.sidebar:
    st.header("Filters")
    table_choice = st.selectbox("Table", ["ALL", *sorted(df["table_name"].unique())])
    hours = st.slider("Lookback window (hours)", min_value=1, max_value=48, value=12)

filtered = df.copy()
if table_choice != "ALL":
    filtered = filtered[filtered["table_name"] == table_choice]

filtered = filtered[filtered["change_ts"] >= (pd.Timestamp.now() - pd.Timedelta(hours=hours))]

kpi_insert = int((filtered["change_type"] == "INSERT").sum())
kpi_update = int((filtered["change_type"] == "UPDATE").sum())
kpi_delete = int((filtered["change_type"] == "DELETE").sum())

col1, col2, col3, col4 = st.columns(4)
col1.metric("Insert", kpi_insert)
col2.metric("Update", kpi_update)
col3.metric("Delete", kpi_delete)
col4.metric("Total", len(filtered))

by_table = filtered.groupby("table_name").size().reset_index(name="changes")
by_type = filtered.groupby("change_type").size().reset_index(name="changes")

chart_col, log_col = st.columns([1.3, 2])
chart_col.subheader("Changes by table")
chart_col.bar_chart(by_table.set_index("table_name"))

log_col.subheader("Recent CDC log")
log_col.dataframe(filtered.sort_values("change_ts", ascending=False), use_container_width=True)

st.subheader("Breakdown by change type")
st.bar_chart(by_type.set_index("change_type"))

st.caption("Mock dashboard for the Salesforce-to-Snowflake CDC architecture described in the project docs.")
