"""Incremental Salesforce -> Snowflake sync for one object, plus a parallel runner for many.

Per object, per run:
  1. describe() the object -> fields, watermark field, IsDeleted support
  2. read the stored watermark (none = initial / full load)
  3. plan the work: big objects are split into Id-range partitions (and very wide ones into
     column groups); each slice is one task
  4. fetch tasks in parallel (REST, or Bulk API 2.0 for big loads) into gzip-CSV files
  5. PUT + COPY INTO a transient all-text stage table (Snowflake loads in parallel)
  6. classify rows INSERT / UPDATE / DELETE into CDC_CHANGE_LOG, then MERGE into the target,
     never overwriting a row with an older version
  7. only after the MERGE succeeds, advance the watermark to the run's START time (minus a
     small overlap) so rows changed *during* a long load are picked up by the next run
  8. optionally reconcile hard deletes (ID diff against Salesforce)

Soft-deleted rows are kept in the target with ISDELETED = true (history is preserved).
"""
from __future__ import annotations

import os
import re
import shutil
import tempfile
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Callable, Dict, Iterable, Iterator, List, Optional, Sequence

from app import control
from app.loader import (
    Partition, bulk_csv_rows, bulk_threshold, object_workers, overlap_seconds, partition_rows,
    plan_partitions, sf_concurrency, sf_slot, to_text, with_retries, write_rows_gz,
)
from app.metadata import ObjectConfig, validate_identifier
from app.orchestrator import build_partition_query, to_soql_datetime
from app.salesforce_client import SalesforceClient
from app.snowflake_client import SnowflakeClient

# SOQL goes over HTTP; very wide objects (hundreds of fields) must be fetched in column
# groups that are re-joined on Id, or Salesforce rejects the query as too long.
MAX_SOQL_CHARS = 12000
# Compound / binary fields cannot be bulk-queried or stored as plain columns.
SKIP_SF_TYPES = {"address", "location", "base64", "anyType"}
SNOWFLAKE_TYPES = {
    "boolean": "BOOLEAN",
    "int": "NUMBER(38,0)",
    "long": "NUMBER(38,0)",
    "double": "FLOAT",
    "currency": "FLOAT",
    "percent": "FLOAT",
    "date": "DATE",
    "datetime": "TIMESTAMP_TZ",
    "time": "TIME",
}

Log = Callable[[str], None]
__all__ = ["IncrementalPipeline", "run_objects", "build_plan", "chunk_fields", "to_text", "SKIP_SF_TYPES"]


def _q(column: str) -> str:
    return '"' + column.upper() + '"'


def chunk_fields(fields: Sequence[str], required: Sequence[str], max_chars: int = MAX_SOQL_CHARS) -> List[List[str]]:
    """Split ``fields`` into SOQL-sized groups; every group starts with ``required`` (Id, watermark, IsDeleted)."""
    required = list(required)
    rest = [f for f in fields if f not in required]
    base = len(", ".join(required))
    chunks: List[List[str]] = []
    current: List[str] = []
    size = base
    for f in rest:
        if current and size + len(f) + 2 > max_chars:
            chunks.append(required + current)
            current, size = [], base
        current.append(f)
        size += len(f) + 2
    chunks.append(required + current)
    return chunks


def add_missing_columns_enabled() -> bool:
    return (os.getenv("CDC_ADD_MISSING_COLUMNS") or "true").strip().lower() not in ("0", "false", "no")


@dataclass
class ObjectPlan:
    """What describe() tells us about how to sync an object."""
    fields: List[str]
    types: Dict[str, str]
    watermark_field: Optional[str]
    has_is_deleted: bool


def build_plan(config: ObjectConfig, describe_fields: Sequence[Dict[str, Any]]) -> ObjectPlan:
    by_lower = {f["name"].lower(): f for f in describe_fields}
    if config.fields:
        unknown = [f for f in config.fields if f.lower() not in by_lower]
        if unknown:
            raise ValueError(f"{config.object_name}: unknown field(s) {', '.join(unknown)}")
        wanted = [by_lower[f.lower()]["name"] for f in config.fields]
        for required in ("Id", "SystemModstamp", "LastModifiedDate", "IsDeleted"):
            if required.lower() in by_lower and required not in wanted:
                wanted.append(required)
    else:
        wanted = [f["name"] for f in describe_fields if f["type"] not in SKIP_SF_TYPES]
    if "Id" not in wanted:
        raise ValueError(f"{config.object_name} has no Id field and cannot be synced.")

    names = {n.lower() for n in wanted}
    watermark_field = (
        "SystemModstamp" if "systemmodstamp" in names
        else "LastModifiedDate" if "lastmodifieddate" in names
        else None
    )
    return ObjectPlan(
        fields=wanted,
        types={n: by_lower[n.lower()]["type"] for n in wanted},
        watermark_field=watermark_field,
        has_is_deleted="isdeleted" in names,
    )


class IncrementalPipeline:
    """Syncs one Salesforce object into one Snowflake table."""

    def __init__(
        self,
        config: ObjectConfig,
        sf: SalesforceClient,
        db: SnowflakeClient,
        run_id: str,
        trigger: str = "manual",
        user: str = "",
        full_refresh: bool = False,
        reconcile: bool = False,
        log: Log = print,
    ):
        self.config = config
        self.sf = sf
        self.db = db
        self.run_id = run_id
        self.trigger = trigger
        self.user = user
        self.full_refresh = full_refresh
        self.reconcile = reconcile
        self.log = log
        self.target = validate_identifier(config.target_table, "target table")
        self.stage = f"CDC_STG_{self.target}_{run_id}"
        self._tables: List[str] = []          # transient tables to drop afterwards
        self._tmpdir: Optional[str] = None
        self.stage_dir = f"@~/cdc/{run_id}/{self.target}/"

    # ---- orchestration ---------------------------------------------------
    def run(self) -> Dict[str, Any]:
        obj = self.config.object_name
        stats = {"extracted": 0, "inserted": 0, "updated": 0, "deleted": 0}
        # Captured BEFORE any Salesforce query: the next watermark must not be later than this, or a
        # row changed while we were reading could be skipped forever.
        started = datetime.now(timezone.utc)
        t_run = time.monotonic()
        stored = None if self.full_refresh else control.get_watermark(self.db, obj)
        control.start_run(self.db, self.run_id, obj, self.trigger, self.user, stored)
        new_watermark: Optional[str] = None
        try:
            self.log(f"[{obj}] starting ({self.trigger}, target {self.target}, load strategy {self.config.load_strategy})")
            plan = build_plan(self.config, self.sf.describe_fields(obj))
            target_cols = self._ensure_target(plan)
            if plan.watermark_field is None:
                stored = None  # nothing to filter on: always a full pull
            self.log(f"[{obj}] {len(plan.fields)} fields, watermark={plan.watermark_field}, "
                     f"since={stored or 'beginning (full load)'}")

            self._extract_to_stage(plan, target_cols, stored, stats)
            if stats["extracted"]:
                self._classify_and_merge(plan, target_cols, stats)
            if plan.watermark_field:
                new_watermark = to_soql_datetime(started - timedelta(seconds=overlap_seconds()))
                control.set_watermark(self.db, obj, plan.watermark_field, new_watermark)
                self.log(f"[{obj}] watermark advanced to {new_watermark} (run start - {overlap_seconds()}s overlap)")

            if self.reconcile or not plan.has_is_deleted:
                stats["deleted"] += self._reconcile_deletes(plan, target_cols)

            control.finish_run(self.db, self.run_id, obj, "SUCCESS", stats, new_watermark or stored)
            self.log(f"[{obj}] done in {time.monotonic() - t_run:.0f}s: +{stats['inserted']} new, "
                     f"~{stats['updated']} updated, -{stats['deleted']} deleted")
        except Exception as exc:
            self.log(f"[{obj}] FAILED after {time.monotonic() - t_run:.0f}s: {exc}")
            control.finish_run(self.db, self.run_id, obj, "FAILED", stats, stored, str(exc))
            raise
        finally:
            self._cleanup()
        return {"object": obj, "status": "SUCCESS", **stats}

    # ---- target table -----------------------------------------------------
    def _ensure_target(self, plan: ObjectPlan) -> List[str]:
        """Create the target if missing; add any columns it lacks (unless disabled)."""
        existing = self.db.table_columns(self.target)
        if not existing:
            cols = ",\n".join(
                f"{_q(f)} {SNOWFLAKE_TYPES.get(plan.types[f], 'VARCHAR')}" for f in plan.fields
            )
            self.db.execute(f"CREATE TABLE {self.target} (\n{cols}\n)")
            self.log(f"[{self.config.object_name}] created table {self.target}")
            return [f.upper() for f in plan.fields]
        if "ID" not in existing:
            raise ValueError(f"Existing table {self.target} has no ID column.")
        missing = [f for f in plan.fields if f.upper() not in existing]
        if missing and add_missing_columns_enabled():
            # Schema evolution: add what Salesforce has but the table lacks (nullable, additive only).
            for f in missing:
                self.db.execute(
                    f"ALTER TABLE {self.target} ADD COLUMN IF NOT EXISTS "
                    f"{_q(f)} {SNOWFLAKE_TYPES.get(plan.types[f], 'VARCHAR')}"
                )
            self.log(f"[{self.config.object_name}] added {len(missing)} missing column(s) to {self.target}: "
                     f"{', '.join(missing)}")
            existing = existing + [f.upper() for f in missing]
        elif missing:
            self.log(f"[{self.config.object_name}] not in {self.target}, skipped: {', '.join(missing)}")
        return [f.upper() for f in plan.fields if f.upper() in existing]

    # ---- extraction -------------------------------------------------------
    def _make_table(self, name: str, columns: Sequence[str]) -> str:
        cols = ", ".join(f"{_q(c)} VARCHAR" for c in columns)
        self.db.execute(f"CREATE OR REPLACE TRANSIENT TABLE {name} ({cols})")
        self._tables.append(name)
        return name

    def _plan_work(self, plan: ObjectPlan, where: str):
        """Decide strategy and Id-range partitions. Returns (strategy, partitions, estimate, id_count)."""
        obj = self.config.object_name
        try:
            estimate = self.sf.count(obj, where, include_deleted=plan.has_is_deleted)
        except Exception as exc:  # unknown size -> behave like a small object
            self.log(f"[{obj}] could not count rows ({exc}); assuming a small load")
            estimate = 0

        strategy = self.config.load_strategy
        if strategy == "auto":
            strategy = "bulk" if estimate >= bulk_threshold() else "rest"

        partitions = [Partition(0)]
        id_count: Optional[int] = None
        if estimate > partition_rows():
            ids = list(self.sf.query_ids(obj, where, include_deleted=plan.has_is_deleted))
            id_count = len(ids)
            partitions = plan_partitions(ids, partition_rows())
        return strategy, partitions, estimate, id_count

    def _extract_to_stage(self, plan: ObjectPlan, target_cols: List[str], since: Optional[str],
                          stats: Dict[str, int]) -> None:
        obj = self.config.object_name
        # The watermark and IsDeleted columns are always staged: they drive the incremental
        # filter, dedup ordering, the newer-version guard and change classification.
        required = ["Id"] + [f for f in (plan.watermark_field, "IsDeleted" if plan.has_is_deleted else None) if f]
        fields = [f for f in plan.fields if f.upper() in target_cols or f in required]
        chunks = chunk_fields(fields, required, MAX_SOQL_CHARS)

        where = f"{plan.watermark_field} > {since}" if since and plan.watermark_field else ""
        strategy, partitions, estimate, id_count = self._plan_work(plan, where)
        tasks = [(ci, part) for part in partitions for ci in range(len(chunks))]
        workers = max(1, min(len(tasks), sf_concurrency()))
        self.log(f"[{obj}] ~{estimate:,} rows via {strategy.upper()}: {len(partitions)} partition(s) x "
                 f"{len(chunks)} column group(s) = {len(tasks)} task(s), {workers} in parallel")

        tables = [self._make_table(self.stage, fields)]
        for ci in range(1, len(chunks)):
            tables.append(self._make_table(f"{self.stage}_P{ci}", chunks[ci]))

        self._tmpdir = tempfile.mkdtemp(prefix=f"cdc_{self.target}_")
        done = 0
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = [pool.submit(self._fetch_task, plan, chunks[ci], ci, part, since, strategy) for ci, part in tasks]
            try:
                # Files are loaded as they finish, so Snowflake ingestion overlaps the other fetches.
                for future in as_completed(futures):
                    ci, part, path, rows, fetch_secs = future.result()
                    began = time.monotonic()
                    self._load_file(path, tables[ci], chunks[ci])
                    done += 1
                    if ci == 0:
                        stats["extracted"] += rows
                    self.log(f"[{obj}] task {done}/{len(tasks)} done (column group {ci + 1}/{len(chunks)}, "
                             f"range {part.index + 1}/{len(partitions)}): {rows:,} rows, "
                             f"fetch {fetch_secs:.0f}s, load {time.monotonic() - began:.0f}s | "
                             f"{stats['extracted']:,} rows so far")
            except BaseException:
                for f in futures:
                    f.cancel()
                raise

        for ci in range(1, len(chunks)):
            began = time.monotonic()
            self._join_chunk_into_stage(tables[ci], chunks[ci], required)
            self.log(f"[{obj}] joined column group {ci + 1}/{len(chunks)} in {time.monotonic() - began:.0f}s")
        if id_count is not None and stats["extracted"] != id_count:
            self.log(f"[{obj}] note: {stats['extracted']:,} rows loaded vs {id_count:,} Ids planned "
                     f"(rows changed while loading; the next run reconciles them)")
        self.log(f"[{obj}] extracted {stats['extracted']:,} rows")

    def _fetch_task(self, plan: ObjectPlan, chunk: List[str], ci: int, part: Partition,
                    since: Optional[str], strategy: str):
        soql = build_partition_query(self.config.object_name, chunk, since, plan.watermark_field, part.lo, part.hi)
        path = os.path.join(self._tmpdir, f"c{ci}_p{part.index}.csv.gz")

        def attempt() -> int:
            with sf_slot():
                return write_rows_gz(path, self._rows(plan, chunk, soql, strategy))

        began = time.monotonic()
        rows = with_retries(attempt, log=self.log, what=f"[{self.config.object_name}] group {ci + 1} range {part.index + 1}")
        return ci, part, path, rows, time.monotonic() - began

    def _rows(self, plan: ObjectPlan, chunk: List[str], soql: str, strategy: str) -> Iterator[List[Optional[str]]]:
        """Rows in ``chunk`` order. Bulk falls back to REST if the Bulk API is unavailable."""
        obj = self.config.object_name
        if strategy == "bulk":
            try:
                files = self.sf.bulk_download(obj, soql, self._tmpdir, include_deleted=plan.has_is_deleted)
                return (row for f in files for row in bulk_csv_rows(f, chunk, plan.types))
            except Exception as exc:
                self.log(f"[{obj}] Bulk API failed ({exc}); falling back to REST for this slice")
        return ([to_text(record.get(f), plan.types[f]) for f in chunk]
                for record in self.sf.query_iter(soql, include_deleted=plan.has_is_deleted))

    def _load_file(self, path: str, table: str, columns: Sequence[str]) -> None:
        self.db.put_file(path, self.stage_dir)
        self.db.copy_csv(table, columns, self.stage_dir, os.path.basename(path))
        os.remove(path)

    def _join_chunk_into_stage(self, part: str, chunk: List[str], required: List[str]) -> None:
        """Copy a later column group into the stage rows, matched on Id. A row that only
        appears in a later group changed after group 1 ran, so the next run picks it up."""
        cols = [f for f in chunk if f not in required]
        if not cols:
            return
        updates = ", ".join(f"s.{_q(c)} = p.{_q(c)}" for c in cols)
        self.db.execute(
            f"MERGE INTO {self.stage} s USING "
            f"(SELECT * FROM {part} QUALIFY ROW_NUMBER() OVER (PARTITION BY {_q('Id')} ORDER BY {_q('Id')}) = 1) p "
            f"ON s.{_q('Id')} = p.{_q('Id')} WHEN MATCHED THEN UPDATE SET {updates}"
        )

    # ---- classify + merge --------------------------------------------------
    def _classify_and_merge(self, plan: ObjectPlan, target_cols: List[str], stats: Dict[str, int]) -> None:
        order = _q(plan.watermark_field) if plan.watermark_field else _q("Id")
        # If an Id appears twice in one load (changed again mid-run) keep the newest.
        latest = (f"SELECT * FROM {self.stage} "
                  f"QUALIFY ROW_NUMBER() OVER (PARTITION BY {_q('Id')} ORDER BY {order} DESC) = 1")

        # Version guard: a row is only written / logged when the incoming version is not older than
        # what the table already holds. Re-reads (overlap, retries, full refresh) therefore neither
        # overwrite newer data nor show up as fake UPDATEs.
        wm = plan.watermark_field if plan.watermark_field and plan.watermark_field.upper() in target_cols else None
        if wm:
            s_ts = f"TRY_TO_TIMESTAMP_TZ(s.{_q(wm)})"
            t_ts = f"TRY_TO_TIMESTAMP_TZ(t.{_q(wm)}::VARCHAR)"
            changed = f"WHERE t.{_q('Id')} IS NULL OR {t_ts} IS NULL OR {s_ts} > {t_ts}"
            may_update = f" AND ({t_ts} IS NULL OR {s_ts} >= {t_ts})"
        else:
            changed, may_update = "", ""

        deleted_case = (f"WHEN LOWER(s.{_q('IsDeleted')}) = 'true' THEN 'DELETE' " if plan.has_is_deleted else "")
        obj = self.config.object_name
        began = time.monotonic()
        self.db.execute(
            f"""
            INSERT INTO CDC_CHANGE_LOG (RUN_ID, OBJECT_NAME, RECORD_ID, CHANGE_TYPE)
            SELECT %s, %s, s.{_q('Id')},
                   CASE {deleted_case}WHEN t.{_q('Id')} IS NULL THEN 'INSERT' ELSE 'UPDATE' END
            FROM ({latest}) s
            LEFT JOIN {self.target} t ON t.{_q('Id')} = s.{_q('Id')}
            {changed}
            """,
            (self.run_id, self.config.object_name),
        )
        self._load_change_counts(stats)
        self.log(f"[{obj}] classified {stats['inserted'] + stats['updated'] + stats['deleted']:,} changed rows in "
                 f"{time.monotonic() - began:.1f}s: {stats['inserted']:,} insert, {stats['updated']:,} update, "
                 f"{stats['deleted']:,} delete (unchanged re-reads are skipped)")

        non_key = [c for c in target_cols if c != "ID"]
        updates = ", ".join(f"t.{_q(c)} = s.{_q(c)}" for c in non_key)
        merge = f"""
            MERGE INTO {self.target} t
            USING ({latest}) s ON t.{_q('Id')} = s.{_q('Id')}
            {f'WHEN MATCHED{may_update} THEN UPDATE SET {updates}' if updates else ''}
            WHEN NOT MATCHED THEN INSERT ({', '.join(_q(c) for c in target_cols)})
                 VALUES ({', '.join('s.' + _q(c) for c in target_cols)})
        """
        began = time.monotonic()
        self.db.execute(merge)
        self.log(f"[{obj}] merged into {self.target} in {time.monotonic() - began:.1f}s")

    def _load_change_counts(self, stats: Dict[str, int]) -> None:
        rows = self.db.fetch_all(
            "SELECT CHANGE_TYPE, COUNT(*) FROM CDC_CHANGE_LOG "
            "WHERE RUN_ID = %s AND OBJECT_NAME = %s GROUP BY CHANGE_TYPE",
            (self.run_id, self.config.object_name),
        )
        counts = {r[0]: int(r[1]) for r in rows}
        stats["inserted"] = counts.get("INSERT", 0)
        stats["updated"] = counts.get("UPDATE", 0)
        stats["deleted"] = counts.get("DELETE", 0)

    # ---- hard deletes -----------------------------------------------------
    def _reconcile_deletes(self, plan: ObjectPlan, target_cols: List[str]) -> int:
        """Hard deletes never appear in a SystemModstamp query (nor, after ~15 days, in queryAll) -
        find them by diffing live Salesforce Ids against the target."""
        obj = self.config.object_name
        live = self._make_table(f"CDC_IDS_{self.target}_{self.run_id}", ["ID"])
        if self._tmpdir is None:
            self._tmpdir = tempfile.mkdtemp(prefix=f"cdc_{self.target}_")
        path = os.path.join(self._tmpdir, "live_ids.csv.gz")

        def list_ids() -> int:
            with sf_slot():
                return write_rows_gz(path, ([i] for i in self.sf.query_ids(obj)))

        count = with_retries(list_ids, log=self.log, what=f"[{obj}] id listing")
        self.log(f"[{obj}] reconcile: {count:,} live Ids in Salesforce, comparing with {self.target}")
        self._load_file(path, live, ["ID"])

        total = self.db.fetch_one(f"SELECT COUNT(*) FROM {self.target}")[0]
        if not count and total:
            raise RuntimeError(f"Reconcile aborted: Salesforce returned 0 {obj} Ids but {self.target} "
                               f"holds {total} rows. Refusing to delete everything.")

        soft = plan.has_is_deleted and "ISDELETED" in target_cols
        not_live = f"{_q('Id')} NOT IN (SELECT ID FROM {live})"
        guard = f" AND COALESCE(LOWER({_q('IsDeleted')}::VARCHAR), 'false') <> 'true'" if soft else ""
        removed = self.db.execute(
            f"""
            INSERT INTO CDC_CHANGE_LOG (RUN_ID, OBJECT_NAME, RECORD_ID, CHANGE_TYPE)
            SELECT %s, %s, {_q('Id')}, 'DELETE' FROM {self.target} WHERE {not_live}{guard}
            """,
            (self.run_id, obj),
        )
        if soft:
            # ISDELETED may be BOOLEAN or text depending on how the table was created.
            self.db.execute(f"UPDATE {self.target} SET {_q('IsDeleted')} = TRUE WHERE {not_live}{guard}")
        else:
            self.db.execute(f"DELETE FROM {self.target} WHERE {not_live}")
        self.log(f"[{obj}] reconcile found {removed} hard-deleted rows")
        return int(removed)

    # ---- cleanup ------------------------------------------------------------
    def _cleanup(self) -> None:
        for table in self._tables:
            try:
                self.db.execute(f"DROP TABLE IF EXISTS {table}")
            except Exception:  # best effort; transient tables also expire
                pass
        self.db.remove_stage_dir(self.stage_dir)
        if self._tmpdir:
            shutil.rmtree(self._tmpdir, ignore_errors=True)
        if self._tables:
            self.log(f"[{self.config.object_name}] cleaned up {len(self._tables)} temporary table(s) and staged files")


# ---- multi-object runner ---------------------------------------------------
STALE_RUN_HOURS = 3


def is_running(db: SnowflakeClient, object_name: str) -> bool:
    """True if a run for this object started recently and has not finished (any trigger)."""
    row = db.fetch_one(
        "SELECT COUNT(*) FROM CDC_RUN_LOG WHERE OBJECT_NAME = %s AND STATUS = 'RUNNING' "
        "AND STARTED_AT > DATEADD(hour, -%s, CURRENT_TIMESTAMP())",
        (object_name, STALE_RUN_HOURS),
    )
    return bool(row and row[0])


@dataclass
class RunSummary:
    run_id: str
    results: List[Dict[str, Any]] = field(default_factory=list)

    @property
    def failed(self) -> int:
        return sum(1 for r in self.results if r["status"] == "FAILED")


def _estimate(sf: SalesforceClient, cfg: ObjectConfig) -> int:
    try:
        return int(sf.count(cfg.object_name))
    except Exception:
        return 0


def run_objects(
    configs: Iterable[ObjectConfig],
    sf: SalesforceClient,
    db: SnowflakeClient,
    trigger: str = "manual",
    user: str = "",
    full_refresh: bool = False,
    reconcile: bool = False,
    log: Log = print,
    should_stop: Callable[[], bool] = lambda: False,
    workers: Optional[int] = None,
) -> RunSummary:
    """Run every given object, several at a time, biggest first. One object failing never stops the others."""
    configs = list(configs)
    control.ensure_control_tables(db)
    summary = RunSummary(run_id=uuid.uuid4().hex[:12])
    ui_log = log

    def log(message: str) -> None:  # noqa: F811 - tee: caller's log + persisted run events
        ui_log(message)
        match = re.match(r"\[([A-Za-z0-9_]+)\]", message)
        control.log_event(db, summary.run_id, message, match.group(1) if match else None)

    results: List[Optional[Dict[str, Any]]] = [None] * len(configs)

    def work(index: int) -> None:
        cfg = configs[index]
        if should_stop():
            log(f"[{cfg.object_name}] skipped: stop requested")
            results[index] = {"object": cfg.object_name, "status": "SKIPPED"}
            return
        if is_running(db, cfg.object_name):
            log(f"[{cfg.object_name}] skipped: another run is still in progress")
            results[index] = {"object": cfg.object_name, "status": "SKIPPED"}
            return
        pipeline = IncrementalPipeline(cfg, sf, db, summary.run_id, trigger, user, full_refresh, reconcile, log)
        try:
            results[index] = pipeline.run()
        except Exception as exc:
            results[index] = {"object": cfg.object_name, "status": "FAILED", "error": str(exc)}

    sizes = {i: _estimate(sf, c) for i, c in enumerate(configs)}
    order = sorted(range(len(configs)), key=lambda i: -sizes[i])          # longest jobs first
    pool_size = max(1, min(len(configs) or 1, workers or object_workers()))
    log(f"Run {summary.run_id}: {len(configs)} object(s), {pool_size} at a time, "
        f"up to {sf_concurrency()} concurrent Salesforce requests")
    with ThreadPoolExecutor(max_workers=pool_size) as pool:
        list(pool.map(work, order))
    summary.results = [r for r in results if r]
    return summary
