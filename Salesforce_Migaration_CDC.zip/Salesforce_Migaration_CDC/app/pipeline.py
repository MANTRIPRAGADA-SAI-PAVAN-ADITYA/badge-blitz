"""Incremental Salesforce -> Snowflake sync for one object, plus a runner for many.

Per object, per run:
  1. describe() the object -> resolve fields, watermark field, IsDeleted support
  2. read the stored watermark (none = initial full load)
  3. stream rows with SystemModstamp > watermark (queryAll, so soft-deletes come too)
  4. bulk-insert them into a TEMPORARY all-varchar stage table
  5. classify rows INSERT / UPDATE / DELETE into CDC_CHANGE_LOG, then MERGE into the target
  6. optionally reconcile hard deletes (ID diff against Salesforce)
  7. only after the MERGE succeeds, advance the watermark and close the run-log row

Soft-deleted rows are kept in the target with ISDELETED = true (history is
preserved); objects with no IsDeleted field are handled by the ID-diff reconcile.
"""
from __future__ import annotations

import os
import re
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence

from app import control
from app.metadata import ObjectConfig, validate_identifier
from app.orchestrator import build_soql_query, parse_sf_datetime, to_soql_datetime
from app.salesforce_client import SalesforceClient
from app.snowflake_client import SnowflakeClient

BATCH_SIZE = 5000
# SOQL goes over HTTP; very wide objects (hundreds of fields) must be fetched in
# column groups that are re-joined on Id, or Salesforce rejects the query as too long.
MAX_SOQL_CHARS = 12000
# Compound / binary fields cannot be bulk-queried or stored as plain columns.
SKIP_SF_TYPES = {"address", "location", "base64", "anyType"}
SNOWFLAKE_TYPES = {
    "boolean": "BOOLEAN",
    "int": "NUMBER(38,0)",
    "long": "NUMBER(38,0)",
    "double": "FLOAT",
    "currency": "FLOAT",
    "percent": "FLOAT",
    "date": "DATE",
    "datetime": "TIMESTAMP_TZ",
    "time": "TIME",
}

Log = Callable[[str], None]


def _q(column: str) -> str:
    return '"' + column.upper() + '"'


def to_text(value: Any, sf_type: str) -> Optional[str]:
    """Normalise a Salesforce value to the text form staged in Snowflake."""
    if value is None:
        return None
    if isinstance(value, bool):
        return "true" if value else "false"
    if sf_type == "datetime" and isinstance(value, str):
        dt = parse_sf_datetime(value)
        return dt.strftime("%Y-%m-%dT%H:%M:%S.") + f"{dt.microsecond // 1000:03d}+00:00"
    return str(value)


def chunk_fields(fields: Sequence[str], required: Sequence[str], max_chars: int = MAX_SOQL_CHARS) -> List[List[str]]:
    """Split ``fields`` into SOQL-sized groups; every group starts with ``required`` (Id, watermark, IsDeleted)."""
    required = list(required)
    rest = [f for f in fields if f not in required]
    base = len(", ".join(required))
    chunks: List[List[str]] = []
    current: List[str] = []
    size = base
    for f in rest:
        if current and size + len(f) + 2 > max_chars:
            chunks.append(required + current)
            current, size = [], base
        current.append(f)
        size += len(f) + 2
    chunks.append(required + current)
    return chunks


def add_missing_columns_enabled() -> bool:
    return (os.getenv("CDC_ADD_MISSING_COLUMNS") or "true").strip().lower() not in ("0", "false", "no")


@dataclass
class ObjectPlan:
    """What describe() tells us about how to sync an object."""
    fields: List[str]
    types: Dict[str, str]
    watermark_field: Optional[str]
    has_is_deleted: bool


def build_plan(config: ObjectConfig, describe_fields: Sequence[Dict[str, Any]]) -> ObjectPlan:
    by_lower = {f["name"].lower(): f for f in describe_fields}
    if config.fields:
        unknown = [f for f in config.fields if f.lower() not in by_lower]
        if unknown:
            raise ValueError(f"{config.object_name}: unknown field(s) {', '.join(unknown)}")
        wanted = [by_lower[f.lower()]["name"] for f in config.fields]
        for required in ("Id", "SystemModstamp", "LastModifiedDate", "IsDeleted"):
            if required.lower() in by_lower and required not in wanted:
                wanted.append(required)
    else:
        wanted = [f["name"] for f in describe_fields if f["type"] not in SKIP_SF_TYPES]
    if "Id" not in wanted:
        raise ValueError(f"{config.object_name} has no Id field and cannot be synced.")

    names = {n.lower() for n in wanted}
    watermark_field = (
        "SystemModstamp" if "systemmodstamp" in names
        else "LastModifiedDate" if "lastmodifieddate" in names
        else None
    )
    return ObjectPlan(
        fields=wanted,
        types={n: by_lower[n.lower()]["type"] for n in wanted},
        watermark_field=watermark_field,
        has_is_deleted="isdeleted" in names,
    )


class IncrementalPipeline:
    """Syncs one Salesforce object into one Snowflake table."""

    def __init__(
        self,
        config: ObjectConfig,
        sf: SalesforceClient,
        db: SnowflakeClient,
        run_id: str,
        trigger: str = "manual",
        user: str = "",
        full_refresh: bool = False,
        reconcile: bool = False,
        log: Log = print,
    ):
        self.config = config
        self.sf = sf
        self.db = db
        self.run_id = run_id
        self.trigger = trigger
        self.user = user
        self.full_refresh = full_refresh
        self.reconcile = reconcile
        self.log = log
        self.target = validate_identifier(config.target_table, "target table")
        self.stage = f"CDC_STG_{self.target}"[:250]

    # ---- orchestration ---------------------------------------------------
    def run(self) -> Dict[str, Any]:
        obj = self.config.object_name
        stats = {"extracted": 0, "inserted": 0, "updated": 0, "deleted": 0}
        stored = None if self.full_refresh else control.get_watermark(self.db, obj)
        control.start_run(self.db, self.run_id, obj, self.trigger, self.user, stored)
        new_watermark: Optional[str] = None
        try:
            plan = build_plan(self.config, self.sf.describe_fields(obj))
            target_cols = self._ensure_target(plan)
            if plan.watermark_field is None:
                stored = None  # nothing to filter on: always a full pull
            self.log(f"[{obj}] {len(plan.fields)} fields, watermark={plan.watermark_field}, "
                     f"since={stored or 'beginning (full load)'}")

            max_seen = self._extract_to_stage(plan, target_cols, stored, stats)
            if stats["extracted"]:
                self._classify_and_merge(plan, target_cols, stats)
            if plan.watermark_field and max_seen:
                new_watermark = to_soql_datetime(max_seen)
                control.set_watermark(self.db, obj, plan.watermark_field, new_watermark)

            if self.reconcile or not plan.has_is_deleted:
                stats["deleted"] += self._reconcile_deletes(plan, target_cols)

            control.finish_run(self.db, self.run_id, obj, "SUCCESS", stats, new_watermark or stored)
            self.log(f"[{obj}] done: +{stats['inserted']} new, ~{stats['updated']} updated, "
                     f"-{stats['deleted']} deleted")
        except Exception as exc:
            self.log(f"[{obj}] FAILED: {exc}")
            control.finish_run(self.db, self.run_id, obj, "FAILED", stats, stored, str(exc))
            raise
        return {"object": obj, "status": "SUCCESS", **stats}

    # ---- steps -----------------------------------------------------------
    def _ensure_target(self, plan: ObjectPlan) -> List[str]:
        """Create the target if missing; add any columns it lacks (unless disabled)."""
        existing = self.db.table_columns(self.target)
        if not existing:
            cols = ",\n".join(
                f"{_q(f)} {SNOWFLAKE_TYPES.get(plan.types[f], 'VARCHAR')}" for f in plan.fields
            )
            self.db.execute(f"CREATE TABLE {self.target} (\n{cols}\n)")
            self.log(f"[{self.config.object_name}] created table {self.target}")
            return [f.upper() for f in plan.fields]
        if "ID" not in existing:
            raise ValueError(f"Existing table {self.target} has no ID column.")
        missing = [f for f in plan.fields if f.upper() not in existing]
        if missing and add_missing_columns_enabled():
            # Schema evolution: add what Salesforce has but the table lacks (nullable, additive only).
            for f in missing:
                self.db.execute(
                    f"ALTER TABLE {self.target} ADD COLUMN IF NOT EXISTS "
                    f"{_q(f)} {SNOWFLAKE_TYPES.get(plan.types[f], 'VARCHAR')}"
                )
            self.log(f"[{self.config.object_name}] added {len(missing)} missing column(s) to {self.target}: "
                     f"{', '.join(missing)}")
            existing = existing + [f.upper() for f in missing]
            missing = []
        elif missing:
            self.log(f"[{self.config.object_name}] not in {self.target}, skipped: {', '.join(missing)}")
        return [f.upper() for f in plan.fields if f.upper() in existing]

    def _extract_to_stage(self, plan: ObjectPlan, target_cols: List[str], since: Optional[str],
                          stats: Dict[str, int]) -> Optional[datetime]:
        # The watermark and IsDeleted columns are always staged: they drive the
        # incremental filter, dedup ordering and change classification.
        required = ["Id"] + [f for f in (plan.watermark_field, "IsDeleted" if plan.has_is_deleted else None) if f]
        fields = [f for f in plan.fields if f.upper() in target_cols or f in required]
        # Staging columns are VARCHAR so Snowflake does the type coercion in MERGE.
        stage_cols = ", ".join(f"{_q(f)} VARCHAR" for f in fields)
        self.db.execute(f"CREATE OR REPLACE TEMPORARY TABLE {self.stage} ({stage_cols})")

        chunks = chunk_fields(fields, required)
        if len(chunks) > 1:
            self.log(f"[{self.config.object_name}] {len(fields)} fields -> fetching in {len(chunks)} column groups")

        max_seen: Optional[datetime] = None
        for index, chunk in enumerate(chunks):
            table = self.stage if index == 0 else f"{self.stage}_P"
            if index:
                self.db.execute(
                    f"CREATE OR REPLACE TEMPORARY TABLE {table} ({', '.join(f'{_q(f)} VARCHAR' for f in chunk)})"
                )
            seen, count = self._stream_chunk(plan, chunk, table, since)
            if index == 0:
                max_seen, stats["extracted"] = seen, count
            else:
                self._join_chunk_into_stage(table, chunk, required)
        self.log(f"[{self.config.object_name}] extracted {stats['extracted']} rows")
        return max_seen

    def _stream_chunk(self, plan: ObjectPlan, chunk: List[str], table: str,
                      since: Optional[str]) -> "tuple[Optional[datetime], int]":
        if plan.watermark_field:
            soql = build_soql_query(self.config.object_name, chunk, since, plan.watermark_field)
        else:
            soql = f"SELECT {', '.join(chunk)} FROM {self.config.object_name}"
        insert = (f"INSERT INTO {table} ({', '.join(_q(f) for f in chunk)}) "
                  f"VALUES ({', '.join(['%s'] * len(chunk))})")
        max_seen: Optional[datetime] = None
        count = 0
        batch: List[List[Optional[str]]] = []
        for record in self.sf.query_iter(soql, include_deleted=plan.has_is_deleted):
            batch.append([to_text(record.get(f), plan.types[f]) for f in chunk])
            if plan.watermark_field and record.get(plan.watermark_field):
                ts = parse_sf_datetime(record[plan.watermark_field])
                if max_seen is None or ts > max_seen:
                    max_seen = ts
            if len(batch) >= BATCH_SIZE:
                self.db.executemany(insert, batch)
                count += len(batch)
                batch = []
        if batch:
            self.db.executemany(insert, batch)
            count += len(batch)
        return max_seen, count

    def _join_chunk_into_stage(self, part: str, chunk: List[str], required: List[str]) -> None:
        """Copy a later column group into the stage rows, matched on Id. A row that only
        appears in a later group changed after group 1 ran, so the next run picks it up."""
        cols = [f for f in chunk if f not in required]
        if not cols:
            return
        updates = ", ".join(f"s.{_q(c)} = p.{_q(c)}" for c in cols)
        self.db.execute(
            f"MERGE INTO {self.stage} s USING "
            f"(SELECT * FROM {part} QUALIFY ROW_NUMBER() OVER (PARTITION BY {_q('Id')} ORDER BY {_q('Id')}) = 1) p "
            f"ON s.{_q('Id')} = p.{_q('Id')} WHEN MATCHED THEN UPDATE SET {updates}"
        )

    def _classify_and_merge(self, plan: ObjectPlan, target_cols: List[str], stats: Dict[str, int]) -> None:
        order = _q(plan.watermark_field) if plan.watermark_field and plan.watermark_field.upper() in target_cols \
            else _q("Id")
        # If an Id appears twice in one batch (changed again mid-run) keep the newest.
        latest = (f"SELECT * FROM {self.stage} "
                  f"QUALIFY ROW_NUMBER() OVER (PARTITION BY {_q('Id')} ORDER BY {order} DESC) = 1")

        deleted_case = (f"WHEN LOWER(s.{_q('IsDeleted')}) = 'true' THEN 'DELETE' "
                        if plan.has_is_deleted else "")
        self.db.execute(
            f"""
            INSERT INTO CDC_CHANGE_LOG (RUN_ID, OBJECT_NAME, RECORD_ID, CHANGE_TYPE)
            SELECT %s, %s, s.{_q('Id')},
                   CASE {deleted_case}WHEN t.{_q('Id')} IS NULL THEN 'INSERT' ELSE 'UPDATE' END
            FROM ({latest}) s
            LEFT JOIN {self.target} t ON t.{_q('Id')} = s.{_q('Id')}
            """,
            (self.run_id, self.config.object_name),
        )

        non_key = [c for c in target_cols if c != "ID"]
        updates = ", ".join(f"t.{_q(c)} = s.{_q(c)}" for c in non_key)
        merge = f"""
            MERGE INTO {self.target} t
            USING ({latest}) s ON t.{_q('Id')} = s.{_q('Id')}
            {f'WHEN MATCHED THEN UPDATE SET {updates}' if updates else ''}
            WHEN NOT MATCHED THEN INSERT ({', '.join(_q(c) for c in target_cols)})
                 VALUES ({', '.join('s.' + _q(c) for c in target_cols)})
        """
        self.db.execute(merge)
        self._load_change_counts(stats)

    def _load_change_counts(self, stats: Dict[str, int]) -> None:
        rows = self.db.fetch_all(
            "SELECT CHANGE_TYPE, COUNT(*) FROM CDC_CHANGE_LOG "
            "WHERE RUN_ID = %s AND OBJECT_NAME = %s GROUP BY CHANGE_TYPE",
            (self.run_id, self.config.object_name),
        )
        counts = {r[0]: int(r[1]) for r in rows}
        stats["inserted"] = counts.get("INSERT", 0)
        stats["updated"] = counts.get("UPDATE", 0)
        stats["deleted"] = counts.get("DELETE", 0)

    def _reconcile_deletes(self, plan: ObjectPlan, target_cols: List[str]) -> int:
        """Hard deletes never appear in a SystemModstamp query (nor, after ~15 days,
        in queryAll) - find them by diffing live Salesforce Ids against the target."""
        obj = self.config.object_name
        ids = [[r["Id"]] for r in self.sf.query_iter(f"SELECT Id FROM {obj}")]
        live = f"CDC_IDS_{self.target}"[:250]
        self.db.execute(f"CREATE OR REPLACE TEMPORARY TABLE {live} (ID VARCHAR)")
        self.db.executemany(f"INSERT INTO {live} (ID) VALUES (%s)", ids)

        total = self.db.fetch_one(f"SELECT COUNT(*) FROM {self.target}")[0]
        if not ids and total:
            raise RuntimeError(f"Reconcile aborted: Salesforce returned 0 {obj} Ids but {self.target} "
                               f"holds {total} rows. Refusing to delete everything.")

        soft = plan.has_is_deleted and "ISDELETED" in target_cols
        not_live = f"{_q('Id')} NOT IN (SELECT ID FROM {live})"
        guard = f" AND COALESCE(LOWER({_q('IsDeleted')}), 'false') <> 'true'" if soft else ""
        removed = self.db.execute(
            f"""
            INSERT INTO CDC_CHANGE_LOG (RUN_ID, OBJECT_NAME, RECORD_ID, CHANGE_TYPE)
            SELECT %s, %s, {_q('Id')}, 'DELETE' FROM {self.target} WHERE {not_live}{guard}
            """,
            (self.run_id, obj),
        )
        if soft:
            # ISDELETED may be BOOLEAN or text depending on how the table was created.
            self.db.execute(f"UPDATE {self.target} SET {_q('IsDeleted')} = TRUE WHERE {not_live}{guard}")
        else:
            self.db.execute(f"DELETE FROM {self.target} WHERE {not_live}")
        self.log(f"[{obj}] reconcile found {removed} hard-deleted rows")
        return int(removed)


# ---- multi-object runner ---------------------------------------------------
STALE_RUN_HOURS = 3


def is_running(db: SnowflakeClient, object_name: str) -> bool:
    """True if a run for this object started recently and has not finished (any trigger)."""
    row = db.fetch_one(
        "SELECT COUNT(*) FROM CDC_RUN_LOG WHERE OBJECT_NAME = %s AND STATUS = 'RUNNING' "
        "AND STARTED_AT > DATEADD(hour, -%s, CURRENT_TIMESTAMP())",
        (object_name, STALE_RUN_HOURS),
    )
    return bool(row and row[0])


@dataclass
class RunSummary:
    run_id: str
    results: List[Dict[str, Any]] = field(default_factory=list)

    @property
    def failed(self) -> int:
        return sum(1 for r in self.results if r["status"] == "FAILED")


def run_objects(
    configs: Iterable[ObjectConfig],
    sf: SalesforceClient,
    db: SnowflakeClient,
    trigger: str = "manual",
    user: str = "",
    full_refresh: bool = False,
    reconcile: bool = False,
    log: Log = print,
    should_stop: Callable[[], bool] = lambda: False,
) -> RunSummary:
    """Run every given object. One object failing never stops the others."""
    control.ensure_control_tables(db)
    summary = RunSummary(run_id=uuid.uuid4().hex[:12])
    ui_log = log

    def log(message: str) -> None:  # noqa: F811 - tee: caller's log + persisted run events
        ui_log(message)
        match = re.match(r"\[([A-Za-z0-9_]+)\]", message)
        control.log_event(db, summary.run_id, message, match.group(1) if match else None)

    for cfg in configs:
        if should_stop():
            log("Stop requested - remaining objects skipped.")
            break
        if is_running(db, cfg.object_name):
            log(f"[{cfg.object_name}] skipped: another run is still in progress")
            summary.results.append({"object": cfg.object_name, "status": "SKIPPED"})
            continue
        pipeline = IncrementalPipeline(cfg, sf, db, summary.run_id, trigger, user, full_refresh, reconcile, log)
        try:
            summary.results.append(pipeline.run())
        except Exception as exc:
            summary.results.append({"object": cfg.object_name, "status": "FAILED", "error": str(exc)})
    return summary
