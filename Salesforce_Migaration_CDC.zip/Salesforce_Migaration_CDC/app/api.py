"""Web API + web UI host.

    python -m app.api            ->  http://127.0.0.1:8000

Serves the React app from ``webui/dist`` (build it once with ``npm run build`` in
``webui/``) and the JSON API under ``/api``. Binds to localhost by default; put it
behind Azure AD / App Service authentication before exposing it.
"""
from __future__ import annotations

import getpass
import threading
from pathlib import Path
from typing import List, Optional

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from app import control
from app.metadata import ObjectConfig, validate_identifier
from app.runner import BackgroundRunner
from app.salesforce_client import SalesforceClient
from app.service import Service, jsonable
from app.snowflake_client import SnowflakeClient
from config.settings import CONFIG

DIST = Path(__file__).resolve().parent.parent / "webui" / "dist"


class State:
    """Lazily-created connections shared by every request."""

    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.db: Optional[SnowflakeClient] = None
        self._sf: Optional[SalesforceClient] = None
        self.service: Optional[Service] = None
        self.runner: Optional[BackgroundRunner] = None

    def problems(self) -> List[str]:
        out = []
        if not CONFIG.snowflake.can_connect():
            out.append("Snowflake is not configured (SNOWFLAKE_ACCOUNT / USER and a password, key or SSO).")
        if not CONFIG.salesforce.has_api_credentials():
            out.append("Salesforce is not configured (SF_USERNAME/PASSWORD, client credentials, token or JWT).")
        return out

    def sf(self) -> SalesforceClient:
        with self.lock:
            if self._sf is None:
                self._sf = SalesforceClient()
            return self._sf

    def connect(self) -> None:
        with self.lock:
            if self.db is not None:
                return
            db = SnowflakeClient()
            control.ensure_control_tables(db)
            self.db = db
            self.service = Service(db, self.sf)
            self.runner = BackgroundRunner(db)

    def disconnect(self) -> None:
        with self.lock:
            if self.db is not None:
                self.db.close()
            self.db = self._sf = self.service = self.runner = None


state = State()
app = FastAPI(title="Salesforce CDC Control Centre")


def svc() -> Service:
    if state.service is None:
        raise HTTPException(409, "Not connected. Click Connect first.")
    return state.service


@app.exception_handler(ValueError)
async def value_error(_: Request, exc: ValueError):
    return JSONResponse({"detail": str(exc)}, status_code=400)


@app.exception_handler(Exception)
async def unhandled(_: Request, exc: Exception):
    return JSONResponse({"detail": f"{type(exc).__name__}: {exc}"}, status_code=500)


# ---- connection / status ----------------------------------------------------------
@app.get("/api/status")
def status():
    info = {
        "problems": state.problems(), "connected": state.db is not None,
        "salesforce_login_url": CONFIG.salesforce.login_url,
        "snowflake_target": f"{CONFIG.snowflake.database}.{CONFIG.snowflake.schema}",
        "snowflake_user": CONFIG.snowflake.user,
        "snowflake_auth": "browser SSO" if CONFIG.snowflake.uses_browser_sso() else "key / password",
        "user": getpass.getuser(),
    }
    if state.db is not None:
        info["session"] = state.db.whoami()
    return info


@app.post("/api/connect")
def connect():
    if state.problems():
        raise HTTPException(400, " ".join(state.problems()))
    state.connect()
    return status()


@app.post("/api/disconnect")
def disconnect():
    state.disconnect()
    return status()


# ---- objects -----------------------------------------------------------------------
class NewObject(BaseModel):
    object_name: str
    target_table: str = ""
    fields: List[str] = []
    note: str = ""


class ObjectPatch(BaseModel):
    enabled: Optional[bool] = None
    fields: Optional[List[str]] = None
    note: Optional[str] = None


@app.get("/api/objects")
def list_objects(s: Service = Depends(svc)):
    return [c.to_dict() for c in s.registry.list()]


@app.get("/api/salesforce/objects")
def salesforce_objects(s: Service = Depends(svc)):
    taken = {c.object_name.lower() for c in s.registry.list()}
    return [o for o in s.sf.list_objects() if o["name"].lower() not in taken]


@app.post("/api/objects")
def add_object(body: NewObject, s: Service = Depends(svc)):
    cfg = ObjectConfig(body.object_name, body.target_table, True, body.fields, body.note)
    if s.registry.get(cfg.object_name):
        raise ValueError(f"{cfg.object_name} is already in the list.")
    described = {f["name"].lower() for f in s.sf.describe_fields(cfg.object_name)}  # raises if the object is absent
    unknown = [f for f in cfg.fields if f.lower() not in described]
    if unknown:
        raise ValueError(f"Unknown field(s) on {cfg.object_name}: {', '.join(unknown)}")
    s.registry.upsert(cfg, getpass.getuser())
    return cfg.to_dict()


@app.patch("/api/objects/{name}")
def patch_object(name: str, body: ObjectPatch, s: Service = Depends(svc)):
    cfg = s.registry.get(name)
    if cfg is None:
        raise HTTPException(404, f"{name} is not configured.")
    if body.enabled is not None:
        cfg.enabled = body.enabled
    if body.fields is not None:
        cfg.fields = [validate_identifier(f, "field") for f in body.fields if f.strip()]
    if body.note is not None:
        cfg.note = body.note
    s.registry.upsert(cfg, getpass.getuser())
    return cfg.to_dict()


@app.delete("/api/objects/{name}")
def delete_object(name: str, s: Service = Depends(svc)):
    s.registry.remove(name)
    return {"removed": name}


@app.get("/api/objects/{name}/columns")
def columns(name: str, s: Service = Depends(svc)):
    return s.column_report(name)


@app.get("/api/objects/{name}/count-compare")
def count_compare(name: str, s: Service = Depends(svc)):
    return s.count_compare(name)


@app.post("/api/objects/{name}/reset-watermark")
def reset_watermark(name: str, s: Service = Depends(svc)):
    s.reset_watermark(name)
    return {"reset": name}


# ---- running ----------------------------------------------------------------------
class RunRequest(BaseModel):
    objects: Optional[List[str]] = None
    full_refresh: bool = False
    reconcile: bool = False


def _run_state():
    r = state.runner
    if r is None:
        return {"running": False}
    return jsonable({
        "running": r.running, "started_at": r.started_at, "log": r.log_lines[-500:], "error": r.error,
        "summary": ({"run_id": r.summary.run_id, "results": r.summary.results, "failed": r.summary.failed}
                    if r.summary else None),
    })


@app.get("/api/run")
def run_status(s: Service = Depends(svc)):
    return _run_state()


@app.post("/api/run")
def start_run(body: RunRequest, s: Service = Depends(svc)):
    configs = s.registry.list(enabled_only=True)
    if body.objects:
        wanted = {n.lower() for n in body.objects}
        configs = [c for c in s.registry.list() if c.object_name.lower() in wanted]
    if not configs:
        raise ValueError("No objects to run. Enable at least one object first.")
    if not state.runner.start(configs, getpass.getuser(), body.full_refresh, body.reconcile):
        raise HTTPException(409, "A run is already in progress.")
    return _run_state()


@app.post("/api/run/stop")
def stop_run(s: Service = Depends(svc)):
    state.runner.stop()
    return _run_state()


# ---- monitoring / investigation ------------------------------------------------------
@app.get("/api/summary")
def summary(hours: int = 24, s: Service = Depends(svc)):
    return s.summary(hours)


@app.get("/api/health")
def health(s: Service = Depends(svc)):
    return s.health()


@app.get("/api/runs")
def runs(hours: int = 24, status: Optional[str] = None, object: Optional[str] = None,
         limit: int = 500, s: Service = Depends(svc)):
    return s.runs(hours, status, object, limit)


@app.get("/api/runs/{run_id}/events")
def run_events(run_id: str, object: Optional[str] = None, s: Service = Depends(svc)):
    return s.run_events(run_id, object)


@app.get("/api/runs/{run_id}/changes")
def run_changes(run_id: str, object: str, type: str = "ALL", s: Service = Depends(svc)):
    return s.changes(run_id, object, type)


@app.get("/api/runs/{run_id}/rows")
def run_rows(run_id: str, object: str, type: str = "ALL", s: Service = Depends(svc)):
    return s.changed_rows(run_id, object, type)


@app.get("/api/records/{record_id}/history")
def record_history(record_id: str, s: Service = Depends(svc)):
    return s.record_history(record_id)


@app.get("/api/records/{object}/{record_id}/compare")
def compare(object: str, record_id: str, s: Service = Depends(svc)):
    return s.compare_record(object, record_id)


# ---- static React app -------------------------------------------------------------------
if DIST.exists():
    app.mount("/assets", StaticFiles(directory=DIST / "assets"), name="assets")

    @app.get("/{path:path}", include_in_schema=False)
    def spa(path: str):
        target = DIST / path
        return FileResponse(target if path and target.is_file() else DIST / "index.html")
else:
    @app.get("/", include_in_schema=False)
    def no_build():
        return JSONResponse({"detail": "Web UI not built. Run `npm install && npm run build` in webui/, "
                                       "or use `npm run dev` there. API docs: /docs"})


def main() -> None:
    import os
    import uvicorn
    uvicorn.run(app, host=os.getenv("CDC_HOST", "127.0.0.1"), port=int(os.getenv("CDC_PORT", "8000")))


if __name__ == "__main__":
    main()
