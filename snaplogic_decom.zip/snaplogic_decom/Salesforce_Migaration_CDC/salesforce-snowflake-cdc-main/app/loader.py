"""Building blocks for loading big objects fast and safely.

* tuning knobs (environment variables, read at call time)
* Id-range partition planning
* gzip-CSV staging files that Snowflake ingests with PUT + COPY INTO
* retries and a global cap on concurrent Salesforce requests
"""
from __future__ import annotations

import csv
import gzip
import os
import re
import sys
import threading
import time
from dataclasses import dataclass
from typing import Any, Callable, Dict, Iterable, Iterator, List, Optional, Sequence

from app.orchestrator import parse_sf_datetime

NULL_MARK = r"\N"            # what we write for NULL; the COPY file format maps it back
RETRY_DELAY = 2.0            # seconds, doubled each attempt (tests set this to 0)
_ID = re.compile(r"^[A-Za-z0-9]{15,18}$")
csv.field_size_limit(min(sys.maxsize, 2**31 - 1))  # long-text fields exceed csv's 128 KB default


# ---- tuning ---------------------------------------------------------------
def _env_int(name: str, default: int) -> int:
    try:
        return max(0, int(os.getenv(name) or default))
    except ValueError:
        return default


def sf_concurrency() -> int:
    """Max simultaneous Salesforce requests across the whole process."""
    return max(1, _env_int("CDC_SF_CONCURRENCY", 4))


def object_workers() -> int:
    """How many objects are synced at the same time."""
    return max(1, _env_int("CDC_OBJECT_WORKERS", 3))


def partition_rows() -> int:
    """Target rows per Id-range partition (objects at or below this are not split)."""
    return max(1, _env_int("CDC_PARTITION_ROWS", 50000))


def bulk_threshold() -> int:
    """With load strategy 'auto', objects with at least this many rows to fetch use the Bulk API."""
    return _env_int("CDC_BULK_THRESHOLD", 100000)


def overlap_seconds() -> int:
    """Safety margin subtracted from the run start time to form the next watermark."""
    return _env_int("CDC_OVERLAP_SECONDS", 300)


_slots: Dict[int, threading.BoundedSemaphore] = {}
_slots_lock = threading.Lock()


def sf_slot() -> threading.BoundedSemaphore:
    """Use as ``with sf_slot():`` around every Salesforce fetch."""
    size = sf_concurrency()
    with _slots_lock:
        return _slots.setdefault(size, threading.BoundedSemaphore(size))


# ---- partitions -------------------------------------------------------------
@dataclass(frozen=True)
class Partition:
    """A half-open Id range [lo, hi); None means unbounded on that side."""
    index: int
    lo: Optional[str] = None
    hi: Optional[str] = None

    def __post_init__(self) -> None:
        for bound in (self.lo, self.hi):
            if bound is not None and not _ID.match(bound):
                raise ValueError(f"Not a Salesforce Id: {bound!r}")


def plan_partitions(sorted_ids: Sequence[str], rows_per_partition: int) -> List[Partition]:
    """Equal-size Id ranges from the object's Ids in Salesforce's ``ORDER BY Id`` order.

    Every Id falls into exactly one range, so the ranges can be fetched in parallel
    and re-run independently.
    """
    if len(sorted_ids) <= rows_per_partition:
        return [Partition(0)]
    bounds = list(sorted_ids[rows_per_partition::rows_per_partition])
    edges: List[Optional[str]] = [None, *bounds, None]
    return [Partition(i, edges[i], edges[i + 1]) for i in range(len(edges) - 1)]


# ---- values & files ---------------------------------------------------------
def to_text(value: Any, sf_type: str) -> Optional[str]:
    """Normalise a Salesforce value to the text form staged in Snowflake."""
    if value is None:
        return None
    if isinstance(value, bool):
        return "true" if value else "false"
    if sf_type == "datetime" and isinstance(value, str):
        dt = parse_sf_datetime(value)
        return dt.strftime("%Y-%m-%dT%H:%M:%S.") + f"{dt.microsecond // 1000:03d}+00:00"
    return str(value)


def write_rows_gz(path: str, rows: Iterable[Sequence[Optional[str]]]) -> int:
    """Stream rows to a gzip CSV; returns the row count. Memory use stays flat."""
    count = 0
    with gzip.open(path, "wt", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        for row in rows:
            writer.writerow([NULL_MARK if v is None else v for v in row])
            count += 1
    return count


def bulk_missing_columns(path: str, fields: Sequence[str]) -> List[str]:
    """Fields we asked for that the Bulk result file does not have a column for.

    Some Salesforce bulk exports are headerless, in which case there is nothing to
    validate against and the fields are assumed to be in the query order.
    """
    with open(path, newline="", encoding="utf-8") as handle:
        reader = csv.reader(handle)
        first = next(reader, None)
        if not first:
            return []
        field_names = {f.lower() for f in fields}
        header_row = bool(first) and all((cell or "").strip().lower() in field_names for cell in first)
        if header_row:
            have = {name.lower() for name in first}
            return [f for f in fields if f.lower() not in have]
        return []


def bulk_csv_rows(path: str, fields: Sequence[str], types: Dict[str, str]) -> Iterator[List[Optional[str]]]:
    """Read a Bulk API 2.0 result file in ``fields`` order, converting to the same
    text form the REST path produces. Bulk CSV has no NULL: an empty cell is NULL.

    Some Bulk API exports include a CSV header row and some do not. Both forms are
    supported: if the first row looks like a header, we map by name; otherwise, we
    assume the file is in the same order as the requested ``fields``.
    """
    with open(path, newline="", encoding="utf-8") as handle:
        reader = csv.reader(handle)
        first = next(reader, None)
        if first is None:
            return

        field_names = {f.lower() for f in fields}
        header_row = bool(first) and all((cell or "").strip().lower() in field_names for cell in first)
        if header_row:
            have = {name.lower() for name in first}
            missing = [f for f in fields if f.lower() not in have]
            if missing:
                raise ValueError(f"Bulk result is missing column {missing[0]}")
            position = {name.lower(): i for i, name in enumerate(first)}
            try:
                order = [position[f.lower()] for f in fields]
            except KeyError as missing:
                raise ValueError(f"Bulk result is missing column {missing}") from None
            rows = reader
        else:
            if len(first) != len(fields):
                raise ValueError(f"Bulk result is missing column {fields[min(len(first), len(fields) - 1)]}")
            order = list(range(len(fields)))
            rows = [first, *reader]

        for row in rows:
            if len(row) < len(fields):
                row = row + [""] * (len(fields) - len(row))
            elif len(row) > len(fields):
                row = row[:len(fields)]
            yield [to_text(row[i], types[f]) if row[i] != "" else None for i, f in zip(order, fields)]


# ---- resilience ---------------------------------------------------------------
_PERMANENT = ("Malformed", "AuthenticationFailed", "ResourceNotFound", "Expired")


def with_retries(fn: Callable[[], Any], attempts: int = 3, log: Callable[[str], None] = lambda m: None,
                 what: str = "request") -> Any:
    """Retry transient failures (timeouts, 5xx, rate limits) with exponential back-off.
    Permanent errors (bad query, bad credentials, bad input) fail immediately."""
    for attempt in range(attempts):
        try:
            return fn()
        except Exception as exc:
            permanent = isinstance(exc, ValueError) or any(tag in type(exc).__name__ for tag in _PERMANENT)
            if permanent or attempt == attempts - 1:
                raise
            delay = RETRY_DELAY * (2 ** attempt)
            log(f"{what} failed ({type(exc).__name__}: {exc}); retry {attempt + 1}/{attempts - 1} in {delay:g}s")
            time.sleep(delay)
