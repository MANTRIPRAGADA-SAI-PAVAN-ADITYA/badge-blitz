import html
import json
import os
import subprocess
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
STATUS = {
    "last_run": None,
    "last_status": "Not started",
    "last_output": "",
    "last_error": "",
}


def env_summary():
    required = [
        "SF_USERNAME",
        "SF_PASSWORD",
        "SF_SECURITY_TOKEN",
        "SF_LOGIN_URL",
        "SNOWFLAKE_ACCOUNT",
        "SNOWFLAKE_USER",
        "SNOWFLAKE_PASSWORD",
        "SNOWFLAKE_ROLE",
        "SNOWFLAKE_WAREHOUSE",
        "SNOWFLAKE_DATABASE",
        "SNOWFLAKE_SCHEMA",
    ]

    present = []
    missing = []
    for key in required:
        if os.getenv(key):
            present.append(key)
        else:
            missing.append(key)

    return {
        "present": present,
        "missing": missing,
        "ready": len(missing) == 0,
    }


def run_pipeline_once():
    status = STATUS
    status["last_run"] = "running"
    status["last_status"] = "Running"
    status["last_output"] = ""
    status["last_error"] = ""

    try:
        completed = subprocess.run(
            [sys.executable, "-m", "app.main"],
            cwd=str(PROJECT_ROOT),
            capture_output=True,
            text=True,
            check=False,
        )

        output = (completed.stdout or "") + (completed.stderr or "")
        status["last_output"] = output.strip()

        lower_output = output.lower()
        config_missing = (
            "credentials are null" in lower_output
            or "before running the extractor" in lower_output
            or "set snowflake environment values" in lower_output
        )

        if completed.returncode != 0:
            status["last_status"] = "Failed"
            status["last_error"] = f"Exit code: {completed.returncode}"
        elif config_missing:
            status["last_status"] = "Blocked: missing config"
            status["last_error"] = "Missing Salesforce or Snowflake credentials in environment variables."
        else:
            status["last_status"] = "Succeeded"
            status["last_error"] = ""
    except Exception as exc:
        status["last_output"] = ""
        status["last_status"] = "Failed"
        status["last_error"] = str(exc)

    status["last_run"] = "completed"


class LauncherHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/":
            self.send_html(home_page())
        elif self.path == "/status":
            self.send_html(status_page())
        else:
            self.send_error(404, "Not found")

    def do_POST(self):
        if self.path == "/run":
            thread = threading.Thread(target=run_pipeline_once, daemon=True)
            thread.start()
            self.send_redirect("/status")
        else:
            self.send_error(404, "Not found")

    def send_html(self, body):
        encoded = body.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

    def send_redirect(self, path):
        self.send_response(302)
        self.send_header("Location", path)
        self.end_headers()

    def log_message(self, format, *args):
        return


def _status_badge(value):
    if value == "Succeeded":
        return "<span style='color:#0a7a51;font-weight:700'>Succeeded</span>"
    if value.startswith("Blocked"):
        return "<span style='color:#b45309;font-weight:700'>Blocked</span>"
    if value == "Failed":
        return "<span style='color:#b91c1c;font-weight:700'>Failed</span>"
    if value == "Running":
        return "<span style='color:#1f5bcf;font-weight:700'>Running</span>"
    return "<span style='color:#475569;font-weight:700'>Not started</span>"


def home_page():
    summary = env_summary()
    status_html = _status_badge(STATUS["last_status"])

    return f"""
    <!doctype html>
    <html>
    <head>
        <meta charset="utf-8" />
        <title>Salesforce CDC Control</title>
        <style>
            :root {{
                --bg: #f4f7fb;
                --panel: #ffffff;
                --line: #dfe7f2;
                --primary: #1f5bcf;
                --primary-soft: #e8f0ff;
                --success: #0a7a51;
                --warning: #b45309;
                --danger: #b91c1c;
                --text: #172033;
                --muted: #4b5873;
            }}
            * {{ box-sizing: border-box; }}
            body {{ font-family: Arial, sans-serif; margin: 0; background: var(--bg); color: var(--text); }}
            .wrap {{ max-width: 1100px; margin: 40px auto; padding: 0 20px; }}
            .hero {{ background: linear-gradient(135deg, #eef5ff 0%, #edfdf9 100%); border: 1px solid var(--line); border-radius: 18px; padding: 28px; box-shadow: 0 12px 28px rgba(15, 23, 42, 0.06); }}
            h1 {{ margin: 0 0 8px 0; font-size: 2.2rem; }}
            p {{ color: var(--muted); line-height: 1.6; }}
            .grid {{ display: grid; grid-template-columns: 1.2fr 0.8fr; gap: 22px; margin-top: 22px; }}
            .panel {{ background: var(--panel); border: 1px solid var(--line); border-radius: 16px; padding: 22px; box-shadow: 0 10px 26px rgba(15,23,42,0.04); }}
            .btn {{ display: inline-block; background: var(--primary); color: white; border: 0; border-radius: 10px; padding: 12px 20px; font-size: 15px; cursor: pointer; text-decoration: none; font-weight: 700; }}
            .secondary {{ background: #f8fafc; border: 1px solid var(--line); color: var(--text); }}
            .pill {{ display: inline-block; padding: 6px 10px; border-radius: 999px; background: var(--primary-soft); border: 1px solid var(--primary); color: var(--primary); font-size: 12px; font-weight: 700; }}
            .status-box {{ margin-top: 16px; padding: 14px 16px; border-radius: 12px; background: #f8fafc; border: 1px solid var(--line); }}
            .muted {{ color: var(--muted); }}
            .codes {{ background: #0f172a; color: #e2e8f0; padding: 12px; border-radius: 10px; font-family: Consolas, monospace; font-size: 12px; overflow: auto; }}
            .alert {{ background: #fff7ed; border: 1px solid #fed7aa; color: var(--warning); padding: 12px 14px; border-radius: 10px; font-weight: 700; }}
            .success {{ background: #ecfdf5; border: 1px solid #a7f3d0; color: var(--success); }}
            .link-row {{ display: flex; gap: 16px; align-items: center; flex-wrap: wrap; margin-top: 18px; }}
            a {{ color: var(--primary); text-decoration: none; font-weight: 700; }}
            pre {{ white-space: pre-wrap; word-break: break-word; font-family: Consolas, monospace; margin: 0; }}
        </style>
    </head>
    <body>
        <div class="wrap">
            <div class="hero">
                <div class="pill">Sandbox → Snowflake Control</div>
                <h1>Salesforce CDC Control Center</h1>
                <p>Run the Salesforce-to-Snowflake pipeline, review status, and open the monitoring dashboard.</p>

                <div class="link-row">
                    <form method="post" action="/run" style="display:inline;">
                        <button class="btn" type="submit">Run Pipeline</button>
                    </form>
                    <a href="/status">View status</a>
                    <a href="http://localhost:8501" target="_blank">Open Streamlit dashboard</a>
                </div>
            </div>

            <div class="grid">
                <div class="panel">
                    <h2>Status</h2>
                    <div class="status-box">
                        <strong>Pipeline:</strong> {status_html}<br>
                        <strong>Last run:</strong> {html.escape(str(STATUS['last_run'] or 'Not started'))}<br>
                        <strong>Last error:</strong> {html.escape(STATUS['last_error'] or 'None')}
                    </div>

                    <h3 style="margin-top: 22px;">Latest output</h3>
                    <div class="codes">
                        <pre>{html.escape(STATUS['last_output'] or 'No output yet')}</pre>
                    </div>
                </div>

                <div class="panel">
                    <h2>Environment check</h2>
                    <p class="muted">Required config for the project.</p>
                    {('''<div class="success" style="padding: 12px 14px; border-radius: 10px; font-weight:700;">Environment looks ready.</div>''') if summary['ready'] else '''<div class="alert">Environment is not ready yet. Missing keys are shown below.</div>'''}
                    <div style="margin-top: 16px;">
                        <strong>Missing:</strong>
                        <div class="codes" style="margin-top: 8px;">
                            <pre>{html.escape(', '.join(summary['missing']) if summary['missing'] else 'None')}</pre>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
    </html>
    """


def status_page():
    summary = env_summary()
    return f"""
    <!doctype html>
    <html>
    <head>
        <title>CDC Status</title>
        <style>
        body {{ font-family: Arial, sans-serif; margin: 40px; background: #f4f7fb; color: #172033; }}
        .card {{ max-width: 900px; margin: 0 auto; background: #fff; border: 1px solid #dfe7f2; border-radius: 16px; padding: 28px; box-shadow: 0 10px 26px rgba(15,23,42,0.04); }}
        .row {{ display: flex; gap: 16px; flex-wrap: wrap; margin-top: 18px; }}
        .badge {{ padding: 8px 12px; border-radius: 999px; font-weight: 700; }}
        .ok {{ background: #ecfdf5; color: #0a7a51; border: 1px solid #a7f3d0; }}
        .warn {{ background: #fff7ed; color: #b45309; border: 1px solid #fed7aa; }}
        .codes {{ background: #0f172a; color: #e2e8f0; padding: 12px; border-radius: 10px; margin-top: 10px; white-space: pre-wrap; font-family: Consolas, monospace; }}
        a {{ color: #1f5bcf; text-decoration: none; font-weight: 700; }}
        .btn {{ background: #1f5bcf; color: white; padding: 10px 16px; border-radius: 10px; text-decoration: none; display: inline-block; }}
        </style>
    </head>
    <body>
        <div class="card">
            <h2>Pipeline Status</h2>
            <div class="row">
                <div class="badge {('ok' if STATUS['last_status'] == 'Succeeded' else 'warn')}">{_status_badge(STATUS['last_status'])}</div>
                <a class="btn" href="/">Back to launcher</a>
                <a class="btn" href="http://localhost:8501" target="_blank">Open dashboard</a>
            </div>

            <div style="margin-top: 20px;">
                <strong>Last run:</strong> {html.escape(str(STATUS['last_run'] or 'Not started'))}<br>
                <strong>Last error:</strong> {html.escape(STATUS['last_error'] or 'None')}
            </div>

            <div class="codes"><pre>{html.escape(STATUS['last_output'] or 'No output yet')}</pre></div>

            <div style="margin-top: 24px;">
                <h3>Environment summary</h3>
                <div class="row">
                    <div class="badge {'ok' if summary['ready'] else 'warn'}">{'Ready' if summary['ready'] else 'Needs config'}</div>
                </div>
                <div class="codes"><pre>{html.escape(', '.join(summary['missing']) if summary['missing'] else 'No missing variables')}</pre></div>
            </div>
        </div>
    </body>
    </html>
    """


def main():
    host = "127.0.0.1"
    port = 5000
    server = ThreadingHTTPServer((host, port), LauncherHandler)
    print(f"Snowflake CDC launcher running at http://{host}:{port}")
    print("Use the browser UI to run the pipeline and open the dashboard.")
    server.serve_forever()


if __name__ == "__main__":
    main()
