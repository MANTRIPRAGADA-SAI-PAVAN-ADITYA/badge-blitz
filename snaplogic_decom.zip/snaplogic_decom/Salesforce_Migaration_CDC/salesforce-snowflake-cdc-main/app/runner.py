"""Runs the pipeline in a background thread so the UI stays responsive."""
from __future__ import annotations

import re
import threading
from datetime import datetime
from typing import List, Optional

from app.control import classify_level
from app.metadata import ObjectConfig
from app.pipeline import RunSummary, run_objects
from app.salesforce_client import SalesforceClient
from app.snowflake_client import SnowflakeClient


class BackgroundRunner:
    """One run at a time per UI process (the run log guards across processes)."""

    def __init__(self, db: SnowflakeClient):
        self.db = db
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self.log_lines: List[str] = []
        self.events: List[dict] = []          # structured: ts, level, object, message
        self.summary: Optional[RunSummary] = None
        self.error: Optional[str] = None
        self.started_at: Optional[datetime] = None

    @property
    def running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def start(self, configs: List[ObjectConfig], user: str, full_refresh: bool = False, reconcile: bool = False) -> bool:
        if self.running:
            return False
        self._stop.clear()
        self.log_lines, self.events, self.summary, self.error = [], [], None, None
        self.started_at = datetime.now()
        self._thread = threading.Thread(
            target=self._work, args=(configs, user, full_refresh, reconcile), daemon=True
        )
        self._thread.start()
        return True

    def stop(self) -> None:
        """Finish the object in progress, then skip the rest."""
        self._stop.set()

    def _log(self, message: str) -> None:
        now = datetime.now()
        tag = re.match(r"\[([A-Za-z0-9_]+)\]", message)
        self.events.append({"ts": now.isoformat(timespec="seconds"), "level": classify_level(message),
                            "object": tag.group(1) if tag else None, "message": message})
        self.log_lines.append(f"{now:%H:%M:%S}  {message}")

    def _work(self, configs, user, full_refresh, reconcile) -> None:
        try:
            self._log("Connecting to Salesforce...")
            sf = SalesforceClient()
            self.summary = run_objects(
                configs, sf, self.db, trigger="manual", user=user,
                full_refresh=full_refresh, reconcile=reconcile,
                log=self._log, should_stop=self._stop.is_set,
            )
            self._log(f"Finished run {self.summary.run_id} ({self.summary.failed} failed)")
        except Exception as exc:  # connection / auth problems before any object ran
            self.error = str(exc)
            self._log(f"ERROR: {exc}")
