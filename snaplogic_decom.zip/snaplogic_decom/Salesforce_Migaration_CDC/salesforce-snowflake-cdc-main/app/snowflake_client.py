from __future__ import annotations

import threading
from typing import Any, List, Optional, Sequence

import snowflake.connector
from snowflake.connector.errors import ProgrammingError

from config.settings import CONFIG


class SnowflakeSqlError(RuntimeError):
    """A SQL statement failed. The message carries Snowflake's error AND the statement,
    so a log line alone is enough to see which identifier or clause was wrong."""


class SnowflakeClient:
    """Thin Snowflake helper. All values go through bind parameters; identifiers
    interpolated into SQL are validated upstream (see app.metadata)."""

    # One connection is shared by the worker threads; statements are serialised by this lock
    # (the slow part - fetching from Salesforce - runs outside it, in parallel).
    _lock = threading.RLock()

    def __init__(self):
        self.conn = self._connect()

    def _connect(self):
        config = CONFIG.snowflake
        if not config.can_connect():
            raise ValueError(
                "Snowflake authentication is not configured. "
                "Set SNOWFLAKE_USER and either SNOWFLAKE_PASSWORD, SNOWFLAKE_TOKEN, SNOWFLAKE_PRIVATE_KEY(_FILE), "
                "or SNOWFLAKE_AUTHENTICATOR=externalbrowser for SSO."
            )

        connect_kwargs = {
            "account": config.account,
            "user": config.user,
            "role": config.role,
            "warehouse": config.warehouse,
            "database": config.database,
            "schema": config.schema,
        }

        if config.password:
            connect_kwargs["password"] = config.password
        if config.authenticator:
            connect_kwargs["authenticator"] = config.authenticator
        if config.token:
            connect_kwargs["token"] = config.token

        # Browser SSO: do not also pass key-based auth arguments. Cache the SSO
        # token so repeated connections don't each pop a browser window.
        if config.authenticator and config.authenticator.lower() == "externalbrowser":
            connect_kwargs["client_store_temporary_credential"] = True
            return snowflake.connector.connect(**connect_kwargs)

        if config.private_key:
            connect_kwargs["private_key"] = config.private_key
        if config.private_key_file:
            connect_kwargs["private_key_file"] = config.private_key_file
        if config.private_key_file_pwd:
            connect_kwargs["private_key_file_pwd"] = config.private_key_file_pwd.encode("utf-8")
        if config.private_key_passphrase:
            connect_kwargs["private_key_passphrase"] = config.private_key_passphrase.encode("utf-8")

        return snowflake.connector.connect(**connect_kwargs)

    def close(self) -> None:
        try:
            self.conn.close()
        except Exception:  # pragma: no cover - best effort
            pass

    # ---- query helpers ------------------------------------------------
    @staticmethod
    def _exec(cur, sql: str, params=None):
        try:
            return cur.execute(sql, params)
        except ProgrammingError as exc:
            preview = " ".join(sql.split())[:700]
            raise SnowflakeSqlError(f"{exc.msg or exc} | SQL: {preview}") from exc

    def execute(self, sql: str, params: Optional[Sequence[Any]] = None) -> int:
        """Run a statement; returns the affected row count."""
        with self._lock, self.conn.cursor() as cur:
            self._exec(cur, sql, params)
            return cur.rowcount or 0

    def executemany(self, sql: str, rows: Sequence[Sequence[Any]]) -> None:
        if not rows:
            return
        with self._lock, self.conn.cursor() as cur:
            cur.executemany(sql, rows)

    def fetch_one(self, sql: str, params: Optional[Sequence[Any]] = None):
        with self._lock, self.conn.cursor() as cur:
            self._exec(cur, sql, params)
            return cur.fetchone()

    def fetch_all(self, sql: str, params: Optional[Sequence[Any]] = None) -> List[tuple]:
        with self._lock, self.conn.cursor() as cur:
            self._exec(cur, sql, params)
            return cur.fetchall()

    def fetch_dicts(self, sql: str, params: Optional[Sequence[Any]] = None) -> List[dict]:
        """Rows as dicts keyed by column name (upper case)."""
        with self._lock, self.conn.cursor() as cur:
            self._exec(cur, sql, params)
            names = [d[0] for d in cur.description]
            return [dict(zip(names, row)) for row in cur.fetchall()]

    # ---- file loading (PUT + COPY INTO) ------------------------------------
    # In a Snowflake string literal a backslash must be doubled: '\\N' matches the two characters \N.
    CSV_FORMAT = ("TYPE=CSV COMPRESSION=GZIP FIELD_OPTIONALLY_ENCLOSED_BY='\"' "
                  "NULL_IF=('\\\\N') EMPTY_FIELD_AS_NULL=FALSE ESCAPE_UNENCLOSED_FIELD=NONE")

    def put_file(self, local_path: str, stage_dir: str) -> None:
        """Upload a local .csv.gz to an internal stage directory such as ``@~/cdc/run/table/``."""
        self.execute(f"PUT 'file://{local_path.replace(chr(92), '/')}' {stage_dir} AUTO_COMPRESS=FALSE OVERWRITE=TRUE")

    def copy_csv(self, table: str, columns: Sequence[str], stage_dir: str, file_name: str) -> None:
        """Load one staged file into ``table``; the file is purged from the stage afterwards."""
        cols = ", ".join(f'"{c.upper()}"' for c in columns)
        self.execute(
            f"COPY INTO {table} ({cols}) FROM {stage_dir} FILES=('{file_name}') "
            f"FILE_FORMAT=({self.CSV_FORMAT}) ON_ERROR=ABORT_STATEMENT PURGE=TRUE"
        )

    def remove_stage_dir(self, stage_dir: str) -> None:
        try:
            self.execute(f"REMOVE {stage_dir}")
        except Exception:  # best effort cleanup
            pass

    # ---- schema helpers -----------------------------------------------
    def table_columns_exact(self, table_name: str) -> List[str]:
        """Column names exactly as stored (case preserved) - tables created by other tools often
        have quoted mixed-case names such as "Id" that an upper-case "ID" would not match."""
        rows = self.fetch_all(
            "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS "
            "WHERE TABLE_SCHEMA = CURRENT_SCHEMA() AND TABLE_NAME = %s ORDER BY ORDINAL_POSITION",
            (table_name.upper(),),
        )
        return [r[0] for r in rows]

    def table_column_types(self, table_name: str) -> dict:
        """UPPER column name -> a type usable in CAST ('' for text and anything compared as text)."""
        rows = self.fetch_all(
            "SELECT COLUMN_NAME, DATA_TYPE, NUMERIC_PRECISION, NUMERIC_SCALE FROM INFORMATION_SCHEMA.COLUMNS "
            "WHERE TABLE_SCHEMA = CURRENT_SCHEMA() AND TABLE_NAME = %s",
            (table_name.upper(),),
        )
        out = {}
        for name, data_type, precision, scale in rows:
            kind = (data_type or "").upper()
            if kind == "NUMBER" and precision is not None:
                out[name.upper()] = f"NUMBER({precision},{scale or 0})"
            elif kind in ("FLOAT", "BOOLEAN", "DATE", "TIME", "TIMESTAMP_TZ", "TIMESTAMP_LTZ", "TIMESTAMP_NTZ"):
                out[name.upper()] = kind
            else:
                out[name.upper()] = ""
        return out

    def table_columns(self, table_name: str) -> List[str]:
        """Upper-case column names of a table in the current schema ([] if absent)."""
        return [c.upper() for c in self.table_columns_exact(table_name)]

    def whoami(self) -> dict:
        row = self.fetch_one(
            "SELECT CURRENT_USER(), CURRENT_ROLE(), CURRENT_WAREHOUSE(), CURRENT_DATABASE(), CURRENT_SCHEMA()"
        )
        return dict(zip(["user", "role", "warehouse", "database", "schema"], row))
