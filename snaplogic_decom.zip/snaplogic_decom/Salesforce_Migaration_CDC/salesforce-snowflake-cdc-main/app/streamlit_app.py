"""Salesforce -> Snowflake CDC control centre.

    streamlit run app/streamlit_app.py

Three tabs: run the pipeline, manage which objects are synced, monitor changes.
No CLI needed for day-to-day use.
"""
from __future__ import annotations

import getpass
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd
import streamlit as st

from app import control
from app.metadata import ObjectConfig, ObjectRegistry, validate_identifier
from app.runner import BackgroundRunner
from app.service import Service
from app.salesforce_client import SalesforceClient
from app.snowflake_client import SnowflakeClient
from config.settings import CONFIG

st.set_page_config(page_title="Salesforce CDC Control Centre", page_icon="🔄", layout="wide",
                   initial_sidebar_state="expanded")

st.markdown("""
<style>
  .block-container { padding-top: 1.6rem; max-width: 1400px; }
  header[data-testid="stHeader"] { background: transparent; }
  .cdc-hero { background: linear-gradient(120deg,#1f5bcf 0%,#4a8af4 100%); color:#fff;
              padding: 18px 24px; border-radius: 14px; margin-bottom: 14px; }
  .cdc-hero h1 { color:#fff; font-size: 1.6rem; margin:0; padding:0; }
  .cdc-hero p { margin: 4px 0 0 0; opacity:.9; font-size:.95rem; }
  .pill { display:inline-block; padding:2px 10px; border-radius:999px; font-size:.78rem;
          font-weight:600; margin-right:6px; background:rgba(255,255,255,.18); color:#fff; }
  div[data-testid="stMetric"] { background:#fff; border:1px solid #e3e8f2; border-radius:12px;
          padding:12px 16px; box-shadow:0 1px 2px rgba(16,24,40,.05); }
  div[data-testid="stVerticalBlockBorderWrapper"] { border-radius:12px; background:#fff; }
  button[kind="primary"] { border-radius:8px; font-weight:600; }
  .stTabs [data-baseweb="tab-list"] { gap: 6px; border-bottom: 1px solid #dfe5f1; }
  .stTabs [data-baseweb="tab"] { padding: 10px 16px; border-radius: 8px 8px 0 0; font-weight:600; }
  .stTabs [aria-selected="true"] { background:#fff; color:#1f5bcf; }
  section[data-testid="stSidebar"] { background:#fff; border-right:1px solid #e3e8f2; }
  .side-card { border:1px solid #e3e8f2; border-radius:10px; padding:10px 12px; margin-bottom:10px;
               background:#f9fbff; font-size:.85rem; line-height:1.5; }
  .side-card b { color:#1f5bcf; }
  .dot { height:9px; width:9px; border-radius:50%; display:inline-block; margin-right:6px; background:#1a7f37; }
</style>
""", unsafe_allow_html=True)


# ---- shared resources (one per server process, shared by all browser sessions) ----
@st.cache_resource(show_spinner="Connecting to Snowflake (a browser window may open for SSO)...")
def get_db() -> SnowflakeClient:
    return SnowflakeClient()


@st.cache_resource
def get_runner() -> BackgroundRunner:
    return BackgroundRunner(get_db())


@st.cache_resource(show_spinner="Connecting to Salesforce...")
def get_sf() -> SalesforceClient:
    return SalesforceClient()


@st.cache_data(ttl=3600, show_spinner="Loading Salesforce object list...")
def sf_object_names() -> list[str]:
    return sorted(o["name"] for o in get_sf().list_objects())


def current_user() -> str:
    for attr in ("user", "experimental_user"):
        info = getattr(st, attr, None)
        email = getattr(info, "email", None) if info is not None else None
        if email:
            return email
    return getpass.getuser()


def query_df(sql: str, columns: list[str], params=None) -> pd.DataFrame:
    return pd.DataFrame(get_db().fetch_all(sql, params), columns=columns)


# ---- connection gate ----------------------------------------------------------------
st.markdown(
    f"""<div class="cdc-hero"><h1>Salesforce → Snowflake CDC</h1>
    <p>Incremental sync with a full audit trail.</p>
    <span class="pill">Target {CONFIG.snowflake.database}.{CONFIG.snowflake.schema}</span>
    <span class="pill">Source {CONFIG.salesforce.login_url.split('//')[-1].strip('/')}</span></div>""",
    unsafe_allow_html=True)

problems = []
if not CONFIG.snowflake.can_connect():
    problems.append("Snowflake is not configured (SNOWFLAKE_ACCOUNT / USER and a password, key or SSO).")
if not CONFIG.salesforce.has_api_credentials():
    problems.append("Salesforce is not configured (SF_USERNAME/PASSWORD, client credentials, token or JWT).")
if problems:
    st.error("\n\n".join(problems) + "\n\nCopy `.env.example` to `.env` and fill it in, then reload.")
    st.stop()

if not st.session_state.get("connected"):
    st.info(
        f"Target: **{CONFIG.snowflake.database}.{CONFIG.snowflake.schema}** as "
        f"**{CONFIG.snowflake.user}** ({'browser SSO' if CONFIG.snowflake.uses_browser_sso() else 'key/password'})  \n"
        f"Source: **{CONFIG.salesforce.login_url}**"
    )
    if st.button("Connect", type="primary"):
        try:
            db = get_db()
            control.ensure_control_tables(db)
            st.session_state["connected"] = True
            st.rerun()
        except Exception as exc:
            get_db.clear()
            st.error(f"Could not connect to Snowflake: {exc}")
    st.stop()

db = get_db()
registry = ObjectRegistry(db)
runner = get_runner()
service = Service(db, get_sf)

with st.sidebar:
    who = db.whoami()
    st.markdown("### Connection")
    st.markdown(
        f"<div class='side-card'><span class='dot'></span><b>Snowflake</b><br>"
        f"{who['database']}.{who['schema']}<br>role {who['role']}<br>warehouse {who['warehouse']}</div>"
        f"<div class='side-card'><span class='dot'></span><b>Salesforce</b><br>{CONFIG.salesforce.login_url}</div>",
        unsafe_allow_html=True)
    st.caption(f"Signed in as {current_user()}")
    if runner.running:
        st.warning("A run is in progress")
    if st.button("Reconnect", use_container_width=True):
        get_db.clear(); get_sf.clear(); get_runner.clear()
        st.session_state.pop("connected", None)
        st.rerun()

LEVEL_STYLE = {"ERROR": "color:#b42318;font-weight:700", "WARN": "color:#a15c07;font-weight:700"}


def log_panel(events: list, key: str, height: int = 380) -> None:
    """Filterable log: level / object / text filters, a coloured table and a text download.
    Accepts live events (ts, object) and persisted ones (event_ts, object_name, run_id)."""
    frame = pd.DataFrame(
        [{"time": str(e.get("ts") or e.get("event_ts") or "")[:19].replace("T", " "),
          "level": (e.get("level") or "INFO").upper(),
          "object": e.get("object") if "object" in e else e.get("object_name"),
          "run": e.get("run_id"), "message": e.get("message", "")} for e in events],
        columns=["time", "level", "object", "run", "message"])
    if frame.empty:
        st.caption("No log lines yet.")
        return
    c1, c2, c3 = st.columns([2, 2, 3])
    levels = c1.multiselect("Level", ["INFO", "WARN", "ERROR"], default=["INFO", "WARN", "ERROR"], key=f"{key}_lv")
    objects = c2.multiselect("Object", sorted(frame["object"].dropna().unique()), key=f"{key}_ob")
    needle = c3.text_input("Search", key=f"{key}_q")
    view = frame[frame["level"].isin(levels)]
    if objects:
        view = view[view["object"].isin(objects)]
    if needle:
        view = view[view["message"].str.contains(needle, case=False, regex=False)]
    counts = frame["level"].value_counts()
    st.caption(f"{len(view):,} of {len(frame):,} lines  |  {counts.get('ERROR', 0)} errors  |  {counts.get('WARN', 0)} warnings")
    shown = view if not frame["run"].isna().all() else view.drop(columns=["run"])
    st.dataframe(shown.style.map(lambda v: LEVEL_STYLE.get(v, ""), subset=["level"]),
                 hide_index=True, use_container_width=True, height=height,
                 column_config={"message": st.column_config.TextColumn(width="large")})
    text = chr(10).join(f"{r.time} {r.level:<5} {r.message}" for r in view.itertuples())
    st.download_button("Download log", text, file_name=f"{key}.txt", key=f"{key}_dl")


tab_run, tab_objects, tab_monitor, tab_logs, tab_audit, tab_investigate = st.tabs(
    ["▶ Run pipeline", "🗂 Objects", "📊 Monitor", "📜 Logs", "📝 Audit log", "🔎 Investigate"])

# ===================================================================================
# RUN
# ===================================================================================
with tab_run:
    enabled = registry.list(enabled_only=True)
    if not enabled:
        st.warning("No objects are enabled yet. Add or enable objects in the **Objects** tab.")
    names = [c.object_name for c in enabled]
    k = st.columns(3)
    k[0].metric("Enabled objects", len(enabled))
    k[1].metric("Status", "Running" if runner.running else "Idle")
    k[2].metric("Last run", (f"{runner.summary.failed} failed" if runner.summary and runner.summary.failed
                             else "OK") if runner.summary else "-")
    box = st.container(border=True)
    box.markdown("#### Run settings")
    chosen = box.multiselect("Objects to run", names, default=names, disabled=runner.running)
    c1, c2 = box.columns(2)
    full_refresh = c1.checkbox(
        "Full refresh (ignore watermark, reload everything)", disabled=runner.running,
        help="Re-reads every row. Safe - the MERGE is idempotent - but slow for big objects.")
    reconcile = c2.checkbox(
        "Also detect hard deletes (ID comparison)", disabled=runner.running,
        help="Finds rows purged from Salesforce's recycle bin. Always on for objects without IsDeleted.")

    b1, b2, _ = box.columns([1, 1, 3])
    if b1.button("▶ Run now", type="primary", disabled=runner.running or not chosen, use_container_width=True):
        runner.start([c for c in enabled if c.object_name in chosen], current_user(), full_refresh, reconcile)
        st.rerun()
    if b2.button("Stop after current object", disabled=not runner.running, use_container_width=True):
        runner.stop()

    @st.fragment(run_every=2)
    def live_log() -> None:
        if runner.running:
            st.info(f"Running since {runner.started_at:%H:%M:%S}...")
        elif runner.error:
            st.error(runner.error)
        elif runner.summary:
            s = runner.summary
            (st.error if s.failed else st.success)(
                f"Run {s.run_id} finished: {len(s.results)} objects, {s.failed} failed.")
            st.dataframe(pd.DataFrame(s.results), use_container_width=True, hide_index=True)
        if runner.events:
            st.subheader("Live log")
            log_panel(runner.events[-5000:], key="live_log", height=420)

    live_log()

# ===================================================================================
# OBJECTS
# ===================================================================================
with tab_objects:
    st.caption("Changes here apply to the next run - scheduled or manual - with no code change. "
               "Removing an object stops syncing it; its Snowflake table and history are kept.")
    configs = registry.list()
    df = pd.DataFrame([
        {"Enabled": c.enabled, "Object": c.object_name, "Target table": c.target_table,
         "Load": c.load_strategy, "Fields (blank = all)": ", ".join(c.fields), "Note": c.note}
        for c in configs
    ])
    edited = st.data_editor(
        df, hide_index=True, use_container_width=True, key="objects_editor",
        disabled=["Object", "Target table"],
        column_config={"Enabled": st.column_config.CheckboxColumn(),
                       "Load": st.column_config.SelectboxColumn(options=["auto", "rest", "bulk"],
                                                                help="auto = REST normally, Bulk API 2.0 for big loads")},
    )
    if st.button("Save changes"):
        changed = 0
        for old, new in zip(configs, edited.to_dict("records")):
            fields = [f.strip() for f in str(new["Fields (blank = all)"] or "").split(",") if f.strip()]
            if (old.enabled, old.fields, old.note, old.load_strategy) != (
                    bool(new["Enabled"]), fields, new["Note"] or "", new["Load"]):
                try:
                    registry.upsert(ObjectConfig(old.object_name, old.target_table, bool(new["Enabled"]),
                                                 fields, new["Note"] or "", new["Load"]), current_user())
                    changed += 1
                except ValueError as exc:
                    st.error(str(exc))
        st.success(f"Saved {changed} change(s).") if changed else st.info("Nothing to save.")
        st.rerun() if changed else None

    st.divider()
    st.subheader("Column coverage & tools")
    if configs:
        inspect = st.selectbox("Object", [c.object_name for c in configs], key="inspect_obj")
        t1, t2, t3 = st.columns(3)
        if t1.button("Check columns"):
            try:
                rep = service.column_report(inspect)
                m = st.columns(4)
                m[0].metric("Fields in Salesforce", rep["salesforce_fields"])
                m[1].metric("In Snowflake", rep["synced"])
                m[2].metric("To be added", rep["missing"])
                m[3].metric("Excluded", rep["excluded"])
                st.caption(f"Target `{rep['target_table']}` " + ("exists." if rep["table_exists"] else "will be created on the first run.")
                           + " Missing columns are added automatically on the next run.")
                if rep["target_only_columns"]:
                    st.caption("Only in Snowflake: " + ", ".join(rep["target_only_columns"]))
                st.dataframe(pd.DataFrame(rep["fields"]), hide_index=True, use_container_width=True)
            except Exception as exc:
                st.error(str(exc))
        if t2.button("Compare row counts"):
            try:
                cc = service.count_compare(inspect)
                st.metric("Salesforce (live)", f"{cc['salesforce_live']:,}")
                st.metric("Snowflake (live)", f"{cc['snowflake_live']:,}")
                (st.success if cc["in_sync"] else st.warning)("Counts match." if cc["in_sync"] else "Counts differ - consider a full refresh with hard-delete detection.")
            except Exception as exc:
                st.error(str(exc))
        if t3.button("Force full reload next run"):
            service.reset_watermark(inspect)
            st.success(f"{inspect} will fully reload on its next run.")

    st.divider()
    st.subheader("Add an object")
    try:
        suggestions = [n for n in sf_object_names() if n.lower() not in {c.object_name.lower() for c in configs}]
    except Exception as exc:
        suggestions = []
        st.warning(f"Could not list Salesforce objects ({exc}). Type the API name instead.")
    with st.form("add_object", clear_on_submit=True):
        a1, a2 = st.columns(2)
        picked = a1.selectbox("Pick from Salesforce", [""] + suggestions)
        typed = a2.text_input("...or type the API name", placeholder="Custom_Object__c")
        target = st.text_input("Target table (blank = object name in upper case)")
        only_fields = st.text_input("Only these fields (comma separated, blank = all)")
        strategy = st.selectbox("Load strategy", ["auto", "rest", "bulk"],
                                help="auto = REST normally, Bulk API 2.0 for big loads")
        if st.form_submit_button("Validate and add"):
            name = (typed or picked).strip()
            try:
                if not name:
                    raise ValueError("Choose or type an object.")
                validate_identifier(name, "object name")
                if registry.get(name):
                    raise ValueError(f"{name} is already in the list.")
                fields = [f.strip() for f in only_fields.split(",") if f.strip()]
                cfg = ObjectConfig(name, target.strip(), True, fields, load_strategy=strategy)
                described = {f["name"].lower() for f in get_sf().describe_fields(name)}  # raises if absent
                unknown = [f for f in cfg.fields if f.lower() not in described]
                if unknown:
                    raise ValueError(f"Unknown field(s) on {name}: {', '.join(unknown)}")
                registry.upsert(cfg, current_user())
                st.success(f"Added {name} → {cfg.target_table}. It will load on the next run.")
                st.rerun()
            except Exception as exc:
                st.error(f"Could not add: {exc}")

    st.subheader("Remove objects")
    to_remove = st.multiselect("Objects to stop syncing", [c.object_name for c in configs])
    confirm = st.checkbox("Yes, remove them from the sync list (data in Snowflake is kept)")
    if st.button("Remove selected", disabled=not (to_remove and confirm)):
        for name in to_remove:
            registry.remove(name)
        st.success(f"Removed {', '.join(to_remove)}.")
        st.rerun()

# ===================================================================================
# MONITOR
# ===================================================================================
with tab_monitor:
    window = st.select_slider("Look back", options=[6, 12, 24, 72, 168, 720], value=24,
                              format_func=lambda h: f"{h}h" if h < 48 else f"{h // 24}d")
    runs = query_df(
        "SELECT RUN_ID, OBJECT_NAME, TRIGGER_TYPE, TRIGGERED_BY, STARTED_AT, ENDED_AT, STATUS, "
        "ROWS_EXTRACTED, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, WATERMARK_FROM, WATERMARK_TO, ERROR_MESSAGE "
        "FROM CDC_RUN_LOG WHERE STARTED_AT >= DATEADD(hour, -%s, CURRENT_TIMESTAMP()) ORDER BY STARTED_AT DESC",
        control.RUN_LOG_COLUMNS, (window,),
    )
    if runs.empty:
        st.info("No runs in this window yet.")
    else:
        for col in ["ROWS_EXTRACTED", "ROWS_INSERTED", "ROWS_UPDATED", "ROWS_DELETED"]:
            runs[col] = pd.to_numeric(runs[col]).fillna(0).astype(int)
        k = st.columns(5)
        k[0].metric("Inserted", int(runs["ROWS_INSERTED"].sum()))
        k[1].metric("Updated", int(runs["ROWS_UPDATED"].sum()))
        k[2].metric("Deleted", int(runs["ROWS_DELETED"].sum()))
        k[3].metric("Object runs", len(runs))
        k[4].metric("Failures", int((runs["STATUS"] == "FAILED").sum()))

        st.subheader("Object health")
        st.dataframe(pd.DataFrame(service.health()), hide_index=True, use_container_width=True)

        st.subheader("Changes by object")
        by_obj = runs.groupby("OBJECT_NAME")[["ROWS_INSERTED", "ROWS_UPDATED", "ROWS_DELETED"]].sum()
        st.bar_chart(by_obj)

        failed = runs[runs["STATUS"] == "FAILED"]
        if not failed.empty:
            st.subheader("Failures")
            st.dataframe(failed[["STARTED_AT", "OBJECT_NAME", "ERROR_MESSAGE"]], hide_index=True, use_container_width=True)

        st.subheader("Run history")
        st.dataframe(runs, hide_index=True, use_container_width=True)

        st.subheader("Drill into a run")
        labels = [f"{r.RUN_ID} · {r.OBJECT_NAME} · {r.STARTED_AT:%Y-%m-%d %H:%M}" for r in runs.itertuples()]
        pick = st.selectbox("Run", labels)
        row = runs.iloc[labels.index(pick)]
        with st.expander("Run log (persisted)"):
            log_panel(service.run_events(row.RUN_ID), key=f"run_{row.RUN_ID}", height=320)
        if row.ERROR_MESSAGE:
            st.error(row.ERROR_MESSAGE)
        kind = st.radio("Change type", ["ALL", "INSERT", "UPDATE", "DELETE"], horizontal=True)
        cond, params = "RUN_ID = %s AND OBJECT_NAME = %s", [row.RUN_ID, row.OBJECT_NAME]
        if kind != "ALL":
            cond += " AND CHANGE_TYPE = %s"
            params.append(kind)
        changes = query_df(
            f"SELECT RECORD_ID, CHANGE_TYPE, CHANGE_TS FROM CDC_CHANGE_LOG WHERE {cond} ORDER BY CHANGE_TS LIMIT 5000",
            ["RECORD_ID", "CHANGE_TYPE", "CHANGE_TS"], params,
        )
        st.caption(f"{len(changes)} changed record ids (max 5000 shown)")
        st.dataframe(changes, hide_index=True, use_container_width=True)

        if st.button("Show current rows from the target table (max 1000)") and not changes.empty:
            cfg = registry.get(row.OBJECT_NAME)
            table = validate_identifier(cfg.target_table if cfg else row.OBJECT_NAME.upper(), "table")
            with db.conn.cursor() as cur:
                cur.execute(
                    f'SELECT t.*, c.CHANGE_TYPE AS "_CHANGE_TYPE" FROM {table} t '
                    f'JOIN (SELECT RECORD_ID, CHANGE_TYPE FROM CDC_CHANGE_LOG WHERE {cond}) c ON t."ID" = c.RECORD_ID LIMIT 1000',
                    params,
                )
                data = pd.DataFrame(cur.fetchall(), columns=[d[0] for d in cur.description])
            st.dataframe(data, hide_index=True, use_container_width=True)


# ===================================================================================
# LOGS
# ===================================================================================
with tab_logs:
    st.caption("Every line of every run - scheduled or manual - is saved. Search across runs.")
    f1, f2, f3, f4 = st.columns([1, 1, 1, 1])
    log_hours = f1.selectbox("Time window", [1, 6, 24, 72, 168, 720], index=2,
                             format_func=lambda h: f"Last {h}h" if h < 48 else f"Last {h // 24}d")
    log_levels = f2.multiselect("Level", ["INFO", "WARN", "ERROR"], default=["WARN", "ERROR"])
    log_object = f3.selectbox("Object", [""] + [c.object_name for c in registry.list()], key="log_object")
    log_run = f4.text_input("Run id")
    g1, g2 = st.columns([3, 1])
    log_text = g1.text_input("Contains text")
    log_limit = g2.selectbox("Max lines", [500, 2000, 5000, 20000], index=1)
    try:
        found = service.search_events(log_hours, log_run.strip() or None, log_object or None,
                                      log_levels, log_text or None, log_limit)
        if len(found) >= log_limit:
            st.warning(f"Showing the newest {log_limit:,} matching lines - narrow the filters to see more.")
        log_panel(list(reversed(found)), key="logs_search", height=560)
    except Exception as exc:
        st.error(str(exc))

# ===================================================================================
# AUDIT LOG
# ===================================================================================
with tab_audit:
    st.caption("Every attribute change the pipeline detected: record, field, OLD value, NEW value, who changed it "
               "in Salesforce and when. Nothing is filtered unless you choose to - the default is everything.")
    a1, a2, a3, a4 = st.columns(4)
    audit_window = a1.selectbox("Time window", [0, 24, 72, 168, 720], key="audit_hours",
                                format_func=lambda h: "All time" if h == 0 else (f"Last {h}h" if h < 48 else f"Last {h // 24}d"))
    audit_object = a2.selectbox("Object", [""] + [c.object_name for c in registry.list()], key="audit_object")
    audit_change = a3.selectbox("Change", ["", "UPDATE", "INSERT", "DELETE"], key="audit_change",
                                format_func=lambda v: {"": "All", "UPDATE": "Field changed", "INSERT": "Record created",
                                                       "DELETE": "Record deleted"}[v])
    audit_limit = a4.selectbox("Max rows", [500, 2000, 10000, 50000], index=1, key="audit_limit")
    b1, b2, b3, b4 = st.columns(4)
    audit_record = b1.text_input("Record Id", key="audit_record").strip()
    audit_field = b2.text_input("Field name", key="audit_field").strip()
    audit_text = b3.text_input("Old or new value contains", key="audit_text")
    audit_run = b4.text_input("Run id", key="audit_run").strip()
    try:
        audit_rows = service.audit(audit_window or None, audit_object or None, audit_record or None,
                                   audit_field or None, audit_run or None, audit_change or None,
                                   audit_text or None, audit_limit)
        frame = pd.DataFrame(audit_rows, columns=["changed_at", "object_name", "record_id", "change_type", "field_name",
                                                  "old_value", "new_value", "modified_by", "record_modstamp", "run_id"])
        k = st.columns(4)
        k[0].metric("Audit rows", f"{len(frame):,}")
        k[1].metric("Attribute changes", f"{int(frame['field_name'].notna().sum()):,}")
        k[2].metric("Records", f"{frame['record_id'].nunique():,}")
        k[3].metric("Distinct fields", f"{frame['field_name'].nunique():,}")
        if len(frame) >= audit_limit:
            st.warning(f"Showing the newest {audit_limit:,} rows - narrow the filters or raise Max rows.")
        st.dataframe(frame, hide_index=True, use_container_width=True, height=520)
        st.download_button("Download CSV", frame.to_csv(index=False), file_name="cdc-audit-log.csv", key="audit_dl")
    except Exception as exc:
        st.error(str(exc))

# ===================================================================================
# INVESTIGATE
# ===================================================================================
with tab_investigate:
    st.caption("Paste a Salesforce record Id to see every change the pipeline logged for it, or compare "
               "Salesforce with Snowflake field by field.")
    i1, i2 = st.columns([2, 1])
    record_id = i1.text_input("Record Id", placeholder="0015000000AbCdE").strip()
    obj_choice = i2.selectbox("Object", [""] + [c.object_name for c in registry.list()])
    b1, b2 = st.columns(2)
    try:
        if b1.button("Change history", disabled=not record_id):
            hist = service.record_history(record_id)
            if hist:
                st.dataframe(pd.DataFrame(hist), hide_index=True, use_container_width=True)
            else:
                st.info("No logged changes for this Id. Its object may not be enabled, or it has not changed since the last full load.")
        if b2.button("Compare Salesforce <-> Snowflake", type="primary", disabled=not (record_id and obj_choice)):
            res = service.compare_record(obj_choice, record_id)
            flags = st.columns(3)
            flags[0].metric("In Salesforce", "yes" if res["in_salesforce"] else "no")
            flags[1].metric("In Snowflake", "yes" if res["in_snowflake"] else "no")
            flags[2].metric("Differing fields", res["differences"])
            if res["in_salesforce"] and not res["in_snowflake"]:
                st.warning("In Salesforce but not Snowflake - run this object (or a full refresh).")
            if res["in_snowflake"] and not res["in_salesforce"]:
                st.warning("In Snowflake but gone from Salesforce - hard-deleted. Run with hard-delete detection.")
            only_diff = st.checkbox("Only differences", value=res["differences"] > 0)
            frame = pd.DataFrame(res["fields"])
            st.dataframe(frame[frame["status"] == "different"] if only_diff else frame, hide_index=True, use_container_width=True)
            st.subheader("Audit trail - what changed in this record")
            trail = pd.DataFrame(res.get("audit", []))
            if trail.empty:
                st.info("No attribute changes recorded for this record yet.")
            else:
                st.dataframe(trail, hide_index=True, use_container_width=True)
            st.subheader("Logged changes")
            st.dataframe(pd.DataFrame(res["history"]), hide_index=True, use_container_width=True)
    except Exception as exc:
        st.error(str(exc))
