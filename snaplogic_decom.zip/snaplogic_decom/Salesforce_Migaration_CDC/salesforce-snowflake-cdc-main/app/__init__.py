"""Application package for Salesforce to Snowflake incremental ingestion."""
