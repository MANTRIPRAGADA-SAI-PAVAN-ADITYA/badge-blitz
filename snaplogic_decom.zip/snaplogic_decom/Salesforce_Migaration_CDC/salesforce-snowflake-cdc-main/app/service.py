"""Read-side operations shared by both UIs (Streamlit and the web app):
monitoring, health, column coverage and record-level investigation.

Everything returned is JSON-serialisable.
"""
from __future__ import annotations

import re
from datetime import date, datetime, timezone
from decimal import Decimal
from typing import Any, Callable, Dict, List, Optional

from app.control import classify_level
from app.metadata import ObjectConfig, ObjectRegistry, validate_identifier
from app.pipeline import SKIP_SF_TYPES, build_plan, to_text
from app.salesforce_client import SalesforceClient
from app.snowflake_client import SnowflakeClient

_SF_ID = re.compile(r"^[A-Za-z0-9]{15,18}$")
STALE_AFTER_HOURS = 8  # 6-hourly schedule + slack


def jsonable(value: Any) -> Any:
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, Decimal):
        return float(value)
    if isinstance(value, dict):
        return {k: jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [jsonable(v) for v in value]
    return value


def lower_keys(rows: List[dict]) -> List[dict]:
    return [{k.lower(): jsonable(v) for k, v in row.items()} for row in rows]


class Service:
    def __init__(self, db: SnowflakeClient, sf_provider: Callable[[], SalesforceClient]):
        self.db = db
        self._sf_provider = sf_provider
        self.registry = ObjectRegistry(db)

    @property
    def sf(self) -> SalesforceClient:
        return self._sf_provider()

    def _target_table(self, object_name: str) -> str:
        cfg = self.registry.get(object_name)
        return validate_identifier(cfg.target_table if cfg else object_name.upper(), "table")

    # ---- monitoring -----------------------------------------------------
    def summary(self, hours: int = 24) -> Dict[str, Any]:
        window = (int(hours),)
        totals = self.db.fetch_dicts(
            """
            SELECT COALESCE(SUM(ROWS_INSERTED),0) AS INSERTED, COALESCE(SUM(ROWS_UPDATED),0) AS UPDATED,
                   COALESCE(SUM(ROWS_DELETED),0) AS DELETED, COALESCE(SUM(ROWS_EXTRACTED),0) AS EXTRACTED,
                   COUNT(*) AS OBJECT_RUNS, COUNT_IF(STATUS = 'FAILED') AS FAILURES,
                   COUNT_IF(STATUS = 'RUNNING') AS RUNNING
            FROM CDC_RUN_LOG WHERE STARTED_AT >= DATEADD(hour, -%s, CURRENT_TIMESTAMP())
            """, window)
        by_object = self.db.fetch_dicts(
            """
            SELECT OBJECT_NAME, SUM(ROWS_INSERTED) AS INSERTED, SUM(ROWS_UPDATED) AS UPDATED,
                   SUM(ROWS_DELETED) AS DELETED, COUNT(*) AS RUNS, COUNT_IF(STATUS = 'FAILED') AS FAILURES
            FROM CDC_RUN_LOG WHERE STARTED_AT >= DATEADD(hour, -%s, CURRENT_TIMESTAMP())
            GROUP BY OBJECT_NAME ORDER BY OBJECT_NAME
            """, window)
        unit = "hour" if hours <= 48 else "day"
        timeline = self.db.fetch_dicts(
            f"""
            SELECT DATE_TRUNC('{unit}', STARTED_AT) AS BUCKET, SUM(ROWS_INSERTED) AS INSERTED,
                   SUM(ROWS_UPDATED) AS UPDATED, SUM(ROWS_DELETED) AS DELETED
            FROM CDC_RUN_LOG WHERE STARTED_AT >= DATEADD(hour, -%s, CURRENT_TIMESTAMP())
            GROUP BY 1 ORDER BY 1
            """, window)
        return jsonable({
            "hours": hours,
            "totals": lower_keys(totals)[0],
            "by_object": lower_keys(by_object),
            "timeline": lower_keys(timeline),
        })

    def runs(self, hours: int = 24, status: Optional[str] = None, object_name: Optional[str] = None,
             limit: int = 500) -> List[dict]:
        where, params = ["STARTED_AT >= DATEADD(hour, -%s, CURRENT_TIMESTAMP())"], [int(hours)]
        if status:
            where.append("STATUS = %s"); params.append(status.upper())
        if object_name:
            where.append("OBJECT_NAME = %s"); params.append(object_name)
        params.append(int(limit))
        return lower_keys(self.db.fetch_dicts(
            f"SELECT * FROM CDC_RUN_LOG WHERE {' AND '.join(where)} ORDER BY STARTED_AT DESC LIMIT %s", params))

    def run_events(self, run_id: str, object_name: Optional[str] = None) -> List[dict]:
        sql = "SELECT EVENT_TS, OBJECT_NAME, LEVEL, MESSAGE FROM CDC_RUN_EVENTS WHERE RUN_ID = %s"
        params: List[Any] = [run_id]
        if object_name:
            sql += " AND (OBJECT_NAME = %s OR OBJECT_NAME IS NULL)"; params.append(object_name)
        rows = lower_keys(self.db.fetch_dicts(sql + " ORDER BY EVENT_TS", params))
        for row in rows:                                 # lines logged before levels existed
            row["level"] = row.get("level") or classify_level(row.get("message") or "")
        return rows

    def search_events(self, hours: int = 24, run_id: Optional[str] = None, object_name: Optional[str] = None,
                      levels: Optional[List[str]] = None, text: Optional[str] = None,
                      limit: int = 2000) -> List[dict]:
        """Log lines across all runs, newest first. ``levels`` e.g. ['WARN', 'ERROR']; ``text`` is a
        case-insensitive substring match."""
        where, params = ["EVENT_TS >= DATEADD(hour, -%s, CURRENT_TIMESTAMP())"], [int(hours)]
        if run_id:
            where.append("RUN_ID = %s"); params.append(run_id)
        if object_name:
            where.append("OBJECT_NAME = %s"); params.append(object_name)
        wanted = [l.upper() for l in (levels or []) if l.upper() in ("INFO", "WARN", "ERROR")]
        if wanted:
            where.append(f"COALESCE(LEVEL, 'INFO') IN ({', '.join(['%s'] * len(wanted))})"); params.extend(wanted)
        if text:
            where.append("POSITION(LOWER(%s), LOWER(MESSAGE)) > 0"); params.append(text)
        params.append(max(1, min(int(limit), 20000)))
        rows = lower_keys(self.db.fetch_dicts(
            f"SELECT RUN_ID, EVENT_TS, OBJECT_NAME, LEVEL, MESSAGE FROM CDC_RUN_EVENTS "
            f"WHERE {' AND '.join(where)} ORDER BY EVENT_TS DESC LIMIT %s", params))
        for row in rows:
            row["level"] = row.get("level") or classify_level(row.get("message") or "")
        return rows

    def changes(self, run_id: str, object_name: str, change_type: Optional[str] = None,
                limit: int = 5000) -> List[dict]:
        sql = "SELECT RECORD_ID, CHANGE_TYPE, CHANGE_TS FROM CDC_CHANGE_LOG WHERE RUN_ID = %s AND OBJECT_NAME = %s"
        params: List[Any] = [run_id, object_name]
        if change_type and change_type != "ALL":
            sql += " AND CHANGE_TYPE = %s"; params.append(change_type)
        return lower_keys(self.db.fetch_dicts(sql + " ORDER BY CHANGE_TS LIMIT %s", params + [int(limit)]))

    def changed_rows(self, run_id: str, object_name: str, change_type: Optional[str] = None,
                     limit: int = 500) -> List[dict]:
        """Current target rows for the records changed in a run."""
        table = self._target_table(object_name)
        cond, params = "RUN_ID = %s AND OBJECT_NAME = %s", [run_id, object_name]
        if change_type and change_type != "ALL":
            cond += " AND CHANGE_TYPE = %s"; params.append(change_type)
        rows = self.db.fetch_dicts(
            f'SELECT c.CHANGE_TYPE AS "_CHANGE_TYPE", t.* FROM {table} t JOIN '
            f'(SELECT RECORD_ID, CHANGE_TYPE FROM CDC_CHANGE_LOG WHERE {cond}) c ON t."ID" = c.RECORD_ID LIMIT %s',
            params + [int(limit)])
        return lower_keys(rows)

    def health(self) -> List[dict]:
        """One line per configured object: is it syncing, when did it last succeed, how stale is it."""
        out = []
        for cfg in self.registry.list():
            last = self.db.fetch_dicts(
                """
                SELECT STATUS, STARTED_AT, ERROR_MESSAGE FROM CDC_RUN_LOG WHERE OBJECT_NAME = %s
                ORDER BY STARTED_AT DESC LIMIT 1
                """, (cfg.object_name,))
            ok = self.db.fetch_dicts(
                """
                SELECT MAX(ENDED_AT) AS LAST_SUCCESS FROM CDC_RUN_LOG WHERE OBJECT_NAME = %s AND STATUS = 'SUCCESS'
                """, (cfg.object_name,))
            wm = self.db.fetch_one("SELECT LAST_VALUE FROM CDC_WATERMARK WHERE OBJECT_NAME = %s", (cfg.object_name,))
            last_ok = ok[0]["LAST_SUCCESS"] if ok else None
            age_h = None
            if last_ok is not None:
                age_h = round((datetime.now(last_ok.tzinfo) - last_ok).total_seconds() / 3600, 1)
            if not cfg.enabled:
                state = "disabled"
            elif not last:
                state = "never_run"
            elif last[0]["STATUS"] == "FAILED":
                state = "failing"
            elif age_h is None or age_h > STALE_AFTER_HOURS:
                state = "stale"
            else:
                state = "healthy"
            out.append(jsonable({
                "object_name": cfg.object_name, "target_table": cfg.target_table, "enabled": cfg.enabled,
                "state": state, "last_status": last[0]["STATUS"] if last else None,
                "last_started": last[0]["STARTED_AT"] if last else None,
                "last_error": last[0]["ERROR_MESSAGE"] if last else None,
                "last_success": last_ok, "hours_since_success": age_h, "watermark": wm[0] if wm else None,
            }))
        return out

    def reset_watermark(self, object_name: str) -> None:
        """Forces a full reload of this object on its next run."""
        self.db.execute("DELETE FROM CDC_WATERMARK WHERE OBJECT_NAME = %s", (object_name,))

    # ---- column coverage ----------------------------------------------------
    def column_report(self, object_name: str) -> Dict[str, Any]:
        """Every Salesforce field vs. what the target table holds, with the reason for any gap."""
        cfg = self.registry.get(object_name) or ObjectConfig(object_name)
        described = self.sf.describe_fields(object_name)
        plan = build_plan(cfg, described)
        table = validate_identifier(cfg.target_table, "table")
        target_cols = set(self.db.table_columns(table))
        wanted = {f.lower() for f in plan.fields}
        rows = []
        for f in described:
            name = f["name"]
            if name.lower() in wanted:
                status = "synced" if name.upper() in target_cols else (
                    "pending" if target_cols else "new_table")
                reason = ("will be added on next run" if status == "pending" else
                          "table will be created on first run" if status == "new_table" else "")
            elif f["type"] in SKIP_SF_TYPES:
                status, reason = "excluded", f"{f['type']} fields cannot be stored as a column"
            else:
                status, reason = "excluded", "not in this object's field list"
            rows.append({"field": name, "type": f["type"], "label": f.get("label", ""),
                         "status": status, "reason": reason})
        extra = sorted(target_cols - {f["name"].upper() for f in described})
        return {
            "object_name": object_name, "target_table": table, "table_exists": bool(target_cols),
            "salesforce_fields": len(described),
            "synced": sum(r["status"] == "synced" for r in rows),
            "missing": sum(r["status"] in ("pending", "new_table") for r in rows),
            "excluded": sum(r["status"] == "excluded" for r in rows),
            "target_only_columns": extra, "fields": rows,
        }

    # ---- audit log ----------------------------------------------------------
    def audit(self, hours: Optional[int] = None, object_name: Optional[str] = None, record_id: Optional[str] = None,
              field: Optional[str] = None, run_id: Optional[str] = None, change_type: Optional[str] = None,
              text: Optional[str] = None, limit: int = 2000) -> List[dict]:
        """Attribute-level history from CDC_AUDIT_LOG, newest first. Every filter is optional;
        with none, everything is returned (up to ``limit``). ``hours`` None/0 = all time."""
        where: List[str] = []
        params: List[Any] = []
        if hours:
            where.append("CHANGED_AT >= DATEADD(hour, -%s, CURRENT_TIMESTAMP())"); params.append(int(hours))
        for column, value in (("OBJECT_NAME", object_name), ("RECORD_ID", record_id), ("RUN_ID", run_id)):
            if value:
                where.append(f"{column} = %s"); params.append(value)
        if field:
            where.append("UPPER(FIELD_NAME) = UPPER(%s)"); params.append(field)
        if change_type and change_type.upper() in ("INSERT", "UPDATE", "DELETE"):
            where.append("CHANGE_TYPE = %s"); params.append(change_type.upper())
        if text:
            where.append("(POSITION(LOWER(%s), LOWER(COALESCE(OLD_VALUE, ''))) > 0 "
                         "OR POSITION(LOWER(%s), LOWER(COALESCE(NEW_VALUE, ''))) > 0)")
            params.extend([text, text])
        params.append(max(1, min(int(limit), 50000)))
        sql = ("SELECT RUN_ID, OBJECT_NAME, RECORD_ID, CHANGE_TYPE, FIELD_NAME, OLD_VALUE, NEW_VALUE, "
               "RECORD_MODSTAMP, MODIFIED_BY, CHANGED_AT FROM CDC_AUDIT_LOG"
               + (" WHERE " + " AND ".join(where) if where else "")
               + " ORDER BY CHANGED_AT DESC, RECORD_ID, FIELD_NAME LIMIT %s")
        return lower_keys(self.db.fetch_dicts(sql, params))

    def errors(self, hours: Optional[int] = None, object_name: Optional[str] = None,
               run_id: Optional[str] = None, limit: int = 2000) -> List[dict]:
        """Values that could not be loaded (CDC_ERROR_LOG), newest first."""
        where: List[str] = []
        params: List[Any] = []
        if hours:
            where.append("LOGGED_AT >= DATEADD(hour, -%s, CURRENT_TIMESTAMP())"); params.append(int(hours))
        for column, value in (("OBJECT_NAME", object_name), ("RUN_ID", run_id)):
            if value:
                where.append(f"{column} = %s"); params.append(value)
        params.append(max(1, min(int(limit), 50000)))
        sql = ("SELECT RUN_ID, OBJECT_NAME, RECORD_ID, COLUMN_NAME, BAD_VALUE, TARGET_TYPE, ERROR_REASON, LOGGED_AT "
               "FROM CDC_ERROR_LOG" + (" WHERE " + " AND ".join(where) if where else "")
               + " ORDER BY LOGGED_AT DESC LIMIT %s")
        return lower_keys(self.db.fetch_dicts(sql, params))

    # ---- investigation ------------------------------------------------------
    def record_history(self, record_id: str) -> List[dict]:
        """Every change we ever logged for a record id, newest first, across all objects."""
        self._check_id(record_id)
        return lower_keys(self.db.fetch_dicts(
            """
            SELECT c.OBJECT_NAME, c.CHANGE_TYPE, c.CHANGE_TS, c.RUN_ID, r.TRIGGER_TYPE, r.TRIGGERED_BY
            FROM CDC_CHANGE_LOG c LEFT JOIN CDC_RUN_LOG r ON r.RUN_ID = c.RUN_ID AND r.OBJECT_NAME = c.OBJECT_NAME
            WHERE c.RECORD_ID = %s ORDER BY c.CHANGE_TS DESC LIMIT 200
            """, (record_id,)))

    def compare_record(self, object_name: str, record_id: str) -> Dict[str, Any]:
        """Field-by-field: what Salesforce holds right now vs what Snowflake holds."""
        self._check_id(record_id)
        validate_identifier(object_name, "object")
        table = self._target_table(object_name)
        described = {f["name"]: f for f in self.sf.describe_fields(object_name)}
        cols = self.db.table_columns(table)

        sf_names = [n for n, f in described.items() if f["type"] not in SKIP_SF_TYPES]
        sf_row = next(iter(self.sf.query_iter(
            f"SELECT {', '.join(sf_names)} FROM {object_name} WHERE Id = '{record_id}'",
            include_deleted="IsDeleted" in described)), None)
        sf_vals = {n.upper(): to_text(sf_row.get(n), described[n]["type"]) for n in sf_names} if sf_row else None

        snow = self.db.fetch_dicts(f'SELECT * FROM {table} WHERE "ID" = %s', (record_id,))
        sn_vals = {k: (None if v is None else self._norm(v)) for k, v in snow[0].items()} if snow else None

        diffs = []
        for col in sorted(set(cols) | set(sf_vals or {})):
            a = sf_vals.get(col) if sf_vals else None
            b = sn_vals.get(col) if sn_vals else None
            same = self._equal(a, b)
            diffs.append({"field": col, "salesforce": a, "snowflake": b,
                          "status": "match" if same else "different"})
        return jsonable({
            "object_name": object_name, "record_id": record_id, "table": table,
            "in_salesforce": sf_row is not None, "in_snowflake": bool(snow),
            "differences": sum(d["status"] == "different" for d in diffs),
            "fields": diffs,
            "history": self.record_history(record_id),
            "audit": self.audit(record_id=record_id, limit=500),
        })

    def count_compare(self, object_name: str) -> Dict[str, Any]:
        """Live Salesforce row count vs live (non-deleted) Snowflake rows."""
        table = self._target_table(object_name)
        sf_count = self.sf.count(object_name)
        cols = self.db.table_columns(table)
        live = (f'COUNT_IF(COALESCE(LOWER("ISDELETED"::VARCHAR), \'false\') <> \'true\')'
                if "ISDELETED" in cols else "COUNT(*)")
        row = self.db.fetch_one(f"SELECT COUNT(*), {live} FROM {table}")
        return {"object_name": object_name, "salesforce_live": sf_count,
                "snowflake_total": int(row[0]), "snowflake_live": int(row[1]),
                "difference": sf_count - int(row[1]), "in_sync": sf_count == int(row[1])}

    # ---- helpers ------------------------------------------------------------
    @staticmethod
    def _check_id(record_id: str) -> None:
        if not _SF_ID.match(record_id or ""):
            raise ValueError("Not a valid Salesforce record Id (15 or 18 letters/digits).")

    @staticmethod
    def _norm(value: Any) -> str:
        if isinstance(value, bool):
            return "true" if value else "false"
        if isinstance(value, datetime):  # same text form the pipeline stages: UTC, millisecond precision
            utc = (value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value).astimezone(timezone.utc)
            return utc.strftime("%Y-%m-%dT%H:%M:%S.") + f"{utc.microsecond // 1000:03d}+00:00"
        return str(value)

    @staticmethod
    def _equal(a: Optional[str], b: Optional[str]) -> bool:
        if a in (None, "") and b in (None, ""):
            return True
        if a is None or b is None:
            return False
        if a == b:
            return True
        try:  # numeric formatting differences (1.0 vs 1)
            return float(a) == float(b)
        except ValueError:
            return False
