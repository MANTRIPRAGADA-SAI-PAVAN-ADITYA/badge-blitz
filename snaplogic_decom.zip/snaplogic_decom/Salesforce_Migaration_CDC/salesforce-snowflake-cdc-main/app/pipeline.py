"""Incremental Salesforce -> Snowflake sync for one object, plus a parallel runner for many.

Per object, per run:
  1. describe() the object -> fields, watermark field, IsDeleted support
  2. read the stored watermark (none = initial / full load)
  3. plan the work: big objects are split into Id-range partitions (and very wide ones into
     column groups); each slice is one task
  4. fetch tasks in parallel (REST, or Bulk API 2.0 for big loads) into gzip-CSV files
  5. PUT + COPY INTO a transient all-text stage table (Snowflake loads in parallel)
  6. classify rows INSERT / UPDATE / DELETE into CDC_CHANGE_LOG, then MERGE into the target,
     never overwriting a row with an older version
  7. only after the MERGE succeeds, advance the watermark to the run's START time (minus a
     small overlap) so rows changed *during* a long load are picked up by the next run
  8. optionally reconcile hard deletes (ID diff against Salesforce)

Soft-deleted rows are kept in the target with ISDELETED = true (history is preserved).
"""
from __future__ import annotations

import os
import re
import shutil
import tempfile
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Callable, Dict, Iterable, Iterator, List, Optional, Sequence

from app import control
from app.loader import (
    Partition, bulk_csv_rows, bulk_missing_columns, bulk_threshold, object_workers, overlap_seconds, partition_rows,
    plan_partitions, sf_concurrency, sf_slot, to_text, with_retries, write_rows_gz,
)
from app.metadata import ObjectConfig, validate_identifier
from app.orchestrator import build_partition_query, to_soql_datetime
from app.salesforce_client import SalesforceClient
from app.snowflake_client import SnowflakeClient

# SOQL goes over HTTP; very wide objects (hundreds of fields) must be fetched in column
# groups that are re-joined on Id, or Salesforce rejects the query as too long.
MAX_SOQL_CHARS = 12000
# Compound / binary fields cannot be bulk-queried or stored as plain columns.
SKIP_SF_TYPES = {"address", "location", "base64", "anyType"}
SNOWFLAKE_TYPES = {
    "boolean": "BOOLEAN",
    "int": "NUMBER(38,0)",
    "long": "NUMBER(38,0)",
    "double": "FLOAT",
    "currency": "FLOAT",
    "percent": "FLOAT",
    "date": "DATE",
    "datetime": "TIMESTAMP_TZ",
    "time": "TIME",
}

Log = Callable[[str], None]
__all__ = ["IncrementalPipeline", "run_objects", "build_plan", "chunk_fields", "to_text", "SKIP_SF_TYPES"]


def _q(column: str) -> str:
    return '"' + column.upper() + '"'


_DATA_ERROR = re.compile(
    r"\(22\d{3}\)|not recognized|out of range|too long|cannot be cast|failed to cast|can't parse|"
    r"numeric value|invalid .*(date|timestamp|time|boolean)|string .* is too long|overflow",
    re.IGNORECASE,
)


def is_data_error(exc: Exception) -> bool:
    """True for errors caused by the data itself (SQLSTATE class 22: bad number / date / too long ...),
    false for pipeline problems such as permissions, connectivity or syntax."""
    return bool(_DATA_ERROR.search(str(exc)))


def chunk_fields(fields: Sequence[str], required: Sequence[str], max_chars: int = MAX_SOQL_CHARS) -> List[List[str]]:
    """Split ``fields`` into SOQL-sized groups; every group starts with ``required`` (Id, watermark, IsDeleted)."""
    required = list(required)
    rest = [f for f in fields if f not in required]
    base = len(", ".join(required))
    chunks: List[List[str]] = []
    current: List[str] = []
    size = base
    for f in rest:
        if current and size + len(f) + 2 > max_chars:
            chunks.append(required + current)
            current, size = [], base
        current.append(f)
        size += len(f) + 2
    chunks.append(required + current)
    return chunks


def add_missing_columns_enabled() -> bool:
    return (os.getenv("CDC_ADD_MISSING_COLUMNS") or "true").strip().lower() not in ("0", "false", "no")


@dataclass
class ObjectPlan:
    """What describe() tells us about how to sync an object."""
    fields: List[str]
    types: Dict[str, str]
    watermark_field: Optional[str]
    has_is_deleted: bool
    # (precision, scale) of Salesforce number fields, so values are stored exactly as Salesforce holds them
    numeric: Dict[str, tuple] = field(default_factory=dict)
    # configured fields that no longer exist in Salesforce (skipped, not fatal)
    unknown: List[str] = field(default_factory=list)


def audit_enabled() -> bool:
    return (os.getenv("CDC_AUDIT") or "true").strip().lower() not in ("0", "false", "no")


AUDIT_COLUMN_GROUP = 150   # columns compared per statement, keeps each SQL statement a sane size


def build_plan(config: ObjectConfig, describe_fields: Sequence[Dict[str, Any]]) -> ObjectPlan:
    by_lower = {f["name"].lower(): f for f in describe_fields}
    unknown: List[str] = []
    if config.fields:
        unknown = [f for f in config.fields if f.lower() not in by_lower]
        if len(unknown) == len(config.fields):
            raise ValueError(f"{config.object_name}: unknown field(s) {', '.join(unknown)}")
        wanted = [by_lower[f.lower()]["name"] for f in config.fields if f.lower() in by_lower]
        for required in ("Id", "SystemModstamp", "LastModifiedDate", "IsDeleted"):
            if required.lower() in by_lower and required not in wanted:
                wanted.append(required)
    else:
        wanted = [f["name"] for f in describe_fields if f["type"] not in SKIP_SF_TYPES]
    if "Id" not in wanted:
        raise ValueError(f"{config.object_name} has no Id field and cannot be synced.")

    names = {n.lower() for n in wanted}
    watermark_field = (
        "SystemModstamp" if "systemmodstamp" in names
        else "LastModifiedDate" if "lastmodifieddate" in names
        else None
    )
    numeric = {}
    for n in wanted:
        meta = by_lower[n.lower()]
        if meta["type"] in ("double", "currency", "percent") and meta.get("precision"):
            numeric[n] = (int(meta["precision"]), int(meta.get("scale") or 0))
    return ObjectPlan(
        fields=wanted,
        types={n: by_lower[n.lower()]["type"] for n in wanted},
        watermark_field=watermark_field,
        has_is_deleted="isdeleted" in names,
        numeric=numeric,
        unknown=unknown,
    )


def column_type(plan: ObjectPlan, name: str) -> str:
    """Snowflake type for a new column. Salesforce numbers keep their declared precision and scale."""
    kind = plan.types[name]
    if name in plan.numeric:
        precision, scale = plan.numeric[name]
        if 1 <= precision <= 38 and 0 <= scale <= precision:
            return f"NUMBER({precision},{scale})"
    return SNOWFLAKE_TYPES.get(kind, "VARCHAR")


class IncrementalPipeline:
    """Syncs one Salesforce object into one Snowflake table."""

    def __init__(
        self,
        config: ObjectConfig,
        sf: SalesforceClient,
        db: SnowflakeClient,
        run_id: str,
        trigger: str = "manual",
        user: str = "",
        full_refresh: bool = False,
        reconcile: bool = False,
        log: Log = print,
    ):
        self.config = config
        self.sf = sf
        self.db = db
        self.run_id = run_id
        self.trigger = trigger
        self.user = user
        self.full_refresh = full_refresh
        self.reconcile = reconcile
        self.log = log
        self.target = validate_identifier(config.target_table, "target table")
        self.stage = f"CDC_STG_{self.target}_{run_id}"
        self._tables: List[str] = []          # transient tables to drop afterwards
        self._colmap: Dict[str, str] = {}      # UPPER name -> the target column's real spelling
        self._ctypes: Dict[str, str] = {}      # UPPER name -> type to CAST new values to when comparing
        self._step = "start"
        self._added_columns: List[str] = []
        self._tmpdir: Optional[str] = None
        self.stage_dir = f"@~/cdc/{run_id}/{self.target}/"

    # ---- orchestration ---------------------------------------------------
    def run(self) -> Dict[str, Any]:
        obj = self.config.object_name
        stats = {"extracted": 0, "inserted": 0, "updated": 0, "deleted": 0}
        # Captured BEFORE any Salesforce query: the next watermark must not be later than this, or a
        # row changed while we were reading could be skipped forever.
        started = datetime.now(timezone.utc)
        t_run = time.monotonic()
        stored = None if self.full_refresh else control.get_watermark(self.db, obj)
        control.start_run(self.db, self.run_id, obj, self.trigger, self.user, stored)
        new_watermark: Optional[str] = None
        try:
            self.log(f"[{obj}] starting ({self.trigger}, target {self.target}, load strategy {self.config.load_strategy})")
            self._step = "describe the Salesforce object"
            sf_fields = self.sf.describe_fields(obj)
            plan = build_plan(self.config, sf_fields)
            if plan.unknown:
                self.log(f"[{obj}] WARN schema change: configured field(s) no longer in Salesforce, "
                         f"skipped: {', '.join(plan.unknown)}")
                self._prune_saved_fields(plan)
            if self.config.fields:
                have = {f.lower() for f in plan.fields}
                new = [f["name"] for f in sf_fields if f["type"] not in SKIP_SF_TYPES and f["name"].lower() not in have]
                if new:
                    self.log(f"[{obj}] note: {len(new)} Salesforce field(s) are not in this object's field list and "
                             f"are not synced (clear the field list to sync all fields): {', '.join(new[:10])}"
                             f"{'...' if len(new) > 10 else ''}")
            self._step = "prepare the Snowflake target table"
            target_cols = self._ensure_target(plan)
            if plan.watermark_field is None:
                stored = None  # nothing to filter on: always a full pull
            elif self._added_columns and stored:
                # Adding a field does not change SystemModstamp, so existing rows would keep NULL in the new column.
                stored = None
                self.log(f"[{obj}] new column(s) {', '.join(self._added_columns)}: reloading all rows to backfill them")
            self.log(f"[{obj}] {len(plan.fields)} fields, watermark={plan.watermark_field}, "
                     f"since={stored or 'beginning (full load)'}")

            self._step = "extract from Salesforce and load files"
            self._extract_to_stage(plan, target_cols, stored, stats)
            if stats["extracted"]:
                self._step = "validate values against the target column types"
                self._quarantine_bad_values(target_cols)
                self._step = "classify changes and merge into the target table"
                self._classify_and_merge(plan, target_cols, stats)
            self._step = "advance the watermark"
            if plan.watermark_field:
                new_watermark = to_soql_datetime(started - timedelta(seconds=overlap_seconds()))
                control.set_watermark(self.db, obj, plan.watermark_field, new_watermark)
                self.log(f"[{obj}] watermark advanced to {new_watermark} (run start - {overlap_seconds()}s overlap)")

            if self.reconcile or not plan.has_is_deleted:
                self._step = "reconcile hard deletes"
                stats["deleted"] += self._reconcile_deletes(plan, target_cols)

            control.finish_run(self.db, self.run_id, obj, "SUCCESS", stats, new_watermark or stored)
            self.log(f"[{obj}] done in {time.monotonic() - t_run:.0f}s: +{stats['inserted']} new, "
                     f"~{stats['updated']} updated, -{stats['deleted']} deleted")
        except Exception as exc:
            self.log(f"[{obj}] FAILED while trying to {self._step} (after {time.monotonic() - t_run:.0f}s): {exc}")
            control.finish_run(self.db, self.run_id, obj, "FAILED", stats, stored,
                               f"While trying to {self._step}: {exc}")
            raise
        finally:
            self._cleanup()
        return {"object": obj, "status": "SUCCESS", **stats}

    # ---- target table -----------------------------------------------------
    def _ensure_target(self, plan: ObjectPlan) -> List[str]:
        """Create the target if missing; add any columns it lacks (unless disabled)."""
        exact = self.db.table_columns_exact(self.target)
        existing = [c.upper() for c in exact]
        if not existing:
            cols = ",\n".join(f"{_q(f)} {column_type(plan, f)}" for f in plan.fields)
            self.db.execute(f"CREATE TABLE {self.target} (\n{cols}\n)")
            self.log(f"[{self.config.object_name}] created table {self.target}")
            self._colmap = {}
            self._ctypes = {f.upper(): ("" if column_type(plan, f) == "VARCHAR" else column_type(plan, f))
                            for f in plan.fields}
            return [f.upper() for f in plan.fields]
        if "ID" not in existing:
            raise ValueError(f"Existing table {self.target} has no ID column (it has: {', '.join(exact[:12])}).")
        # Remember each column's real spelling: a table made by another tool may have "Id" or
        # "SystemModstamp" in quoted mixed case, which "ID" / "SYSTEMMODSTAMP" would not match.
        self._colmap = {}
        for name in exact:
            if name.upper() not in self._colmap or name == name.upper():
                self._colmap[name.upper()] = name
        odd = [n for n in exact if n != n.upper()]
        if odd:
            self.log(f"[{self.config.object_name}] note: {self.target} has mixed-case column names "
                     f"({', '.join(odd[:5])}{'...' if len(odd) > 5 else ''}); using them as they are")
        self._ctypes = self.db.table_column_types(self.target)
        wanted_upper = {f.upper() for f in plan.fields}
        gone = [n for n in exact if n.upper() not in wanted_upper and not n.upper().startswith("CDC_")]
        if gone and not self.config.fields:
            self.log(f"[{self.config.object_name}] WARN schema change: column(s) no longer in Salesforce, "
                     f"kept in {self.target} but no longer updated: {', '.join(gone[:20])}"
                     f"{'...' if len(gone) > 20 else ''}")
        missing = [f for f in plan.fields if f.upper() not in existing]
        if missing and add_missing_columns_enabled():
            # Schema evolution: add what Salesforce has but the table lacks (nullable, additive only).
            for f in missing:
                self.db.execute(
                    f"ALTER TABLE {self.target} ADD COLUMN IF NOT EXISTS {_q(f)} {column_type(plan, f)}"
                )
                self._ctypes[f.upper()] = "" if column_type(plan, f) == "VARCHAR" else column_type(plan, f)
            self.log(f"[{self.config.object_name}] WARN schema change: added {len(missing)} new column(s) to {self.target}: "
                     f"{', '.join(missing)}")
            existing = existing + [f.upper() for f in missing]
            self._added_columns = list(missing)
        elif missing:
            self.log(f"[{self.config.object_name}] not in {self.target}, skipped: {', '.join(missing)}")
        usable = [f.upper() for f in plan.fields if f.upper() in existing]
        # Fail fast, BEFORE hours of extraction: make sure every column we will write can be resolved.
        try:
            self.db.execute(f"SELECT {', '.join(self._t(c) for c in usable)} FROM {self.target} WHERE 1 = 0")
        except Exception as exc:
            raise ValueError(f"The columns to load cannot be resolved in {self.target} ({exc})") from exc
        return usable

    def _prune_saved_fields(self, plan: ObjectPlan) -> None:
        """Remove fields deleted in Salesforce from the saved field list so the config matches reality."""
        gone = {f.lower() for f in plan.unknown}
        try:
            from app.metadata import ObjectRegistry
            self.config.fields = [f for f in self.config.fields if f.lower() not in gone]
            ObjectRegistry(self.db).upsert(self.config, "auto-schema")
            self.log(f"[{self.config.object_name}] removed from the saved field list: {', '.join(plan.unknown)}")
        except Exception as exc:
            self.log(f"[{self.config.object_name}] note: could not update the saved field list ({exc})")

    def _t(self, column: str) -> str:
        """Quoted name of a column in the TARGET table, in the spelling it really has there."""
        return chr(34) + self._colmap.get(column.upper(), column.upper()) + chr(34)


    # ---- extraction -------------------------------------------------------
    def _make_table(self, name: str, columns: Sequence[str]) -> str:
        cols = ", ".join(f"{_q(c)} VARCHAR" for c in columns)
        self.db.execute(f"CREATE OR REPLACE TRANSIENT TABLE {name} ({cols})")
        self._tables.append(name)
        return name

    def _plan_work(self, plan: ObjectPlan, where: str):
        """Decide strategy and Id-range partitions. Returns (strategy, partitions, estimate, id_count)."""
        obj = self.config.object_name
        try:
            estimate = self.sf.count(obj, where, include_deleted=plan.has_is_deleted)
        except Exception as exc:  # unknown size -> behave like a small object
            self.log(f"[{obj}] could not count rows ({exc}); assuming a small load")
            estimate = 0

        strategy = self.config.load_strategy
        if strategy == "auto":
            strategy = "bulk" if estimate >= bulk_threshold() else "rest"

        partitions = [Partition(0)]
        id_count: Optional[int] = None
        if estimate > partition_rows():
            ids = list(self.sf.query_ids(obj, where, include_deleted=plan.has_is_deleted))
            id_count = len(ids)
            partitions = plan_partitions(ids, partition_rows())
        return strategy, partitions, estimate, id_count

    def _extract_to_stage(self, plan: ObjectPlan, target_cols: List[str], since: Optional[str],
                          stats: Dict[str, int]) -> None:
        obj = self.config.object_name
        # The watermark and IsDeleted columns are always staged: they drive the incremental
        # filter, dedup ordering, the newer-version guard and change classification.
        required = ["Id"] + [f for f in (plan.watermark_field, "IsDeleted" if plan.has_is_deleted else None) if f]
        fields = [f for f in plan.fields if f.upper() in target_cols or f in required]
        chunks = chunk_fields(fields, required, MAX_SOQL_CHARS)

        where = f"{plan.watermark_field} > {since}" if since and plan.watermark_field else ""
        strategy, partitions, estimate, id_count = self._plan_work(plan, where)
        tasks = [(ci, part) for part in partitions for ci in range(len(chunks))]
        workers = max(1, min(len(tasks), sf_concurrency()))
        self.log(f"[{obj}] ~{estimate:,} rows via {strategy.upper()}: {len(partitions)} partition(s) x "
                 f"{len(chunks)} column group(s) = {len(tasks)} task(s), {workers} in parallel")

        tables = [self._make_table(self.stage, fields)]
        for ci in range(1, len(chunks)):
            tables.append(self._make_table(f"{self.stage}_P{ci}", chunks[ci]))

        self._tmpdir = tempfile.mkdtemp(prefix=f"cdc_{self.target}_")
        done = 0
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = [pool.submit(self._fetch_task, plan, chunks[ci], ci, part, since, strategy) for ci, part in tasks]
            try:
                # Files are loaded as they finish, so Snowflake ingestion overlaps the other fetches.
                for future in as_completed(futures):
                    ci, part, path, rows, fetch_secs = future.result()
                    began = time.monotonic()
                    self._load_file(path, tables[ci], chunks[ci])
                    done += 1
                    if ci == 0:
                        stats["extracted"] += rows
                    self.log(f"[{obj}] task {done}/{len(tasks)} done (column group {ci + 1}/{len(chunks)}, "
                             f"range {part.index + 1}/{len(partitions)}): {rows:,} rows, "
                             f"fetch {fetch_secs:.0f}s, load {time.monotonic() - began:.0f}s | "
                             f"{stats['extracted']:,} rows so far")
            except BaseException:
                for f in futures:
                    f.cancel()
                raise

        for ci in range(1, len(chunks)):
            began = time.monotonic()
            self._join_chunk_into_stage(tables[ci], chunks[ci], required)
            self.log(f"[{obj}] joined column group {ci + 1}/{len(chunks)} in {time.monotonic() - began:.0f}s")
        if id_count is not None and stats["extracted"] != id_count:
            self.log(f"[{obj}] note: {stats['extracted']:,} rows loaded vs {id_count:,} Ids planned "
                     f"(rows changed while loading; the next run reconciles them)")
        self.log(f"[{obj}] extracted {stats['extracted']:,} rows")

    def _fetch_task(self, plan: ObjectPlan, chunk: List[str], ci: int, part: Partition,
                    since: Optional[str], strategy: str):
        soql = build_partition_query(self.config.object_name, chunk, since, plan.watermark_field, part.lo, part.hi)
        path = os.path.join(self._tmpdir, f"c{ci}_p{part.index}.csv.gz")

        def attempt() -> int:
            with sf_slot():
                return write_rows_gz(path, self._rows(plan, chunk, soql, strategy))

        began = time.monotonic()
        rows = with_retries(attempt, log=self.log, what=f"[{self.config.object_name}] group {ci + 1} range {part.index + 1}")
        return ci, part, path, rows, time.monotonic() - began

    def _rows(self, plan: ObjectPlan, chunk: List[str], soql: str, strategy: str) -> Iterator[List[Optional[str]]]:
        """Rows in ``chunk`` order. Bulk falls back to REST if the Bulk API is unavailable."""
        obj = self.config.object_name
        if strategy == "bulk":
            try:
                files = self.sf.bulk_download(obj, soql, self._tmpdir, include_deleted=plan.has_is_deleted)
                missing = bulk_missing_columns(files[0], chunk) if files else []
                if missing:
                    raise ValueError(f"Bulk result has no column for: {', '.join(missing[:10])}")
                return (row for f in files for row in bulk_csv_rows(f, chunk, plan.types))
            except Exception as exc:
                self.log(f"[{obj}] Bulk API failed ({exc}); falling back to REST for this slice")
        return ([to_text(record.get(f), plan.types[f]) for f in chunk]
                for record in self.sf.query_iter(soql, include_deleted=plan.has_is_deleted))

    def _load_file(self, path: str, table: str, columns: Sequence[str]) -> None:
        self.db.put_file(path, self.stage_dir)
        self.db.copy_csv(table, columns, self.stage_dir, os.path.basename(path))
        os.remove(path)

    def _join_chunk_into_stage(self, part: str, chunk: List[str], required: List[str]) -> None:
        """Copy a later column group into the stage rows, matched on Id. A row that only
        appears in a later group changed after group 1 ran, so the next run picks it up."""
        cols = [f for f in chunk if f not in required]
        if not cols:
            return
        updates = ", ".join(f"s.{_q(c)} = p.{_q(c)}" for c in cols)
        self.db.execute(
            f"MERGE INTO {self.stage} s USING "
            f"(SELECT * FROM {part} QUALIFY ROW_NUMBER() OVER (PARTITION BY {_q('Id')} ORDER BY {_q('Id')}) = 1) p "
            f"ON s.{_q('Id')} = p.{_q('Id')} WHEN MATCHED THEN UPDATE SET {updates}"
        )

    # ---- bad values ----------------------------------------------------------
    def _quarantine_bad_values(self, target_cols: List[str]) -> None:
        """A value that cannot be stored in its typed target column (overflow, wrong format) would fail the
        whole MERGE. Log record Id + column + value + reason to CDC_ERROR_LOG, set just that value to NULL
        in the stage, and let the rest of the load continue."""
        obj = self.config.object_name
        typed = [(c, self._ctypes.get(c.upper(), "")) for c in target_cols if c != "ID"]
        typed = [(c, t) for c, t in typed if t]
        if not typed:
            return
        try:
            bad_cols: List[tuple] = []
            for i in range(0, len(typed), 100):
                part = typed[i:i + 100]
                counts = ", ".join(
                    f"COUNT_IF({_q(c)} IS NOT NULL AND TRY_CAST({_q(c)} AS {t}) IS NULL)" for c, t in part)
                row = self.db.fetch_one(f"SELECT {counts} FROM {self.stage}")
                bad_cols += [(c, t, n) for (c, t), n in zip(part, row) if n]
            for c, t, n in bad_cols:
                bad = f"{_q(c)} IS NOT NULL AND TRY_CAST({_q(c)} AS {t}) IS NULL"
                reason = (f"Value cannot be stored as {t} (overflow or invalid format); "
                          f"value set to NULL, rest of the record loaded")
                self.db.execute(
                    f"INSERT INTO CDC_ERROR_LOG (RUN_ID, OBJECT_NAME, RECORD_ID, COLUMN_NAME, BAD_VALUE, "
                    f"TARGET_TYPE, ERROR_REASON) SELECT %s, %s, {_q('Id')}, %s, LEFT({_q(c)}, 1000), %s, %s "
                    f"FROM {self.stage} WHERE {bad}",
                    (self.run_id, obj, c, t, reason),
                )
                self.db.execute(f"UPDATE {self.stage} SET {_q(c)} = NULL WHERE {bad}")
                self.log(f"[{obj}] WARN skipped {n:,} value(s) in column {c} (cannot be stored as {t}); "
                         f"record Ids are in CDC_ERROR_LOG")
        except Exception as exc:
            self.log(f"[{obj}] WARN could not pre-check values against column types: {exc}")

    # ---- classify + merge --------------------------------------------------
    def _classify_and_merge(self, plan: ObjectPlan, target_cols: List[str], stats: Dict[str, int]) -> None:
        order = _q(plan.watermark_field) if plan.watermark_field else _q("Id")
        # If an Id appears twice in one load (changed again mid-run) keep the newest.
        latest = (f"SELECT * FROM {self.stage} "
                  f"QUALIFY ROW_NUMBER() OVER (PARTITION BY {_q('Id')} ORDER BY {order} DESC) = 1")

        # Version guard: a row is only written / logged when the incoming version is not older than
        # what the table already holds. Re-reads (overlap, retries, full refresh) therefore neither
        # overwrite newer data nor show up as fake UPDATEs.
        wm = plan.watermark_field if plan.watermark_field and plan.watermark_field.upper() in target_cols else None
        if wm:
            s_ts = f"TRY_TO_TIMESTAMP_TZ(s.{_q(wm)})"
            t_ts = f"TRY_TO_TIMESTAMP_TZ(t.{self._t(wm)}::VARCHAR)"
            changed = f"WHERE t.{self._t('Id')} IS NULL OR {t_ts} IS NULL OR {s_ts} > {t_ts}"
            may_update = f" AND ({t_ts} IS NULL OR {s_ts} >= {t_ts})"
            newer = f"({t_ts} IS NULL OR {s_ts} > {t_ts})"
        else:
            changed, may_update, newer = "", "", "TRUE"

        deleted_case = (f"WHEN LOWER(s.{_q('IsDeleted')}) = 'true' THEN 'DELETE' " if plan.has_is_deleted else "")
        obj = self.config.object_name
        began = time.monotonic()
        self.db.execute(
            f"""
            INSERT INTO CDC_CHANGE_LOG (RUN_ID, OBJECT_NAME, RECORD_ID, CHANGE_TYPE)
            SELECT %s, %s, s.{_q('Id')},
                   CASE {deleted_case}WHEN t.{self._t('Id')} IS NULL THEN 'INSERT' ELSE 'UPDATE' END
            FROM ({latest}) s
            LEFT JOIN {self.target} t ON t.{self._t('Id')} = s.{_q('Id')}
            {changed}
            """,
            (self.run_id, self.config.object_name),
        )
        self._load_change_counts(stats)
        self.log(f"[{obj}] classified {stats['inserted'] + stats['updated'] + stats['deleted']:,} changed rows in "
                 f"{time.monotonic() - began:.1f}s: {stats['inserted']:,} insert, {stats['updated']:,} update, "
                 f"{stats['deleted']:,} delete (unchanged re-reads are skipped)")

        if audit_enabled():
            self._audit(plan, target_cols, latest, newer)

        non_key = [c for c in target_cols if c != "ID"]
        updates = ", ".join(f"t.{self._t(c)} = s.{_q(c)}" for c in non_key)
        merge = f"""
            MERGE INTO {self.target} t
            USING ({latest}) s ON t.{self._t('Id')} = s.{_q('Id')}
            {f'WHEN MATCHED{may_update} THEN UPDATE SET {updates}' if updates else ''}
            WHEN NOT MATCHED THEN INSERT ({', '.join(self._t(c) for c in target_cols)})
                 VALUES ({', '.join('s.' + _q(c) for c in target_cols)})
        """
        began = time.monotonic()
        try:
            self.db.execute(merge)
        except Exception as exc:
            if not is_data_error(exc):
                raise
            self.log(f"[{obj}] WARN merge failed on a data problem ({str(exc)[:200]}); "
                     f"isolating the failing record(s) and loading the rest")
            self._merge_isolating(latest, merge_for=lambda src: merge.replace(f"USING ({latest}) s", f"USING ({src}) s"),
                                  stats=stats)
        self.log(f"[{obj}] merged into {self.target} in {time.monotonic() - began:.1f}s")

    MAX_ISOLATED_FAILURES = 500

    def _merge_isolating(self, latest: str, merge_for: Callable[[str], str], stats: Dict[str, int]) -> None:
        """Bisect the staged Ids to find records the MERGE rejects for data reasons; log each one in
        CDC_ERROR_LOG, load all the others, and drop the failed ones from the change / audit logs."""
        obj = self.config.object_name
        ids = f"CDC_IDS_{self.target}_{self.run_id}"
        self.db.execute(
            f"CREATE OR REPLACE TRANSIENT TABLE {ids} AS SELECT {_q('Id')} AS ID, "
            f"ROW_NUMBER() OVER (ORDER BY {_q('Id')}) AS RN FROM ({latest})"
        )
        self._tables.append(ids)
        total = int(self.db.fetch_one(f"SELECT COUNT(*) FROM {ids}")[0])
        failed: List[str] = []

        def attempt(lo: int, hi: int) -> None:
            src = (f"SELECT * FROM ({latest}) x WHERE x.{_q('Id')} IN "
                   f"(SELECT ID FROM {ids} WHERE RN BETWEEN {lo} AND {hi})")
            try:
                self.db.execute(merge_for(src))
                return
            except Exception as exc:
                if not is_data_error(exc):
                    raise
                if lo == hi:
                    rid = self.db.fetch_one(f"SELECT ID FROM {ids} WHERE RN = {lo}")[0]
                    failed.append(rid)
                    if len(failed) > self.MAX_ISOLATED_FAILURES:
                        raise ValueError(f"More than {self.MAX_ISOLATED_FAILURES} records failed on data "
                                         f"problems; stopping (last error: {exc})") from exc
                    self.db.execute(
                        "INSERT INTO CDC_ERROR_LOG (RUN_ID, OBJECT_NAME, RECORD_ID, COLUMN_NAME, BAD_VALUE, "
                        "TARGET_TYPE, ERROR_REASON) VALUES (%s, %s, %s, NULL, NULL, NULL, %s)",
                        (self.run_id, obj, rid, ("Record not loaded: " + str(exc))[:4000]),
                    )
                    return
                mid = (lo + hi) // 2
                attempt(lo, mid)
                attempt(mid + 1, hi)

        if total:
            if total == 1:
                attempt(1, 1)
            else:
                mid = total // 2
                attempt(1, mid)
                attempt(mid + 1, total)
        if failed:
            for table in ("CDC_CHANGE_LOG", "CDC_AUDIT_LOG"):
                self.db.execute(
                    f"DELETE FROM {table} WHERE RUN_ID = %s AND OBJECT_NAME = %s AND "
                    f"RECORD_ID IN ({', '.join(['%s'] * len(failed))})",
                    (self.run_id, obj, *failed),
                )
            self._load_change_counts(stats)
            self.log(f"[{obj}] WARN {len(failed)} record(s) NOT loaded because of data errors "
                     f"(see CDC_ERROR_LOG): {', '.join(failed[:10])}{'...' if len(failed) > 10 else ''}")


    # ---- audit log ----------------------------------------------------------
    AUDIT_COLUMNS = ("RUN_ID, OBJECT_NAME, RECORD_ID, CHANGE_TYPE, FIELD_NAME, OLD_VALUE, NEW_VALUE, "
                     "RECORD_MODSTAMP, MODIFIED_BY, CHANGED_AT")

    def _audit(self, plan: ObjectPlan, target_cols: List[str], latest: str, newer: str) -> None:
        """Record WHAT changed: one row per changed attribute (old value, new value), plus one row per
        inserted / deleted record. Runs before the MERGE, while the old values are still in the table.
        Nothing is filtered: every attribute that differs is recorded, exactly as Salesforce sent it."""
        obj = self.config.object_name
        modstamp = f"s.{_q(plan.watermark_field)}" if plan.watermark_field else "NULL"
        modified_by = f"s.{_q('LastModifiedById')}" if "LASTMODIFIEDBYID" in target_cols else "NULL"

        # record level: inserts and deletes, taken from the change log written a moment ago
        record_rows = self.db.execute(
            f"""
            INSERT INTO CDC_AUDIT_LOG ({self.AUDIT_COLUMNS})
            SELECT c.RUN_ID, c.OBJECT_NAME, c.RECORD_ID, c.CHANGE_TYPE, NULL, NULL, NULL,
                   {modstamp}, {modified_by}, CURRENT_TIMESTAMP()
            FROM CDC_CHANGE_LOG c
            LEFT JOIN ({latest}) s ON s.{_q('Id')} = c.RECORD_ID
            WHERE c.RUN_ID = %s AND c.OBJECT_NAME = %s AND c.CHANGE_TYPE IN ('INSERT', 'DELETE')
            """,
            (self.run_id, obj),
        )

        # field level: compare every column of records that already exist, in the column's own type
        api_name = {f.upper(): f for f in plan.fields}
        columns = [c for c in target_cols if c != "ID"]
        field_rows = 0
        for start in range(0, len(columns), AUDIT_COLUMN_GROUP):
            group = columns[start:start + AUDIT_COLUMN_GROUP]
            flags, olds, news = [], [], []
            for c in group:
                label = api_name.get(c, c).replace("'", "")
                cast = self._ctypes.get(c, "")
                incoming = f"TRY_CAST(s.{_q(c)} AS {cast})" if cast else f"s.{_q(c)}"
                flags.append(f"IFF({incoming} IS DISTINCT FROM t.{self._t(c)}, '{label}', NULL)")
                olds.append(f"'{label}', t.{self._t(c)}::VARCHAR")
                news.append(f"'{label}', s.{_q(c)}")
            field_rows += self.db.execute(
                f"""
                INSERT INTO CDC_AUDIT_LOG ({self.AUDIT_COLUMNS})
                SELECT %s, %s, j.RID, 'UPDATE', f.value::VARCHAR,
                       j.OLDV[f.value::VARCHAR]::VARCHAR, j.NEWV[f.value::VARCHAR]::VARCHAR,
                       j.MS, j.BY_, CURRENT_TIMESTAMP()
                FROM (
                    SELECT s.{_q('Id')} AS RID, {modstamp} AS MS, {modified_by} AS BY_,
                           ARRAY_CONSTRUCT_COMPACT({', '.join(flags)}) AS CHG,
                           OBJECT_CONSTRUCT_KEEP_NULL({', '.join(olds)}) AS OLDV,
                           OBJECT_CONSTRUCT_KEEP_NULL({', '.join(news)}) AS NEWV
                    FROM ({latest}) s
                    JOIN {self.target} t ON t.{self._t('Id')} = s.{_q('Id')}
                    WHERE {newer}
                ) j,
                LATERAL FLATTEN(input => j.CHG) f
                """,
                (self.run_id, obj),
            )
        self.log(f"[{obj}] audit: {field_rows:,} attribute change(s) and {record_rows:,} record insert/delete "
                 f"event(s) written to CDC_AUDIT_LOG")

    def _load_change_counts(self, stats: Dict[str, int]) -> None:
        rows = self.db.fetch_all(
            "SELECT CHANGE_TYPE, COUNT(*) FROM CDC_CHANGE_LOG "
            "WHERE RUN_ID = %s AND OBJECT_NAME = %s GROUP BY CHANGE_TYPE",
            (self.run_id, self.config.object_name),
        )
        counts = {r[0]: int(r[1]) for r in rows}
        stats["inserted"] = counts.get("INSERT", 0)
        stats["updated"] = counts.get("UPDATE", 0)
        stats["deleted"] = counts.get("DELETE", 0)

    # ---- hard deletes -----------------------------------------------------
    def _reconcile_deletes(self, plan: ObjectPlan, target_cols: List[str]) -> int:
        """Hard deletes never appear in a SystemModstamp query (nor, after ~15 days, in queryAll) -
        find them by diffing live Salesforce Ids against the target."""
        obj = self.config.object_name
        live = self._make_table(f"CDC_IDS_{self.target}_{self.run_id}", ["ID"])
        if self._tmpdir is None:
            self._tmpdir = tempfile.mkdtemp(prefix=f"cdc_{self.target}_")
        path = os.path.join(self._tmpdir, "live_ids.csv.gz")

        def list_ids() -> int:
            with sf_slot():
                return write_rows_gz(path, ([i] for i in self.sf.query_ids(obj)))

        count = with_retries(list_ids, log=self.log, what=f"[{obj}] id listing")
        self.log(f"[{obj}] reconcile: {count:,} live Ids in Salesforce, comparing with {self.target}")
        self._load_file(path, live, ["ID"])

        total = self.db.fetch_one(f"SELECT COUNT(*) FROM {self.target}")[0]
        if not count and total:
            raise RuntimeError(f"Reconcile aborted: Salesforce returned 0 {obj} Ids but {self.target} "
                               f"holds {total} rows. Refusing to delete everything.")

        soft = plan.has_is_deleted and "ISDELETED" in target_cols
        not_live = f"{self._t('Id')} NOT IN (SELECT ID FROM {live})"
        guard = f" AND COALESCE(LOWER({self._t('IsDeleted')}::VARCHAR), 'false') <> 'true'" if soft else ""
        removed = self.db.execute(
            f"""
            INSERT INTO CDC_CHANGE_LOG (RUN_ID, OBJECT_NAME, RECORD_ID, CHANGE_TYPE)
            SELECT %s, %s, {self._t('Id')}, 'DELETE' FROM {self.target} WHERE {not_live}{guard}
            """,
            (self.run_id, obj),
        )
        if audit_enabled():
            self.db.execute(
                f"""
                INSERT INTO CDC_AUDIT_LOG ({self.AUDIT_COLUMNS})
                SELECT RUN_ID, OBJECT_NAME, RECORD_ID, 'DELETE', NULL, NULL, NULL, NULL, NULL, CURRENT_TIMESTAMP()
                FROM CDC_CHANGE_LOG
                WHERE RUN_ID = %s AND OBJECT_NAME = %s AND CHANGE_TYPE = 'DELETE'
                  AND RECORD_ID NOT IN (SELECT RECORD_ID FROM CDC_AUDIT_LOG
                                        WHERE RUN_ID = %s AND OBJECT_NAME = %s AND CHANGE_TYPE = 'DELETE')
                """,
                (self.run_id, obj, self.run_id, obj),
            )
        if soft:
            # ISDELETED may be BOOLEAN or text depending on how the table was created.
            self.db.execute(f"UPDATE {self.target} SET {self._t('IsDeleted')} = TRUE WHERE {not_live}{guard}")
        else:
            self.db.execute(f"DELETE FROM {self.target} WHERE {not_live}")
        self.log(f"[{obj}] reconcile found {removed} hard-deleted rows")
        return int(removed)

    # ---- cleanup ------------------------------------------------------------
    def _cleanup(self) -> None:
        for table in self._tables:
            try:
                self.db.execute(f"DROP TABLE IF EXISTS {table}")
            except Exception:  # best effort; transient tables also expire
                pass
        self.db.remove_stage_dir(self.stage_dir)
        if self._tmpdir:
            shutil.rmtree(self._tmpdir, ignore_errors=True)
        if self._tables:
            self.log(f"[{self.config.object_name}] cleaned up {len(self._tables)} temporary table(s) and staged files")


# ---- multi-object runner ---------------------------------------------------
STALE_RUN_HOURS = 3


def is_running(db: SnowflakeClient, object_name: str) -> bool:
    """True if a run for this object started recently and has not finished (any trigger)."""
    row = db.fetch_one(
        "SELECT COUNT(*) FROM CDC_RUN_LOG WHERE OBJECT_NAME = %s AND STATUS = 'RUNNING' "
        "AND STARTED_AT > DATEADD(hour, -%s, CURRENT_TIMESTAMP())",
        (object_name, STALE_RUN_HOURS),
    )
    return bool(row and row[0])


@dataclass
class RunSummary:
    run_id: str
    results: List[Dict[str, Any]] = field(default_factory=list)

    @property
    def failed(self) -> int:
        return sum(1 for r in self.results if r["status"] == "FAILED")


def _estimate(sf: SalesforceClient, cfg: ObjectConfig) -> int:
    try:
        return int(sf.count(cfg.object_name))
    except Exception:
        return 0


def run_objects(
    configs: Iterable[ObjectConfig],
    sf: SalesforceClient,
    db: SnowflakeClient,
    trigger: str = "manual",
    user: str = "",
    full_refresh: bool = False,
    reconcile: bool = False,
    log: Log = print,
    should_stop: Callable[[], bool] = lambda: False,
    workers: Optional[int] = None,
) -> RunSummary:
    """Run every given object, several at a time, biggest first. One object failing never stops the others."""
    configs = list(configs)
    control.ensure_control_tables(db)
    summary = RunSummary(run_id=uuid.uuid4().hex[:12])
    ui_log = log

    def log(message: str) -> None:  # noqa: F811 - tee: caller's log + persisted run events
        ui_log(message)
        match = re.match(r"\[([A-Za-z0-9_]+)\]", message)
        control.log_event(db, summary.run_id, message, match.group(1) if match else None)

    results: List[Optional[Dict[str, Any]]] = [None] * len(configs)

    def work(index: int) -> None:
        cfg = configs[index]
        if should_stop():
            log(f"[{cfg.object_name}] skipped: stop requested")
            results[index] = {"object": cfg.object_name, "status": "SKIPPED"}
            return
        if is_running(db, cfg.object_name):
            log(f"[{cfg.object_name}] skipped: another run is still in progress")
            results[index] = {"object": cfg.object_name, "status": "SKIPPED"}
            return
        pipeline = IncrementalPipeline(cfg, sf, db, summary.run_id, trigger, user, full_refresh, reconcile, log)
        try:
            results[index] = pipeline.run()
        except Exception as exc:
            results[index] = {"object": cfg.object_name, "status": "FAILED", "error": str(exc)}

    sizes = {i: _estimate(sf, c) for i, c in enumerate(configs)}
    order = sorted(range(len(configs)), key=lambda i: -sizes[i])          # longest jobs first
    pool_size = max(1, min(len(configs) or 1, workers or object_workers()))
    log(f"Run {summary.run_id}: {len(configs)} object(s), {pool_size} at a time, "
        f"up to {sf_concurrency()} concurrent Salesforce requests")
    with ThreadPoolExecutor(max_workers=pool_size) as pool:
        list(pool.map(work, order))
    summary.results = [r for r in results if r]
    return summary
