# Salesforce → Snowflake incremental CDC

> **Full project guide (architecture, status, roadmap, go-live checklist): open [`docs/index.html`](docs/index.html) in a browser.**
> **Knowledge-transfer guide (how it works, running it, bad-data handling, Azure daily schedule): [`docs/migration-guide.html`](docs/migration-guide.html).**

Python replacement for the SnapLogic pipelines. Pulls the Salesforce objects you choose into Snowflake,
incrementally, with a full audit trail, and a Streamlit UI so nobody needs a terminal.

## How it works

Per object, per run: `describe()` the object → read watermark → fetch rows with
`SystemModstamp > watermark` using `queryAll` (so soft-deleted rows come too) → bulk-insert into a temporary
stage → classify rows (INSERT / UPDATE / DELETE) into `CDC_CHANGE_LOG` → `MERGE` into the target table →
**then** advance the watermark. A failed run never moves the watermark, so the next run retries safely.

* **Soft deletes** (`IsDeleted = true`) are kept in the target with `ISDELETED = true`.
* **Hard deletes / objects without `IsDeleted`** (e.g. `UserRole`) are found by comparing Salesforce Ids to the
  target (automatic for such objects; tick *Also detect hard deletes* for the rest).
* Objects without `SystemModstamp` fall back to `LastModifiedDate`, or to a full pull.
* Target columns come from Salesforce `describe()` (all fields). If the table already exists, only columns it
  already has are loaded.
* One object failing never stops the others.

Snowflake tables created in the configured schema: your data tables plus `CDC_OBJECT_CONFIG`, `CDC_WATERMARK`,
`CDC_RUN_LOG`, `CDC_RUN_EVENTS` (persisted log lines), `CDC_CHANGE_LOG`.

**Every column comes across.** With no field list set, all fields from `describe()` are synced (only compound
address/location and binary fields are excluded - their component fields such as `BillingStreet` are included).
If the target table already exists and lacks columns, they are added automatically (`ALTER TABLE ... ADD COLUMN`;
disable with `CDC_ADD_MISSING_COLUMNS=false`). Very wide objects are fetched in column groups so the SOQL never
exceeds Salesforce's length limit. The *Columns* view lists every field, whether it is in Snowflake, and why not.
Fields the integration user cannot see (field-level security) are not returned by Salesforce at all.

## Audit log: what changed, from what to what

`CDC_CHANGE_LOG` says *which* records changed in a run. `CDC_AUDIT_LOG` says *what* changed: one row per changed
attribute with the **old value**, the **new value**, the Salesforce user who changed it (`LastModifiedById`), the
Salesforce timestamp and the run. Inserts and deletes are recorded as one row each. Nothing is filtered: every
attribute that differs is recorded, exactly as Salesforce sent it (including `SystemModstamp` / `LastModifiedDate`).
Values are compared in the column's own type, so `1.0` vs `1` or a different timestamp format is not a change.
Search it in the **Audit log** page, per record under **Investigate**, or via `GET /api/audit`. Switch off with
`CDC_AUDIT=false`. Numbers are stored with their exact Salesforce precision and scale.

## Big objects (hundreds of fields x hundreds of thousands of rows)

The first load of a large object is the heavy part; later runs only fetch changes. For big loads the engine:

* splits the object into **Id-range partitions** (and very wide ones into **column groups**) and fetches them
  **in parallel** under a global cap on concurrent Salesforce requests;
* uses the **Bulk API 2.0** automatically for big loads (per-object `load_strategy`: `auto` / `rest` / `bulk`);
* writes gzip CSV files and loads them with **`PUT` + `COPY INTO`** (no row-by-row inserts);
* retries transient errors, and sets the watermark to the **run start time** (minus 5 min) so rows changed during
  a long load are never missed; the merge never overwrites a newer row with an older one.

Tune with `CDC_SF_CONCURRENCY` (4), `CDC_OBJECT_WORKERS` (3), `CDC_PARTITION_ROWS` (50000),
`CDC_BULK_THRESHOLD` (100000), `CDC_OVERLAP_SECONDS` (300). Trimming unused fields is the biggest speed-up.
Not yet run at real scale - time one big object first. Details: `docs/index.html` section 6.

## Two UIs, same engine

```bash
pip install -r requirements.txt
copy .env.example .env      # fill in credentials

# 1. Web app (React) - recommended for the team
cd webui && npm install && npm run build && cd ..
python -m app.api           # http://127.0.0.1:8000   (API docs at /docs)
cdc-ui.cmd                  # Windows: builds UI if needed, starts server, opens the browser

# 2. Streamlit
streamlit run app/streamlit_app.py
```

Front-end development: `python -m app.api` plus `npm run dev` in `webui/` (proxies `/api`).
Container: `docker build -t cdc-control .` (builds the UI and serves it from the API).

Both have: **Run pipeline** (per-object progress and a live log with level / object / text filters, copy and download), **Logs** (search the saved log of every run), **Objects** (add / enable / remove, column coverage, row-count comparison, force
reload), **Monitor & logs** (KPIs, object health, charts, run history, persisted per-run logs, changed records and
their current data) and **Investigate** (paste a record Id: full change history, and a field-by-field
Salesforce ↔ Snowflake comparison).

* **Run pipeline** – pick objects, optional full refresh / hard-delete check, live log.
* **Objects** – enable/disable, add (picked from Salesforce, validated), restrict fields, remove. Stored in
  `CDC_OBJECT_CONFIG`, so it survives redeploys and is shared by everyone using the app.
* **Monitor** – inserted / updated / deleted per object, failures, run history, drill into the changed records.

`config/objects.json` is only the first-time seed list (all disabled). Test in a scratch schema first
(`SNOWFLAKE_SCHEMA`) - `STG_SF` is still being written by SnapLogic until it is decommissioned.

## Scheduled runs (Azure DevOps)

`azure-pipelines.yml` runs `python -m app.main` at 00/06/12/18 UTC using the `salesforce-cdc-secrets` variable
group. Build agents have no browser: use a Snowflake **service user with key-pair auth** there
(`SNOWFLAKE_PRIVATE_KEY`). Browser SSO (`SNOWFLAKE_AUTHENTICATOR=externalbrowser`) is for local use only.

CLI (optional): `python -m app.main [--objects Account,Contact] [--full-refresh] [--reconcile]`

## Hosting the UI

Any container/App Service that runs `streamlit run app/streamlit_app.py` works. Put it behind Azure AD
authentication (the app has no login of its own) and use key-pair auth, not browser SSO.

## Tests

```bash
pytest -q
```
