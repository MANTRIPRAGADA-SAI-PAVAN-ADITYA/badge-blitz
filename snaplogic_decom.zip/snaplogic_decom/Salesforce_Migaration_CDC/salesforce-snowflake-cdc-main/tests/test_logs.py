from app.control import classify_level
from app.runner import BackgroundRunner
from app.service import Service


def test_levels_are_classified_for_colouring_and_filtering():
    assert classify_level("[Account] FAILED after 3s: boom") == "ERROR"
    assert classify_level("Reconcile aborted: refusing") == "ERROR"
    assert classify_level("[Account] Bulk API failed (x); falling back to REST for this slice") == "WARN"   # failed but recovered
    assert classify_level("[Account] skipped: another run is still in progress") == "WARN"
    assert classify_level("[Account] request failed (TimeoutError); retry 1/2 in 2s") == "WARN"
    assert classify_level("[Account] note: 24 rows loaded vs 25 Ids planned") == "WARN"
    assert classify_level("[Account] task 3/8 done (column group 1/1, range 3/8): 50,000 rows") == "INFO"


def test_runner_keeps_structured_events():
    runner = BackgroundRunner(db=None)
    runner._log("[Account] merged into ACCOUNT in 2.0s")
    runner._log("Connecting to Salesforce...")
    runner._log("[Contact] FAILED: boom")
    assert [(e["level"], e["object"]) for e in runner.events] == [("INFO", "Account"), ("INFO", None), ("ERROR", "Contact")]
    assert runner.log_lines[0].endswith("[Account] merged into ACCOUNT in 2.0s")


class RecordingDb:
    def __init__(self, rows=()):
        self.rows, self.calls = list(rows), []

    def fetch_dicts(self, sql, params=None):
        self.calls.append((" ".join(sql.split()), list(params or [])))
        return self.rows


def make_service(db):
    svc = Service.__new__(Service)
    svc.db = db
    return svc


def test_log_search_builds_a_parameterised_filter():
    db = RecordingDb([{"RUN_ID": "r1", "EVENT_TS": "t", "OBJECT_NAME": "Account", "LEVEL": None, "MESSAGE": "[Account] FAILED: x"}])
    rows = make_service(db).search_events(hours=48, run_id="r1", object_name="Account",
                                          levels=["warn", "ERROR", "bogus"], text="fail'; DROP TABLE x", limit=999999)
    sql, params = db.calls[0]
    assert "LEVEL, 'INFO') IN (%s, %s)" in sql and "POSITION(LOWER(%s), LOWER(MESSAGE)) > 0" in sql
    assert "DROP TABLE" not in sql                                  # the search text is a bind value only
    assert params == [48, "r1", "Account", "WARN", "ERROR", "fail'; DROP TABLE x", 20000]
    assert rows[0]["level"] == "ERROR"                              # old rows without a level are classified on read


def test_audit_query_has_no_implicit_filter_and_binds_every_value():
    db = RecordingDb([])
    make_service(db).audit()
    sql, params = db.calls[0]
    assert "WHERE" not in sql and "FROM CDC_AUDIT_LOG" in sql and params == [2000]      # all history, nothing hidden

    make_service(db).audit(hours=24, object_name="Account", record_id="001000000000001", field="name",
                           change_type="update", text="x'; DROP TABLE y", limit=5)
    sql, params = db.calls[1]
    assert "DROP TABLE" not in sql
    assert params == [24, "Account", "001000000000001", "name", "UPDATE", "x'; DROP TABLE y", "x'; DROP TABLE y", 5]
