import pytest

from app.metadata import ObjectConfig, ObjectRegistry, validate_identifier


def test_registry_add_disable_remove_roundtrip(tmp_path):
    reg = ObjectRegistry(path=tmp_path / "objects.json")
    assert reg.list() == []

    reg.upsert(ObjectConfig("Account"))
    reg.upsert(ObjectConfig("Custom_Thing__c", fields=["Name"], note="x"))
    assert [c.object_name for c in reg.list()] == ["Account", "Custom_Thing__c"]
    assert reg.get("custom_thing__c").target_table == "CUSTOM_THING__C"

    reg.set_enabled("Account", False)
    assert [c.object_name for c in reg.list(enabled_only=True)] == ["Custom_Thing__c"]

    reg.remove("Account")
    assert [c.object_name for c in reg.list()] == ["Custom_Thing__c"]


def test_upsert_replaces_existing_entry(tmp_path):
    reg = ObjectRegistry(path=tmp_path / "objects.json")
    reg.upsert(ObjectConfig("Account", enabled=True))
    reg.upsert(ObjectConfig("Account", enabled=False))
    assert len(reg.list()) == 1 and reg.list()[0].enabled is False


@pytest.mark.parametrize("bad", ["Account; DROP TABLE x", "a b", "1abc", "", "Acc-ount", "x'y"])
def test_identifiers_are_validated(bad):
    with pytest.raises(ValueError):
        validate_identifier(bad)
    with pytest.raises(ValueError):
        ObjectConfig(bad)


def test_shipped_defaults_load_and_are_disabled():
    reg = ObjectRegistry()  # config/objects.json
    configs = reg.list()
    assert len(configs) == 24
    assert not any(c.enabled for c in configs)  # nothing runs until someone opts in
    assert reg.get("UserRole") is not None


def test_registry_uses_safe_column_add_for_load_strategy():
    class FakeSnowflake:
        def __init__(self):
            self.calls = []

        def execute(self, sql, params=None):
            self.calls.append((sql, params))
            if "ADD COLUMN IF NOT EXISTS" in sql.upper():
                raise AssertionError("Snowflake schema upgrade should not use IF NOT EXISTS on ADD COLUMN")

        def fetch_one(self, sql, params=None):
            return (0,)

        def fetch_all(self, sql, params=None):
            return []

    fake_db = FakeSnowflake()
    reg = ObjectRegistry(fake_db)

    assert isinstance(reg, ObjectRegistry)
    assert any("CREATE TABLE IF NOT EXISTS CDC_OBJECT_CONFIG" in sql for sql, _ in fake_db.calls)
    assert any("LOAD_STRATEGY" in sql and "ADD COLUMN" in sql for sql, _ in fake_db.calls)
