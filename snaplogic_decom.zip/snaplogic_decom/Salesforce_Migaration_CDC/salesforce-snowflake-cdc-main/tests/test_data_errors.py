from app.pipeline import is_data_error


def test_data_errors_are_recognised():
    msg = "100038 (22018): DML operation to table OPPORTUNITY failed on column X with error: Numeric value '9' is not recognized"
    assert is_data_error(Exception(msg))
    assert is_data_error(Exception("100069 (22000): String 'abc' is too long and would be truncated"))


def test_pipeline_errors_are_not_data_errors():
    assert not is_data_error(Exception("002003 (42S02): SQL compilation error: Object 'X' does not exist"))
    assert not is_data_error(Exception("Connection reset by peer"))
    assert not is_data_error(Exception("003001 (42501): Insufficient privileges to operate on table"))
