"""In-memory stand-ins for Snowflake/Salesforce so the API and UI can be exercised without credentials."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from app.metadata import ObjectRegistry
from app.pipeline import RunSummary

NOW = datetime.now(timezone.utc)


class FakeDb:
    def whoami(self):
        return {"user": "DEMO", "role": "DEV_ROLE", "warehouse": "DEV_WH", "database": "DEV_DB", "schema": "SCRATCH"}

    def close(self):
        pass


class FakeRunner:
    def __init__(self):
        self.running = False
        self.started_at = None
        self.log_lines = []
        self.events = []
        self.summary = None
        self.error = None
        self.started_with = None

    def start(self, configs, user, full_refresh=False, reconcile=False):
        if self.running:
            return False
        self.started_with = ([c.object_name for c in configs], full_refresh, reconcile)
        self.started_at = NOW
        self.log_lines = [f"12:00:00  [{c.object_name}] extracted 3 rows" for c in configs]
        self.events = [{"ts": NOW.isoformat(), "level": "INFO", "object": c.object_name,
                        "message": f"[{c.object_name}] task 1/2 done (column group 1/1, range 1/2): 3 rows, fetch 1s, load 1s | 3 rows so far"}
                       for c in configs] + [{"ts": NOW.isoformat(), "level": "WARN", "object": None, "message": "Bulk API failed; falling back to REST"}]
        self.summary = RunSummary("demo123", [
            {"object": c.object_name, "status": "SUCCESS", "extracted": 3, "inserted": 2, "updated": 1, "deleted": 0}
            for c in configs])
        return True

    def stop(self):
        self.running = False


class FakeService:
    def __init__(self, path):
        self.registry = ObjectRegistry(path=path)
        self.sf = self

    def list_objects(self):
        return [{"name": "Account", "label": "Account", "custom": False}, {"name": "Case", "label": "Case", "custom": False}]

    def describe_fields(self, name):
        if name == "Nope__c":
            raise ValueError("Object Nope__c not found")
        return [{"name": "Id", "type": "id"}, {"name": "Name", "type": "string"}]

    def summary(self, hours=24):
        return {"hours": hours, "totals": {"inserted": 10, "updated": 5, "deleted": 2, "extracted": 17,
                                           "object_runs": 4, "failures": 1, "running": 0},
                "by_object": [{"object_name": "Account", "inserted": 10, "updated": 5, "deleted": 2, "runs": 2, "failures": 0}],
                "timeline": [{"bucket": (NOW - timedelta(hours=h)).isoformat(), "inserted": 3 + h, "updated": 2, "deleted": h % 2}
                             for h in range(6, 0, -1)]}

    def health(self):
        return [{"object_name": "Account", "target_table": "ACCOUNT", "enabled": True, "state": "healthy",
                 "last_status": "SUCCESS", "last_started": NOW.isoformat(), "last_error": None,
                 "last_success": NOW.isoformat(), "hours_since_success": 1.0, "watermark": "2026-10-07T10:00:00.000Z"},
                {"object_name": "Contact", "target_table": "CONTACT", "enabled": True, "state": "failing",
                 "last_status": "FAILED", "last_started": NOW.isoformat(), "last_error": "INVALID_FIELD: Foo__c",
                 "last_success": None, "hours_since_success": None, "watermark": None}]

    def runs(self, hours=24, status=None, object_name=None, limit=500):
        row = {"run_id": "demo123", "object_name": "Account", "trigger_type": "manual", "triggered_by": "me",
               "started_at": NOW.isoformat(), "ended_at": NOW.isoformat(), "status": "SUCCESS", "rows_extracted": 17,
               "rows_inserted": 10, "rows_updated": 5, "rows_deleted": 2, "watermark_from": None,
               "watermark_to": "2026-10-07T10:00:00.000Z", "error_message": None}
        failed = dict(row, run_id="demo124", object_name="Contact", status="FAILED", error_message="INVALID_FIELD: Foo__c")
        return [r for r in (row, failed) if not status or r["status"] == status]

    def run_events(self, run_id, object_name=None):
        return [{"event_ts": NOW.isoformat(), "object_name": object_name, "level": "INFO", "message": "[Account] extracted 17 rows"},
                {"event_ts": NOW.isoformat(), "object_name": object_name, "level": "ERROR", "message": "[Account] FAILED: boom"}]

    def search_events(self, hours=24, run_id=None, object_name=None, levels=None, text=None, limit=2000):
        rows = [{"run_id": "demo123", "event_ts": NOW.isoformat(), "object_name": "Account", "level": "INFO", "message": "[Account] merged into ACCOUNT in 2.0s"},
                {"run_id": "demo124", "event_ts": NOW.isoformat(), "object_name": "Contact", "level": "ERROR", "message": "[Contact] FAILED: INVALID_FIELD"}]
        self.last_search = dict(hours=hours, run_id=run_id, object_name=object_name, levels=levels, text=text, limit=limit)
        return [r for r in rows if (not levels or r["level"] in levels) and (not text or text.lower() in r["message"].lower())]

    def changes(self, run_id, object_name, change_type=None, limit=5000):
        return [{"record_id": "0015000000AbCdE", "change_type": "INSERT", "change_ts": NOW.isoformat()}]

    def changed_rows(self, run_id, object_name, change_type=None, limit=500):
        return [{"_change_type": "INSERT", "id": "0015000000AbCdE", "name": "Acme"}]

    def record_history(self, record_id):
        return [{"object_name": "Account", "change_type": "UPDATE", "change_ts": NOW.isoformat(), "run_id": "demo123",
                 "trigger_type": "manual", "triggered_by": "me"}]

    def compare_record(self, object_name, record_id):
        return {"object_name": object_name, "record_id": record_id, "table": "ACCOUNT", "in_salesforce": True,
                "in_snowflake": True, "differences": 1,
                "fields": [{"field": "ID", "salesforce": record_id, "snowflake": record_id, "status": "match"},
                           {"field": "NAME", "salesforce": "Acme Corp", "snowflake": "Acme", "status": "different"}],
                "history": self.record_history(record_id)}

    def column_report(self, name):
        return {"object_name": name, "target_table": name.upper(), "table_exists": True, "salesforce_fields": 3,
                "synced": 1, "missing": 1, "excluded": 1, "target_only_columns": [],
                "fields": [{"field": "Id", "type": "id", "label": "", "status": "synced", "reason": ""},
                           {"field": "Phone", "type": "phone", "label": "", "status": "pending", "reason": "will be added on next run"},
                           {"field": "BillingAddress", "type": "address", "label": "", "status": "excluded",
                            "reason": "address fields cannot be stored as a column"}]}

    def audit(self, hours=None, object_name=None, record_id=None, field=None, run_id=None,
              change_type=None, text=None, limit=2000):
        self.last_audit = dict(hours=hours, object_name=object_name, record_id=record_id, field=field,
                               run_id=run_id, change_type=change_type, text=text, limit=limit)
        return [{"run_id": "demo123", "object_name": "Account", "record_id": "0015000000AbCdE",
                 "change_type": "UPDATE", "field_name": "Name", "old_value": "Acme", "new_value": "Acme Corp",
                 "record_modstamp": NOW.isoformat(), "modified_by": "005000000000001", "changed_at": NOW.isoformat()}]

    def count_compare(self, name):
        return {"object_name": name, "salesforce_live": 100, "snowflake_total": 103, "snowflake_live": 100,
                "difference": 0, "in_sync": True}

    def reset_watermark(self, name):
        self.reset = name
