import React, { useEffect, useState } from 'react'
import { api } from './api'
import { Err } from './components.jsx'
import RunPage from './pages/RunPage.jsx'
import ObjectsPage from './pages/ObjectsPage.jsx'
import MonitorPage from './pages/MonitorPage.jsx'
import InvestigatePage from './pages/InvestigatePage.jsx'
import LogsPage from './pages/LogsPage.jsx'
import AuditPage from './pages/AuditPage.jsx'

const PAGES = [
  ['run', 'Run pipeline', RunPage, '▶', 'Fetch changed rows from Salesforce and merge them into Snowflake.'],
  ['objects', 'Objects', ObjectsPage, '▤', 'Choose which objects sync, their fields and load mode.'],
  ['monitor', 'Monitor & logs', MonitorPage, '▦', 'Health, history and changed records across runs.'],
  ['logs', 'Logs', LogsPage, '☰', 'Search the saved log of every run.'],
  ['audit', 'Audit log', AuditPage, '✎', 'What changed: old value, new value and when.'],
  ['investigate', 'Investigate', InvestigatePage, '⌕', 'Full history of one record and a Salesforce vs Snowflake comparison.'],
]

export default function App() {
  const [status, setStatus] = useState(null)
  const [error, setError] = useState(null)
  const [busy, setBusy] = useState(false)
  const [page, setPage] = useState(() => window.location.hash.slice(1) || 'run')

  useEffect(() => {
    const onHash = () => setPage(window.location.hash.slice(1) || 'run')
    window.addEventListener('hashchange', onHash)
    return () => window.removeEventListener('hashchange', onHash)
  }, [])
  useEffect(() => { api.status().then(setStatus, setError) }, [])

  const [theme, setTheme] = useState(() => localStorage.getItem('theme') || 'light')
  useEffect(() => {
    document.documentElement.dataset.theme = theme
    localStorage.setItem('theme', theme)
  }, [theme])
  const toggleTheme = () => setTheme((t) => (t === 'light' ? 'dark' : 'light'))

  const connect = async () => {
    setBusy(true); setError(null)
    try { setStatus(await api.connect()) } catch (e) { setError(e) } finally { setBusy(false) }
  }
  const disconnect = async () => setStatus(await api.disconnect())
  const go = (id) => { window.location.hash = id }

  const [running, setRunning] = useState(false)
  useEffect(() => {
    if (!status?.connected) return undefined
    const tick = () => api.runState().then((r) => setRunning(!!r.running), () => {})
    tick()
    const t = setInterval(tick, 4000)
    return () => clearInterval(t)
  }, [status?.connected])

  if (!status) return <div className="center-screen"><div className="spinner" /><p className="muted">Loading…</p><Err error={error} /></div>

  if (!status.connected) {
    return (
      <div className="center-screen">
        <div className="connect-card">
          <div className="connect-head">
            <div className="hero-title">Salesforce → Snowflake CDC</div>
            <div className="hero-sub">Control centre for the incremental migration pipeline</div>
          </div>
          <div className="connect-body">
            <div className="kv"><span>Source</span><b className="mono">{status.salesforce_login_url}</b></div>
            <div className="kv"><span>Target</span><b className="mono">{status.snowflake_target}</b></div>
            <div className="kv"><span>User</span><b className="mono">{status.snowflake_user} ({status.snowflake_auth})</b></div>
            {status.problems.map((p) => <div key={p} className="note">{p}</div>)}
            {status.problems.length > 0 && <p className="muted">Copy <span className="mono">.env.example</span> to <span className="mono">.env</span>, fill it in and restart the server.</p>}
            <Err error={error} />
            <button className="btn primary big" disabled={busy || status.problems.length > 0} onClick={connect}>
              {busy ? <><span className="spinner sm" /> Connecting…</> : 'Connect'}
            </button>
            {busy && <p className="muted small">A sign-in window may open for Snowflake SSO. Complete it to continue.</p>}
          </div>
        </div>
      </div>
    )
  }

  const active = PAGES.find(([id]) => id === page) || PAGES[0]
  const Current = active[2]
  return (
    <div className="shell">
      <aside className="side">
        <div className="brand">CDC Control Centre<small>Salesforce → Snowflake</small></div>
        <nav className="nav">
          {PAGES.map(([id, label, , icon]) => (
            <button key={id} className={page === id ? 'on' : ''} onClick={() => go(id)}>
              <span className="ico">{icon}</span>{label}
            </button>
          ))}
        </nav>
        <div className="conn">
          <div><span className="dot" /><b>Snowflake</b></div>
          <div className="mono">{status.session?.database}.{status.session?.schema}</div>
          <div className="mono">{status.session?.role}</div>
          <div style={{ marginTop: 8 }}><span className="dot" /><b>Salesforce</b></div>
          <div className="mono" style={{ wordBreak: 'break-all' }}>{status.salesforce_login_url}</div>
          <div style={{ marginTop: 8 }}><a onClick={disconnect}>Disconnect</a></div>
        </div>
        <button className="btn small theme" onClick={toggleTheme}>{theme === 'light' ? 'Dark theme' : 'Light theme'}</button>
      </aside>
      <main className="main">
        <div className="hero">
          <div>
            <div className="hero-title">{active[1]}</div>
            <div className="hero-sub">{active[4]}</div>
          </div>
          <div className="hero-pills">
            {running && <a className="hpill live" onClick={() => go('run')}><span className="pulse" />Run in progress</a>}
            <span className="hpill">Target {status.snowflake_target}</span>
            <span className="hpill">Source {(status.salesforce_login_url || '').replace(/^https?:\/\//, '').replace(/\/$/, '')}</span>
          </div>
        </div>
        <div className="page" key={active[0]}><Current go={go} /></div>
      </main>
    </div>
  )
}
