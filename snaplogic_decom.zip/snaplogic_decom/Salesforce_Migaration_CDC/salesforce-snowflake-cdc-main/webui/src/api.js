async function req(path, options = {}) {
  const res = await fetch(path, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
    body: options.body ? JSON.stringify(options.body) : undefined,
  })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(data.detail || `${res.status} ${res.statusText}`)
  return data
}

const qs = (o) =>
  '?' + new URLSearchParams(Object.entries(o).filter(([, v]) => v !== undefined && v !== '' && v !== null)).toString()

export const api = {
  status: () => req('/api/status'),
  connect: () => req('/api/connect', { method: 'POST' }),
  disconnect: () => req('/api/disconnect', { method: 'POST' }),

  objects: () => req('/api/objects'),
  salesforceObjects: () => req('/api/salesforce/objects'),
  addObject: (body) => req('/api/objects', { method: 'POST', body }),
  patchObject: (name, body) => req(`/api/objects/${name}`, { method: 'PATCH', body }),
  removeObject: (name) => req(`/api/objects/${name}`, { method: 'DELETE' }),
  columns: (name) => req(`/api/objects/${name}/columns`),
  countCompare: (name) => req(`/api/objects/${name}/count-compare`),
  resetWatermark: (name) => req(`/api/objects/${name}/reset-watermark`, { method: 'POST' }),

  runState: () => req('/api/run'),
  startRun: (body) => req('/api/run', { method: 'POST', body }),
  stopRun: () => req('/api/run/stop', { method: 'POST' }),

  summary: (hours) => req(`/api/summary${qs({ hours })}`),
  health: () => req('/api/health'),
  runs: (p) => req(`/api/runs${qs(p)}`),
  logs: (p) => req(`/api/logs${qs({ hours: p.hours, level: p.level, object: p.object, run_id: p.run_id, q: p.q, limit: p.limit })}`),
  audit: (p) => req(`/api/audit${qs({ hours: p.hours || undefined, object: p.object, record_id: p.record_id, field: p.field, change_type: p.change_type, q: p.q, run_id: p.run_id, limit: p.limit })}`),
  events: (runId, object) => req(`/api/runs/${runId}/events${qs({ object })}`),
  changes: (runId, object, type) => req(`/api/runs/${runId}/changes${qs({ object, type })}`),
  rows: (runId, object, type) => req(`/api/runs/${runId}/rows${qs({ object, type })}`),
  history: (id) => req(`/api/records/${id}/history`),
  compare: (object, id) => req(`/api/records/${object}/${id}/compare`),
}
