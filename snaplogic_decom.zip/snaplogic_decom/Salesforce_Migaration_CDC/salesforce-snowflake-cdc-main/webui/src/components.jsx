import React, { useCallback, useEffect, useRef, useState } from 'react'

export const Pill = ({ value, children }) => (
  <span className={`pill ${value}`}>{children ?? String(value ?? '').replace('_', ' ')}</span>
)

export const fmtTime = (iso) => (iso ? new Date(iso).toLocaleString() : '—')
export const fmtNum = (n) => (n === null || n === undefined ? '—' : Number(n).toLocaleString())

export function Err({ error }) {
  return error ? <div className="err">{String(error.message || error)}</div> : null
}

/** Runs an async loader, exposing {data, error, loading, reload}. */
export function useLoad(fn, deps = []) {
  const [state, set] = useState({ data: null, error: null, loading: true })
  const reload = useCallback(() => {
    set((s) => ({ ...s, loading: true }))
    return fn().then(
      (data) => set({ data, error: null, loading: false }),
      (error) => set({ data: null, error, loading: false }),
    )
  }, deps) // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { reload() }, [reload])
  return { ...state, reload }
}

export function usePoll(fn, ms, active = true) {
  const saved = useRef(fn)
  saved.current = fn
  useEffect(() => {
    if (!active) return undefined
    const id = setInterval(() => saved.current(), ms)
    return () => clearInterval(id)
  }, [ms, active])
}

export function Table({ columns, rows, onRow, empty = 'Nothing to show.', max }) {
  if (!rows || rows.length === 0) return <p className="muted">{empty}</p>
  return (
    <div className="scroll" style={max ? { maxHeight: max } : undefined}>
      <table>
        <thead>
          <tr>{columns.map((c) => <th key={c.key} className={c.num ? 'num' : ''}>{c.label}</th>)}</tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i} className={onRow ? 'click' : ''} onClick={onRow ? () => onRow(r) : undefined}>
              {columns.map((c) => (
                <td key={c.key} className={c.num ? 'num' : ''}>{c.render ? c.render(r) : (r[c.key] ?? '—')}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

/** Rows of arbitrary shape (e.g. a Snowflake table row): columns come from the data. */
export function DataTable({ rows, max = 420 }) {
  if (!rows || rows.length === 0) return <p className="muted">No rows.</p>
  const cols = Object.keys(rows[0]).map((key) => ({
    key,
    label: key,
    render: (r) => (r[key] === null || r[key] === undefined ? '—' : String(r[key])),
  }))
  return <Table columns={cols} rows={rows} max={max} />
}

/** Stacked inserted/updated/deleted bars. Pure SVG, no chart library. */
export function StackedBars({ data, label }) {
  if (!data || data.length === 0) return <p className="muted">No changes in this window.</p>
  const H = 220, pad = { l: 48, r: 8, t: 8, b: 70 }
  const W = Math.max(720, pad.l + pad.r + data.length * 56)
  const totals = data.map((d) => (d.inserted || 0) + (d.updated || 0) + (d.deleted || 0))
  const max = Math.max(1, ...totals)
  const bw = (W - pad.l - pad.r) / data.length
  const y = (v) => pad.t + (H - pad.t - pad.b) * (1 - v / max)
  const parts = [['inserted', 'var(--ins)'], ['updated', 'var(--upd)'], ['deleted', 'var(--del)']]
  return (
    <div>
      <div className="legend">
        <span><i style={{ background: 'var(--ins)' }} />Inserted</span>
        <span><i style={{ background: 'var(--upd)' }} />Updated</span>
        <span><i style={{ background: 'var(--del)' }} />Deleted</span>
      </div>
      <div style={{ overflowX: 'auto' }}>
      <svg viewBox={`0 0 ${W} ${H}`} style={{ width: W > 720 ? `${W}px` : '100%', minWidth: '100%', height: 'auto' }} role="img" aria-label="Changes">
        {[0, 0.5, 1].map((t) => (
          <g key={t}>
            <line x1={pad.l} x2={W - pad.r} y1={y(max * t)} y2={y(max * t)} stroke="var(--line)" />
            <text x={pad.l - 6} y={y(max * t) + 4} textAnchor="end" fontSize="10" fill="var(--muted)">
              {fmtNum(Math.round(max * t))}
            </text>
          </g>
        ))}
        {data.map((d, i) => {
          let acc = 0
          return (
            <g key={i}>
              {parts.map(([k, color]) => {
                const v = d[k] || 0
                const top = y(acc + v)
                const h = y(acc) - top
                acc += v
                return v ? (
                  <rect key={k} x={pad.l + i * bw + 3} y={top} width={Math.max(2, bw - 6)} height={h} fill={color}>
                    <title>{`${label(d)} — ${k}: ${fmtNum(v)}`}</title>
                  </rect>
                ) : null
              })}
              <text transform={`translate(${pad.l + i * bw + bw / 2 + 4} ${H - pad.b + 12}) rotate(-35)`} textAnchor="end" fontSize="10" fill="var(--muted)">
                {String(label(d)).slice(0, 24)}
              </text>
            </g>
          )
        })}
      </svg>
      </div>
    </div>
  )
}

export function Drawer({ title, onClose, children }) {
  return (
    <div className="drawer-bg" onClick={onClose}>
      <div className="drawer" onClick={(e) => e.stopPropagation()}>
        <div className="row"><h2 className="grow">{title}</h2><button className="btn small" onClick={onClose}>Close</button></div>
        {children}
      </div>
    </div>
  )
}
