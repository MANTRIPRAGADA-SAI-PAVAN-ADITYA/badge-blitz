import React, { useState } from 'react'
import { api } from '../api'
import { Err, Pill, Table, fmtTime, useLoad } from '../components.jsx'

const Value = ({ v, cls }) => (v === null || v === undefined
  ? <span className={`val ${cls} nul`}>∅ null</span>
  : <span className={`val ${cls}`}>{String(v) === '' ? '(empty text)' : String(v)}</span>)

export const AuditTrail = ({ rows, empty }) => (
  <Table
    max={560}
    empty={empty}
    columns={[
      { key: 'changed_at', label: 'When', render: (r) => fmtTime(r.changed_at) },
      { key: 'record_id', label: 'Record', render: (r) => (
        <div><b>{r.object_name}</b><div className="mono small">{r.record_id}</div></div>) },
      { key: 'change_type', label: 'Change', render: (r) => <Pill value={r.change_type} /> },
      { key: 'field_name', label: 'Field', render: (r) => (r.field_name ? <b>{r.field_name}</b> : <span className="muted">whole record</span>) },
      {
        key: 'value',
        label: 'Old → New',
        render: (r) => (r.field_name
          ? <div style={{ minWidth: 260 }}><Value v={r.old_value} cls="old" /> <span className="muted">→</span> <Value v={r.new_value} cls="new" /></div>
          : <span className="muted">{r.change_type === 'INSERT' ? 'record created' : 'record deleted'}</span>),
      },
      { key: 'modified_by', label: 'Changed by / Salesforce time', render: (r) => (
        <div><span className="mono small">{r.modified_by || '—'}</span>
          <div className="mono small muted">{r.record_modstamp || ''}</div></div>) },
      { key: 'run_id', label: 'Run', render: (r) => <span className="mono small">{r.run_id}</span> },
    ]}
    rows={rows}
  />
)

const toCsv = (rows) => {
  const cols = ['changed_at', 'object_name', 'record_id', 'change_type', 'field_name', 'old_value', 'new_value',
    'record_modstamp', 'modified_by', 'run_id']
  const cell = (v) => (v === null || v === undefined ? '' : `"${String(v).replace(/"/g, '""')}"`)
  return [cols.join(','), ...rows.map((r) => cols.map((c) => cell(r[c])).join(','))].join('\n')
}

/** Attribute-level audit trail: which field of which record changed, from what to what, and when. */
export default function AuditPage() {
  const objects = useLoad(() => api.objects())
  const empty = { hours: 0, object: '', record_id: '', field: '', change_type: '', q: '', run_id: '', limit: 2000 }
  const [f, setF] = useState(empty)
  const [applied, setApplied] = useState(empty)
  const audit = useLoad(() => api.audit(applied), [JSON.stringify(applied)])
  const set = (patch) => setF({ ...f, ...patch })
  const apply = (e) => { e?.preventDefault(); setApplied({ ...f, record_id: f.record_id.trim(), run_id: f.run_id.trim() }) }
  const clear = () => { setF(empty); setApplied(empty) }

  const rows = audit.data || []
  const download = () => {
    const url = URL.createObjectURL(new Blob([toCsv(rows)], { type: 'text/csv' }))
    Object.assign(document.createElement('a'), { href: url, download: 'cdc-audit-log.csv' }).click()
    URL.revokeObjectURL(url)
  }
  const fieldChanges = rows.filter((r) => r.field_name).length

  return (
    <>
      <h1>Audit log</h1>
      <p className="muted">
        Every attribute change the pipeline detected: the record, the field, the <b>old value</b>, the <b>new value</b>, who changed it
        in Salesforce and when. Nothing is filtered unless you choose to — the default view is everything, newest first.
      </p>
      <Err error={audit.error || objects.error} />

      <form className="card" onSubmit={apply}>
        <div className="row">
          <label>Time window&nbsp;
            <select value={f.hours} onChange={(e) => set({ hours: Number(e.target.value) })}>
              <option value={0}>All time</option>
              {[[24, '24 hours'], [72, '3 days'], [168, '7 days'], [720, '30 days']].map(([h, l]) => <option key={h} value={h}>Last {l}</option>)}
            </select>
          </label>
          <label>Object&nbsp;
            <select value={f.object} onChange={(e) => set({ object: e.target.value })}>
              <option value="">All</option>
              {(objects.data || []).map((o) => <option key={o.object_name} value={o.object_name}>{o.object_name}</option>)}
            </select>
          </label>
          <label>Change&nbsp;
            <select value={f.change_type} onChange={(e) => set({ change_type: e.target.value })}>
              <option value="">All</option><option value="UPDATE">Field changed</option>
              <option value="INSERT">Record created</option><option value="DELETE">Record deleted</option>
            </select>
          </label>
          <input className="mono" style={{ width: 190 }} placeholder="Record Id" value={f.record_id} onChange={(e) => set({ record_id: e.target.value })} />
          <input style={{ width: 150 }} placeholder="Field name" value={f.field} onChange={(e) => set({ field: e.target.value })} />
          <input className="grow" placeholder="Old or new value contains…" value={f.q} onChange={(e) => set({ q: e.target.value })} />
          <input className="mono" style={{ width: 130 }} placeholder="Run id" value={f.run_id} onChange={(e) => set({ run_id: e.target.value })} />
          <label>Max rows&nbsp;
            <select value={f.limit} onChange={(e) => set({ limit: Number(e.target.value) })}>
              {[500, 2000, 10000, 50000].map((n) => <option key={n} value={n}>{n.toLocaleString()}</option>)}
            </select>
          </label>
          <button className="btn primary" type="submit">Search</button>
          <button className="btn" type="button" onClick={clear}>Clear filters</button>
          <button className="btn" type="button" onClick={download} disabled={!rows.length}>Download CSV</button>
        </div>
      </form>

      <div className="grid kpis">
        <div className="kpi"><b>{rows.length.toLocaleString()}</b><span>audit rows shown</span></div>
        <div className="kpi"><b>{fieldChanges.toLocaleString()}</b><span>attribute changes</span></div>
        <div className="kpi"><b>{new Set(rows.map((r) => r.record_id)).size.toLocaleString()}</b><span>records</span></div>
        <div className="kpi"><b>{new Set(rows.map((r) => r.field_name).filter(Boolean)).size.toLocaleString()}</b><span>distinct fields</span></div>
      </div>
      {rows.length >= applied.limit && (
        <div className="note">Showing the newest {applied.limit.toLocaleString()} rows. Narrow the filters or raise “Max rows” to see more.</div>
      )}
      <div className="card">
        <AuditTrail rows={rows} empty={audit.loading ? 'Loading…' : 'No audit rows match. Changes are recorded from the first run after the audit log was enabled.'} />
      </div>
    </>
  )
}
