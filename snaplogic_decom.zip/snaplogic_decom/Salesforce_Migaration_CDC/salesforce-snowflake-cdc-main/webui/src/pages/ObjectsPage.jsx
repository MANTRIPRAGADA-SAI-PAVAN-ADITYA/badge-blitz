import React, { useState } from 'react'
import { api } from '../api'
import { Drawer, Err, Pill, Table, fmtNum, useLoad } from '../components.jsx'

function ColumnReport({ name }) {
  const { data, error, loading } = useLoad(() => api.columns(name), [name])
  const [filter, setFilter] = useState('all')
  if (loading) return <p className="muted">Reading Salesforce metadata…</p>
  if (error) return <Err error={error} />
  const rows = data.fields.filter((f) => filter === 'all' || f.status === filter)
  return (
    <>
      <div className="grid kpis">
        <div className="kpi"><b>{data.salesforce_fields}</b><span>fields in Salesforce</span></div>
        <div className="kpi"><b>{data.synced}</b><span>in Snowflake</span></div>
        <div className="kpi"><b>{data.missing}</b><span>to be added</span></div>
        <div className="kpi"><b>{data.excluded}</b><span>excluded</span></div>
      </div>
      <p className="muted">
        Target <span className="mono">{data.target_table}</span> {data.table_exists ? 'exists' : 'will be created on the first run'}.
        Missing columns are added automatically on the next run.
        {data.target_only_columns.length > 0 && <> Columns only in Snowflake: <span className="mono">{data.target_only_columns.join(', ')}</span>.</>}
      </p>
      <div className="tabs">
        {['all', 'synced', 'pending', 'new_table', 'excluded'].map((f) => (
          <button key={f} className={filter === f ? 'on' : ''} onClick={() => setFilter(f)}>{f.replace('_', ' ')}</button>
        ))}
      </div>
      <Table
        max={520}
        columns={[
          { key: 'field', label: 'Field', render: (r) => <span className="mono">{r.field}</span> },
          { key: 'type', label: 'Type' },
          { key: 'status', label: 'Status', render: (r) => <Pill value={r.status} /> },
          { key: 'reason', label: 'Note' },
        ]}
        rows={rows}
      />
    </>
  )
}

function CountCompare({ name }) {
  const { data, error, loading } = useLoad(() => api.countCompare(name), [name])
  if (loading) return <p className="muted">Counting in Salesforce and Snowflake…</p>
  if (error) return <Err error={error} />
  return (
    <div className="grid kpis">
      <div className="kpi"><b>{fmtNum(data.salesforce_live)}</b><span>Salesforce rows (live)</span></div>
      <div className="kpi"><b>{fmtNum(data.snowflake_live)}</b><span>Snowflake rows (live)</span></div>
      <div className="kpi"><b>{fmtNum(data.snowflake_total)}</b><span>Snowflake incl. soft-deleted</span></div>
      <div className="kpi">
        <b>{data.in_sync ? 'In sync' : fmtNum(data.difference)}</b>
        <span>{data.in_sync ? 'counts match' : 'difference (Salesforce − Snowflake)'}</span>
      </div>
    </div>
  )
}

export default function ObjectsPage() {
  const objects = useLoad(() => api.objects())
  const [drawer, setDrawer] = useState(null) // {kind, name}
  const [error, setError] = useState(null)
  const [message, setMessage] = useState(null)
  const [available, setAvailable] = useState(null)
  const [form, setForm] = useState({ object_name: '', target_table: '', fields: '', note: '', load_strategy: 'auto' })

  const act = async (fn, ok) => {
    setError(null); setMessage(null)
    try { await fn(); if (ok) setMessage(ok); await objects.reload() } catch (e) { setError(e) }
  }
  const loadAvailable = () => api.salesforceObjects().then(setAvailable, setError)
  const add = (e) => {
    e.preventDefault()
    act(async () => {
      await api.addObject({
        object_name: form.object_name.trim(),
        target_table: form.target_table.trim(),
        fields: form.fields.split(',').map((f) => f.trim()).filter(Boolean),
        note: form.note,
        load_strategy: form.load_strategy,
      })
      setForm({ object_name: '', target_table: '', fields: '', note: '', load_strategy: 'auto' })
    }, `Added ${form.object_name}. It loads on the next run.`)
  }

  return (
    <>
      <h1>Objects</h1>
      <p className="muted">Which Salesforce objects are synced. Changes apply to the next run — scheduled or manual. Removing an object keeps its Snowflake table and history.</p>
      <Err error={objects.error || error} />
      {message && <div className="okbox">{message}</div>}

      <div className="card">
        <Table
          columns={[
            { key: 'enabled', label: 'Sync', render: (o) => (
              <input type="checkbox" checked={o.enabled} onChange={(e) => act(() => api.patchObject(o.object_name, { enabled: e.target.checked }))} />
            ) },
            { key: 'object_name', label: 'Object', render: (o) => <b>{o.object_name}</b> },
            { key: 'target_table', label: 'Snowflake table', render: (o) => <span className="mono">{o.target_table}</span> },
            { key: 'fields', label: 'Fields', render: (o) => (o.fields.length ? `${o.fields.length} selected` : 'all') },
            { key: 'load_strategy', label: 'Load', render: (o) => (
              <select value={o.load_strategy} title="auto = REST normally, Bulk API 2.0 for big loads"
                onChange={(e) => act(() => api.patchObject(o.object_name, { load_strategy: e.target.value }))}>
                <option value="auto">auto</option><option value="rest">REST</option><option value="bulk">Bulk API</option>
              </select>
            ) },
            { key: 'note', label: 'Note' },
            { key: 'actions', label: '', render: (o) => (
              <div className="row" style={{ gap: 6 }}>
                <button className="btn small" onClick={() => setDrawer({ kind: 'columns', name: o.object_name })}>Columns</button>
                <button className="btn small" onClick={() => setDrawer({ kind: 'counts', name: o.object_name })}>Compare counts</button>
                <button className="btn small" title="Next run reloads this object from scratch"
                  onClick={() => confirm(`Force a full reload of ${o.object_name} on its next run?`) && act(() => api.resetWatermark(o.object_name), `${o.object_name} will fully reload on its next run.`)}>Reset</button>
                <button className="btn small danger"
                  onClick={() => confirm(`Stop syncing ${o.object_name}? Its Snowflake data is kept.`) && act(() => api.removeObject(o.object_name), `Removed ${o.object_name}.`)}>Remove</button>
              </div>
            ) },
          ]}
          rows={objects.data}
          empty={objects.loading ? 'Loading…' : 'No objects configured.'}
        />
      </div>

      <div className="card">
        <h2>Add an object</h2>
        <form onSubmit={add} className="grid" style={{ maxWidth: 640 }}>
          <div className="row">
            <input className="grow" required list="sf-objects" placeholder="Salesforce API name, e.g. Case or Custom__c"
              value={form.object_name} onChange={(e) => setForm({ ...form, object_name: e.target.value })} />
            <datalist id="sf-objects">{(available || []).map((o) => <option key={o.name} value={o.name}>{o.label}</option>)}</datalist>
            <button type="button" className="btn" onClick={loadAvailable}>{available ? `${available.length} objects loaded` : 'Load list from Salesforce'}</button>
          </div>
          <input placeholder="Snowflake table (blank = object name in upper case)" value={form.target_table} onChange={(e) => setForm({ ...form, target_table: e.target.value })} />
          <input placeholder="Only these fields (comma separated; blank = every field)" value={form.fields} onChange={(e) => setForm({ ...form, fields: e.target.value })} />
          <input placeholder="Note (optional)" value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} />
          <label className="muted">Load strategy&nbsp;
            <select value={form.load_strategy} onChange={(e) => setForm({ ...form, load_strategy: e.target.value })}>
              <option value="auto">auto (REST, Bulk API for big loads)</option><option value="rest">REST only</option><option value="bulk">Bulk API 2.0</option>
            </select>
          </label>
          <div><button className="btn primary" type="submit">Validate and add</button></div>
        </form>
      </div>

      {drawer && (
        <Drawer title={`${drawer.kind === 'columns' ? 'Column coverage' : 'Row counts'} — ${drawer.name}`} onClose={() => setDrawer(null)}>
          {drawer.kind === 'columns' ? <ColumnReport name={drawer.name} /> : <CountCompare name={drawer.name} />}
        </Drawer>
      )}
    </>
  )
}
