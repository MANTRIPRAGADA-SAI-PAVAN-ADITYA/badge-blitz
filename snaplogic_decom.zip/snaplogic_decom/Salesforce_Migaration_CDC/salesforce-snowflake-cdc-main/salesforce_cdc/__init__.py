"""Compatibility package for the incremental Salesforce pipeline."""

from app.orchestrator import build_soql_query, get_run_windows, is_run_time_due

__all__ = ["build_soql_query", "get_run_windows", "is_run_time_due"]
