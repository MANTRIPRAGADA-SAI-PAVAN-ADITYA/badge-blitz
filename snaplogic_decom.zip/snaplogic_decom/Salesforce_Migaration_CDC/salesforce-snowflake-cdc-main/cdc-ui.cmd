@echo off
rem Start the CDC web UI and open it in the browser. Usage: cdc-ui.cmd [port]
cd /d "%~dp0"
if not "%~1"=="" set CDC_PORT=%~1
set CDC_OPEN_BROWSER=1
if not exist webui\dist\index.html (
  echo Building web UI...
  pushd webui
  call npm install && call npm run build
  popd
)
py -m app.api
