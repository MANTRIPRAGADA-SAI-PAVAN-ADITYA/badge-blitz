# Salesforce → Snowflake CDC Tracking with Streamlit

## Overview

This document extends the existing incremental pipeline (see
[architecture-slide.md](architecture-slide.md)) with a downstream
change-tracking layer built on Snowflake `STREAM`/`TASK` objects, and a
Streamlit dashboard used to monitor deltas each time the pipeline refreshes.

Two independent delta layers are combined:

1. **Source delta (Salesforce → Snowflake)** — which rows were pulled from
   Salesforce using a watermark field (`SystemModstamp`).
2. **Target delta (inside Snowflake)** — which rows actually changed in the
   final tables after the `MERGE`, captured via `STREAM` objects.

---

## End-to-end architecture

```mermaid
flowchart LR
    SF[Salesforce Objects] -->|SystemModstamp > watermark| PY[Python Orchestrator]
    PY --> STG[Snowflake STG_* tables]
    STG -->|MERGE| RAW[Snowflake RAW_* tables]
    RAW --> STRM[Snowflake STREAM per table]
    STRM -->|TASK on schedule| AUDIT[CDC_AUDIT table]
    RAW --> WM[CONTROL_WATERMARK]
    AUDIT --> ST[Streamlit App]
    WM --> ST
    ST --> USER[Data / Ops Team]
```

---

## Refresh sequence

```mermaid
sequenceDiagram
    participant S as Salesforce
    participant P as Python Orchestrator
    participant STG as Snowflake Staging
    participant RAW as Snowflake Final Table
    participant STR as Snowflake Stream
    participant T as Snowflake Task
    participant A as CDC_AUDIT
    participant D as Streamlit Dashboard

    P->>P: Read CONTROL_WATERMARK
    P->>S: Query WHERE SystemModstamp > watermark
    S-->>P: Changed / deleted rows
    P->>STG: Load rows into STG_<Object>
    STG->>RAW: MERGE into RAW_<Object>
    RAW->>STR: Stream captures INSERT/UPDATE/DELETE
    T->>STR: Scheduled task reads stream
    T->>A: Insert change_type, record_id, change_ts
    P->>P: Update CONTROL_WATERMARK
    D->>A: Query latest deltas
    D->>D: Render KPIs and change log
```

---

## Salesforce objects and delta fields

These are the objects currently configured in
[app/metadata.py](../../app/metadata.py). All three already carry the fields
needed to drive both delta layers directly — no extra Salesforce
configuration is required.

| Salesforce Object | Delta Field (watermark) | Delete Detection | Key Column | Snowflake Stage Table | Snowflake Final Table |
|---|---|---|---|---|---|
| `Account` | `SystemModstamp` | `IsDeleted` | `Id` | `STG_ACCOUNT` | `RAW_ACCOUNT` |
| `Contact` | `SystemModstamp` | `IsDeleted` | `Id` | `STG_CONTACT` | `RAW_CONTACT` |
| `Opportunity` | `SystemModstamp` | `IsDeleted` | `Id` | `STG_OPPORTUNITY` | `RAW_OPPORTUNITY` |

**Why `SystemModstamp`:**
- Updated by Salesforce on *any* change (direct edit, workflow, rollup,
  formula recalculation) — more reliable than `LastModifiedDate`, which only
  updates on direct user/API edits.
- Not editable by users or API, so it can't be spoofed or accidentally reset.
- Present on every standard and custom Salesforce object, so the same
  pattern extends to new objects (e.g. `Lead`, `Case`, custom objects) with
  no design change — just add an `ObjectConfig` entry.

**Adding a new object** only requires appending to
`get_object_configs()` with the same four fields
(`SystemModstamp`, `IsDeleted`, `LastModifiedDate`, `CreatedDate`) plus any
business columns.

---

## Snowflake CDC (target delta) layer

Built on top of the existing [sql/snowflake_streams_tasks.sql](../../sql/snowflake_streams_tasks.sql)
pattern, adding a shared audit table so Streamlit has one place to query.

```sql
-- One stream per final table, already defined per object
CREATE OR REPLACE STREAM RAW_ACCOUNT_STREAM ON TABLE RAW_ACCOUNT;
CREATE OR REPLACE STREAM RAW_CONTACT_STREAM ON TABLE RAW_CONTACT;
CREATE OR REPLACE STREAM RAW_OPPORTUNITY_STREAM ON TABLE RAW_OPPORTUNITY;

-- Shared audit table read by Streamlit
CREATE OR REPLACE TABLE CDC_AUDIT (
    table_name     STRING,
    change_type    STRING,       -- INSERT / UPDATE / DELETE
    record_id      STRING,
    change_ts      TIMESTAMP_LTZ,
    source_system  STRING,
    payload        VARIANT
);

-- One task per stream, aligned to the 00:00 / 06:00 / 12:00 / 18:00 schedule
CREATE OR REPLACE TASK TASK_CDC_ACCOUNT
WAREHOUSE = MY_WH
SCHEDULE = 'USING CRON 0 0,6,12,18 * * * UTC'
AS
INSERT INTO CDC_AUDIT
SELECT 'RAW_ACCOUNT', METADATA$ACTION, ID, CURRENT_TIMESTAMP(), 'Salesforce', OBJECT_CONSTRUCT(*)
FROM RAW_ACCOUNT_STREAM;

ALTER TASK TASK_CDC_ACCOUNT RESUME;
```

Repeat the `TASK_CDC_<OBJECT>` pattern for `Contact` and `Opportunity`.

---

## Streamlit dashboard design

Recommended as a **Streamlit in Snowflake (SiS)** app so it queries
`CDC_AUDIT` and `CONTROL_WATERMARK` directly with no external credentials.

### Layout

| Section | Content |
|---|---|
| Sidebar filter | Table selector (`Account`, `Contact`, `Opportunity`), date range, change type |
| KPI row | Rows inserted, rows updated, rows deleted, net delta since last refresh |
| Watermark panel | Last successful watermark timestamp per object, next scheduled run |
| Trend chart | Change volume over last 24h / 7d, grouped by `change_type` |
| Change log table | Paginated `CDC_AUDIT` rows: `record_id`, `change_type`, `change_ts`, payload preview |
| Reconciliation panel | Source row count (Salesforce, via last extraction log) vs. target row count (Snowflake) |

### Core query examples

```sql
-- KPI counts for the selected table and window
SELECT change_type, COUNT(*) AS cnt
FROM CDC_AUDIT
WHERE table_name = :selected_table
  AND change_ts >= :window_start
GROUP BY change_type;

-- Recent change log
SELECT change_ts, change_type, record_id, payload
FROM CDC_AUDIT
WHERE table_name = :selected_table
ORDER BY change_ts DESC
LIMIT 200;
```

### Minimal app skeleton

```python
import streamlit as st
from snowflake.snowpark.context import get_active_session

st.set_page_config(page_title="Salesforce CDC Monitor", layout="wide")
session = get_active_session()

tables = ["RAW_ACCOUNT", "RAW_CONTACT", "RAW_OPPORTUNITY"]
selected = st.sidebar.selectbox("Table", tables)
hours = st.sidebar.slider("Window (hours)", 1, 168, 24)

kpis = session.sql(f"""
    SELECT change_type, COUNT(*) AS cnt
    FROM CDC_AUDIT
    WHERE table_name = '{selected}'
      AND change_ts >= DATEADD('hour', -{hours}, CURRENT_TIMESTAMP())
    GROUP BY change_type
""").to_pandas()

cols = st.columns(3)
for i, ct in enumerate(["INSERT", "UPDATE", "DELETE"]):
    count = int(kpis.loc[kpis.CHANGE_TYPE == ct, "CNT"].sum()) if not kpis.empty else 0
    cols[i].metric(ct.title(), count)

log = session.sql(f"""
    SELECT change_ts, change_type, record_id
    FROM CDC_AUDIT
    WHERE table_name = '{selected}'
    ORDER BY change_ts DESC
    LIMIT 200
""").to_pandas()
st.dataframe(log, use_container_width=True)
```

---

## Implementation phases

1. Enable `CHANGE_TRACKING` and create `STREAM`s on `RAW_ACCOUNT`,
   `RAW_CONTACT`, `RAW_OPPORTUNITY`.
2. Create the shared `CDC_AUDIT` table and one `TASK_CDC_<OBJECT>` per
   stream, aligned to the existing 00:00/06:00/12:00/18:00 schedule.
3. Build the Streamlit app (SiS) reading from `CDC_AUDIT` and
   `CONTROL_WATERMARK`.
4. Add reconciliation query comparing Salesforce extraction counts (from
   pipeline logs) against `CDC_AUDIT` insert/update counts per run.
5. Extend to new Salesforce objects by adding an `ObjectConfig` entry and a
   matching stream/task pair — no dashboard changes required.
