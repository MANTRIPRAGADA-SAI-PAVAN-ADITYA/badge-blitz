"""Application configuration.

Values are read from environment variables (or a ``.env`` file next to this
file). See ``.env.example`` for every supported setting.
"""
import os
import secrets
from datetime import timedelta
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

DATABASE_DIR = BASE_DIR / "database"
DATABASE_DIR.mkdir(exist_ok=True)
OUTBOX_DIR = DATABASE_DIR / "outbox"


def _bool(name: str, default: bool = False) -> bool:
    return os.getenv(name, str(default)).strip().lower() in ("1", "true", "yes", "on")


def _secret_key() -> str:
    """Use SECRET_KEY if provided, otherwise generate one and persist it."""
    key = os.getenv("SECRET_KEY")
    if key:
        return key
    key_file = DATABASE_DIR / ".secret_key"
    if key_file.exists():
        return key_file.read_text().strip()
    key = secrets.token_hex(32)
    key_file.write_text(key)
    return key


class Config:
    SECRET_KEY = _secret_key()
    SQLALCHEMY_DATABASE_URI = os.getenv(
        "DATABASE_URL", "sqlite:///" + (DATABASE_DIR / "requests.db").as_posix()
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = _bool("SESSION_COOKIE_SECURE", False)
    PERMANENT_SESSION_LIFETIME = timedelta(hours=8)

    HOST = os.getenv("HOST", "0.0.0.0")
    PORT = int(os.getenv("PORT", "5000"))
    DEBUG = _bool("FLASK_DEBUG", False)
    PER_PAGE = int(os.getenv("PER_PAGE", "10"))

    # --- Default accounts created by init_db (change after first login!) ---
    DEFAULT_ADMIN_EMAIL = os.getenv("DEFAULT_ADMIN_EMAIL", "admin@company.com")
    DEFAULT_ADMIN_PASSWORD = os.getenv("DEFAULT_ADMIN_PASSWORD", "Admin@123")
    DEFAULT_USER_EMAIL = os.getenv("DEFAULT_USER_EMAIL", "user@company.com")
    DEFAULT_USER_PASSWORD = os.getenv("DEFAULT_USER_PASSWORD", "User@123")

    # --- Email (Outlook / Office 365 SMTP by default) ---
    MAIL_ENABLED = _bool("MAIL_ENABLED", False)  # False => write .eml to database/outbox
    MAIL_SERVER = os.getenv("MAIL_SERVER", "smtp.office365.com")
    MAIL_PORT = int(os.getenv("MAIL_PORT", "587"))
    MAIL_USE_TLS = _bool("MAIL_USE_TLS", True)
    MAIL_USERNAME = os.getenv("MAIL_USERNAME", "")
    MAIL_PASSWORD = os.getenv("MAIL_PASSWORD", "")
    MAIL_SENDER = os.getenv("MAIL_SENDER", "snowflake-access-portal@company.com")
    # Comma-separated fallback list; admins can manage the live list on the Notification Emails page.
    ADMIN_TEAM_EMAILS = [e.strip() for e in os.getenv("ADMIN_TEAM_EMAILS", "dataengineering@company.com").split(",") if e.strip()]
    PORTAL_URL = os.getenv("PORTAL_URL", "http://localhost:5000")

    # --- Authentication: "local" or "ad" (Active Directory placeholder) ---
    AUTH_MODE = os.getenv("AUTH_MODE", "local").lower()
    LDAP_SERVER = os.getenv("LDAP_SERVER", "ldap://dc.company.com")
    LDAP_DOMAIN = os.getenv("LDAP_DOMAIN", "company.com")

    # --- Snowflake lookup (read-only service user, RSA key-pair auth) ---
    SNOWFLAKE_ENABLED = _bool("SNOWFLAKE_ENABLED", False)
    SNOWFLAKE_ACCOUNT = os.getenv("SNOWFLAKE_ACCOUNT", "")
    SNOWFLAKE_USER = os.getenv("SNOWFLAKE_USER", "")
    SNOWFLAKE_ROLE = os.getenv("SNOWFLAKE_ROLE", "")
    SNOWFLAKE_WAREHOUSE = os.getenv("SNOWFLAKE_WAREHOUSE", "")
    SNOWFLAKE_PRIVATE_KEY_PATH = os.getenv("SNOWFLAKE_PRIVATE_KEY_PATH", str(BASE_DIR / "keys" / "rsa_key.p8"))
    SNOWFLAKE_PRIVATE_KEY_PASSPHRASE = os.getenv("SNOWFLAKE_PRIVATE_KEY_PASSPHRASE", "")
    SNOWFLAKE_CACHE_MINUTES = int(os.getenv("SNOWFLAKE_CACHE_MINUTES", "15"))
    EXCLUDED_DATABASES = [x.strip().upper() for x in
                          os.getenv("EXCLUDED_DATABASES", "SNOWFLAKE,SNOWFLAKE_SAMPLE_DATA").split(",") if x.strip()]
    EXCLUDED_SCHEMAS = [x.strip().upper() for x in
                        os.getenv("EXCLUDED_SCHEMAS", "INFORMATION_SCHEMA,PUBLIC").split(",") if x.strip()]


# --- Form option lists ---
DATABASES = ["PROD_PACIFICDM_DB", "DEV_PACIFICDM_DB", "UAT_PACIFICDM_DB"]
ACCESS_ROLES = {"RO": "Read Only (RO)", "RW": "Read Write (RW)", "FULL": "Full"}
DURATIONS = ["Permanent", "30 Days", "60 Days", "90 Days"]
STATUSES = ["Pending", "Approved", "Rejected", "Completed"]
ROLES = ["requestor", "admin"]
