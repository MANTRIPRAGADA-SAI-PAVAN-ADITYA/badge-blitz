"""Authentication: local password check, with an Active Directory placeholder."""
from config import Config
from models import User, db


def _ad_authenticate(email: str, password: str) -> bool:
    """PLACEHOLDER: bind to Active Directory using the user's UPN.

    Requires ``pip install ldap3`` and AUTH_MODE=ad. Adjust LDAP_SERVER in .env.
    """
    try:
        from ldap3 import Connection, Server
    except ImportError:
        return False
    try:
        conn = Connection(Server(Config.LDAP_SERVER), user=email, password=password, auto_bind=True)
        conn.unbind()
        return True
    except Exception:
        return False


def authenticate(email: str, password: str):
    """Return the User on success, otherwise None."""
    email = (email or "").strip().lower()
    user = User.query.filter(db.func.lower(User.email) == email).first()
    if Config.AUTH_MODE == "ad" and password and _ad_authenticate(email, password):
        if user is None:  # first AD login: provision a requestor account
            user = User(name=email.split("@")[0].title(), email=email, role="requestor")
            user.set_password("!ad-managed!" + email)
            db.session.add(user)
            db.session.commit()
        return user if user.active else None
    if user and user.active and user.check_password(password or ""):
        return user
    return None
