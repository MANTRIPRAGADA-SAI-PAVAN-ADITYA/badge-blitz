"""Verify integrations from the command line.

    python test_integrations.py mail you@company.com     # send a test email
    python test_integrations.py snowflake                # test RSA key-pair login
    python test_integrations.py lookup you@company.com   # show catalog size + that user's access
"""
import json
import sys

import email_service
import snowflake_service
from app import app


def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else ""
    if cmd == "snowflake":
        ok, msg = snowflake_service.test_connection()
        print(("OK: " if ok else "FAILED: ") + msg)
        sys.exit(0 if ok else 1)
    if cmd == "lookup" and len(sys.argv) > 2:
        r = snowflake_service.lookup(sys.argv[2], refresh=True)
        print("ok:", r["ok"], "| mapped:", r["mapped"], "|", r["message"])
        print("databases:", len(r["databases"]), "| schemas:", sum(map(len, r["databases"].values())))
        print(json.dumps(r["current"], indent=2))
        return
    if cmd == "mail" and len(sys.argv) > 2:
        with app.app_context():
            if not app.config["MAIL_ENABLED"]:
                print("MAIL_ENABLED is false: the message will only be saved to database/outbox.")
            ok = email_service.send_email([sys.argv[2]], "Snowflake Access Portal - test email",
                                          "<p>SMTP configuration works.</p>")
            print("OK" if ok else "FAILED (see the audit log for the error)")
        return
    sys.exit(__doc__)


if __name__ == "__main__":
    main()
