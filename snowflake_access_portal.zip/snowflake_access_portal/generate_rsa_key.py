"""Generate an RSA key pair for the portal's Snowflake service user.

    python generate_rsa_key.py [--passphrase]

Writes keys/rsa_key.p8 (private, keep secret) and keys/rsa_key.pub, then prints
the ALTER USER statement a Snowflake admin must run to register the public key.
"""
import getpass
import sys
from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa

keys = Path(__file__).resolve().parent / "keys"
keys.mkdir(exist_ok=True)
priv_path, pub_path = keys / "rsa_key.p8", keys / "rsa_key.pub"
if priv_path.exists():
    sys.exit(f"{priv_path} already exists; refusing to overwrite.")

passphrase = getpass.getpass("Passphrase: ").encode() if "--passphrase" in sys.argv else None
key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
enc = serialization.BestAvailableEncryption(passphrase) if passphrase else serialization.NoEncryption()
priv_path.write_bytes(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, enc))
pub_pem = key.public_key().public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo)
pub_path.write_bytes(pub_pem)
body = "".join(l for l in pub_pem.decode().splitlines() if "KEY" not in l)

print(f"Private key: {priv_path}\nPublic key : {pub_path}\n")
print("Ask a Snowflake admin to run:\n")
print(f"ALTER USER <PORTAL_SERVICE_USER> SET RSA_PUBLIC_KEY='{body}';\n")
print("Then set in .env: SNOWFLAKE_ENABLED=true, SNOWFLAKE_ACCOUNT, SNOWFLAKE_USER, SNOWFLAKE_ROLE, "
      "SNOWFLAKE_PRIVATE_KEY_PATH" + (", SNOWFLAKE_PRIVATE_KEY_PASSPHRASE" if passphrase else ""))
