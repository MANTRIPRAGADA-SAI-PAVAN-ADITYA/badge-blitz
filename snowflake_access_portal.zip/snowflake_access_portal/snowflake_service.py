"""Read-only Snowflake lookups (RSA key-pair auth).

* ``lookup(email)`` returns the database/schema catalog plus, when the portal user
  can be matched to a Snowflake user, the access they already hold per schema
  (inferred as RO / RW / FULL from their grants, including inherited roles).
* Results are cached in memory (``SNOWFLAKE_CACHE_MINUTES``); the cache for a
  user is dropped on login and by the form's Refresh button.

Only SHOW commands are issued; nothing is ever granted or changed.
Requires: pip install snowflake-connector-python cryptography
"""
import re
import threading
import time
from pathlib import Path

from config import Config

RANK = {"RO": 1, "RW": 2, "FULL": 3}
WRITE_PRIVS = {"INSERT", "UPDATE", "DELETE", "TRUNCATE"}
MAX_ROLES = 300

_lock = threading.Lock()
_catalog_cache = {"at": 0.0, "data": None}
_user_cache: dict[str, tuple[float, dict]] = {}


# ------------------------------------------------------------ connection
def _private_key_der() -> bytes:
    from cryptography.hazmat.backends import default_backend
    from cryptography.hazmat.primitives import serialization

    path = Path(Config.SNOWFLAKE_PRIVATE_KEY_PATH)
    if not path.is_file():
        raise FileNotFoundError(f"Private key not found: {path}")
    pw = Config.SNOWFLAKE_PRIVATE_KEY_PASSPHRASE
    key = serialization.load_pem_private_key(
        path.read_bytes(), password=pw.encode() if pw else None, backend=default_backend())
    return key.private_bytes(serialization.Encoding.DER, serialization.PrivateFormat.PKCS8,
                             serialization.NoEncryption())


def connect():
    import snowflake.connector
    return snowflake.connector.connect(
        account=Config.SNOWFLAKE_ACCOUNT, user=Config.SNOWFLAKE_USER, private_key=_private_key_der(),
        role=Config.SNOWFLAKE_ROLE or None, warehouse=Config.SNOWFLAKE_WAREHOUSE or None,
        login_timeout=20, network_timeout=60)


def test_connection() -> tuple[bool, str]:
    try:
        conn = connect()
        try:
            row = conn.cursor().execute("SELECT CURRENT_USER(), CURRENT_ROLE()").fetchone()
        finally:
            conn.close()
        return True, f"Connected as {row[0]} with role {row[1]}"
    except Exception as exc:
        return False, f"{type(exc).__name__}: {exc}"


# --------------------------------------------------------------- helpers
def _q(ident: str) -> str:
    return '"' + ident.replace('"', '""') + '"'


def _rows(cur, sql: str) -> list[dict]:
    cur.execute(sql)
    cols = [c[0].lower() for c in cur.description]
    return [dict(zip(cols, r)) for r in cur.fetchall()]


def _split_name(name: str) -> list[str]:
    """'DB.SCHEMA."T 1"' -> ['DB', 'SCHEMA', 'T 1']."""
    return [p[1:-1].replace('""', '"') if p.startswith('"') else p
            for p in re.findall(r'"(?:[^"]|"")*"|[^."]+', name or "")]


# --------------------------------------------------------------- catalog
def fetch_catalog(cur) -> dict[str, list[str]]:
    """{database: [schemas]} excluding system databases/schemas."""
    skip_db, skip_sc = set(Config.EXCLUDED_DATABASES), set(Config.EXCLUDED_SCHEMAS)
    catalog = {}
    for d in _rows(cur, "SHOW DATABASES"):
        name = d["name"]
        if name.upper() in skip_db:
            continue
        schemas = [s["name"] for s in _rows(cur, f"SHOW SCHEMAS IN DATABASE {_q(name)}")
                   if s["name"].upper() not in skip_sc]
        if schemas:
            catalog[name] = sorted(schemas)
    return dict(sorted(catalog.items()))


# ---------------------------------------------------------- user access
def find_user(cur, email: str):
    """Snowflake user whose LOGIN_NAME, EMAIL or NAME equals the portal email."""
    target = email.strip().lower()
    for u in _rows(cur, "SHOW USERS"):
        if target in {str(u.get(k) or "").lower() for k in ("login_name", "email", "name")}:
            return u["name"]
    return None


def infer_access(cur, user: str) -> dict[str, dict[str, str]]:
    """{database: {schema: 'RO'|'RW'|'FULL'}} from the user's roles (incl. inherited)."""
    pending = [r["role"] for r in _rows(cur, f"SHOW GRANTS TO USER {_q(user)}")]
    seen, privs = set(), {}

    def add(parts, priv, on_schema):
        if len(parts) < 2:
            return
        privs.setdefault((parts[0], parts[1]), set()).add(("S:" if on_schema else "") + priv.upper())

    while pending and len(seen) < MAX_ROLES:
        role = pending.pop()
        if role in seen:
            continue
        seen.add(role)
        for g in _rows(cur, f"SHOW GRANTS TO ROLE {_q(role)}"):
            on, priv = (g.get("granted_on") or "").upper(), (g.get("privilege") or "").upper()
            if on == "ROLE" and priv == "USAGE":
                pending.append(g["name"])
            elif on == "SCHEMA":
                add(_split_name(g["name"]), priv, True)
            elif on in ("TABLE", "VIEW", "MATERIALIZED VIEW", "EXTERNAL TABLE", "DYNAMIC TABLE", "EVENT TABLE"):
                add(_split_name(g["name"]), priv, False)
        for g in _rows(cur, f"SHOW FUTURE GRANTS TO ROLE {_q(role)}"):
            on, priv = (g.get("grant_on") or "").upper(), (g.get("privilege") or "").upper()
            if on in ("TABLE", "VIEW"):
                add(_split_name(g["name"]), priv, False)

    access: dict[str, dict[str, str]] = {}
    for (db_, schema), p in privs.items():
        write = bool(p & WRITE_PRIVS)
        if "S:OWNERSHIP" in p or ("S:CREATE TABLE" in p and write):
            level = "FULL"
        elif write:
            level = "RW"
        elif "SELECT" in p:
            level = "RO"
        else:
            continue
        access.setdefault(db_, {})[schema] = level
    return access


# ---------------------------------------------------------------- public
def _fresh(ts: float) -> bool:
    return time.time() - ts < Config.SNOWFLAKE_CACHE_MINUTES * 60


def clear_user_cache(email: str | None = None) -> None:
    with _lock:
        if email is None:
            _user_cache.clear()
            _catalog_cache.update(at=0.0, data=None)
        else:
            _user_cache.pop(email.lower(), None)


def lookup(email: str, refresh: bool = False) -> dict:
    """Return {ok, message, mapped, databases, current}. Never raises."""
    if not Config.SNOWFLAKE_ENABLED:
        return {"ok": False, "mapped": False, "databases": {}, "current": {},
                "message": "Snowflake lookup is not enabled. Enter database and schema names manually."}
    key = email.lower()
    with _lock:
        if refresh:
            _user_cache.pop(key, None)
            _catalog_cache.update(at=0.0, data=None)
        cached = _user_cache.get(key)
        if cached and _fresh(cached[0]):
            return cached[1]
    try:
        conn = connect()
        try:
            cur = conn.cursor()
            with _lock:
                catalog = _catalog_cache["data"] if _catalog_cache["data"] and _fresh(_catalog_cache["at"]) else None
            if catalog is None:
                catalog = fetch_catalog(cur)
                with _lock:
                    _catalog_cache.update(at=time.time(), data=catalog)
            sf_user = find_user(cur, email)
            current = {}
            if sf_user:
                raw = infer_access(cur, sf_user)
                current = {d: {s: lvl for s, lvl in sc.items() if s in catalog[d]}
                           for d, sc in raw.items() if d in catalog}
        finally:
            conn.close()
    except Exception as exc:
        return {"ok": False, "mapped": False, "databases": {}, "current": {},
                "message": f"Could not read Snowflake ({type(exc).__name__}). Enter names manually."}
    result = {"ok": True, "mapped": sf_user is not None, "databases": catalog, "current": current,
              "message": "" if sf_user else
              f"No Snowflake user matches {email}; current access can't be shown. You can still pick or type names."}
    with _lock:
        _user_cache[key] = (time.time(), result)
    return result
