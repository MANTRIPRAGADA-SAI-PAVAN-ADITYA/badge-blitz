// Chart.js dashboard charts
(function () {
  var charts = [];
  var palette = ['#003f2d', '#17e88f', '#2a9d8f', '#e9c46a', '#f4a261', '#6c8ead'];
  var statusColors = ['#f0ad00', '#198754', '#dc3545', '#0d6efd'];

  function build() {
    charts.forEach(function (c) { c.destroy(); });
    charts = [];
    var d = window.CHART_DATA;
    var text = getComputedStyle(document.body).color;
    Chart.defaults.color = text;
    Chart.defaults.borderColor = 'rgba(128,128,128,.25)';
    var integer = { beginAtZero: true, ticks: { precision: 0 } };

    charts.push(new Chart(document.getElementById('chartDb'), {
      type: 'bar',
      data: { labels: d.database.labels, datasets: [{ label: 'Requests', data: d.database.data, backgroundColor: palette }] },
      options: { plugins: { legend: { display: false } }, scales: { y: integer } }
    }));
    charts.push(new Chart(document.getElementById('chartStatus'), {
      type: 'doughnut',
      data: { labels: d.status.labels, datasets: [{ data: d.status.data, backgroundColor: statusColors }] },
      options: { plugins: { legend: { position: 'bottom' } } }
    }));
    charts.push(new Chart(document.getElementById('chartMonthly'), {
      type: 'line',
      data: { labels: d.monthly.labels, datasets: [{ label: 'Requests', data: d.monthly.data, borderColor: '#17a673', backgroundColor: 'rgba(23,232,143,.2)', fill: true, tension: .3 }] },
      options: { plugins: { legend: { display: false } }, scales: { y: integer } }
    }));
  }
  window.rebuildCharts = build;
  if (window.Chart) build();
})();
