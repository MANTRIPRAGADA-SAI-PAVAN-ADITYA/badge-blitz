// Dark mode toggle (persisted in localStorage)
(function () {
  var btn = document.getElementById('themeToggle');
  if (!btn) return;
  function icon() {
    var dark = document.documentElement.getAttribute('data-bs-theme') === 'dark';
    btn.innerHTML = '<i class="bi bi-' + (dark ? 'sun' : 'moon-stars') + '"></i>';
  }
  icon();
  btn.addEventListener('click', function () {
    var next = document.documentElement.getAttribute('data-bs-theme') === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-bs-theme', next);
    try { localStorage.setItem('theme', next); } catch (e) {}
    icon();
    if (window.rebuildCharts) window.rebuildCharts();
  });
})();
