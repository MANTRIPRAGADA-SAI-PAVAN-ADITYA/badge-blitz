// Request form: databases come from Snowflake (with current-access badges) or are typed manually.
(function () {
  var RANK = { RO: 1, RW: 2, FULL: 3 };
  var form = document.getElementById('requestForm');
  var rowsEl = document.getElementById('rows');
  var statusEl = document.getElementById('lookupStatus');
  var info = { ok: false, mapped: false, databases: {}, current: {}, message: '' };
  var counter = 0;

  function el(tag, attrs, children) {
    var e = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) {
      if (k === 'text') e.textContent = attrs[k];
      else if (k === 'class') e.className = attrs[k];
      else e.setAttribute(k, attrs[k]);
    });
    (children || []).forEach(function (c) { e.appendChild(c); });
    return e;
  }

  function setStatus(cls, text) {
    statusEl.className = 'alert py-2 small alert-' + cls;
    statusEl.textContent = text;
  }

  // ---- one row = database + schemas + role
  function addRow(state) {
    state = state || {};
    var id = ++counter;
    var manual = !!state.manual || !info.ok;
    var row = el('div', { class: 'border rounded p-3 mb-3 item-row', 'data-id': id });
    row.appendChild(el('input', { type: 'hidden', name: 'row_id', value: id }));
    var top = el('div', { class: 'row g-2 mb-2' });

    // database
    var dbCol = el('div', { class: 'col-sm-6' });
    var dbField;
    if (manual) {
      dbField = el('input', { class: 'form-control db-field', name: 'database_' + id, list: 'dbSuggest',
        placeholder: 'Database name', maxlength: 255, required: 'required' });
    } else {
      dbField = el('select', { class: 'form-select db-field', name: 'database_' + id, required: 'required' },
        [el('option', { value: '', text: 'Select database...' })].concat(
          Object.keys(info.databases).map(function (d) { return el('option', { value: d, text: d }); })));
    }
    dbField.value = state.database || '';
    dbCol.appendChild(dbField);
    top.appendChild(dbCol);

    // role
    var roleSel = el('select', { class: 'form-select role-field', name: 'role_' + id, required: 'required' },
      [el('option', { value: '', text: 'Role...' })].concat(Object.keys(window.ROLE_LABELS).map(function (k) {
        return el('option', { value: k, text: window.ROLE_LABELS[k] });
      })));
    roleSel.value = state.role || '';
    top.appendChild(el('div', { class: 'col-sm-4' }, [roleSel]));

    var rm = el('button', { type: 'button', class: 'btn btn-outline-danger w-100 remove-row', title: 'Remove' },
      [el('i', { class: 'bi bi-trash' })]);
    top.appendChild(el('div', { class: 'col-sm-2' }, [rm]));
    row.appendChild(top);

    // schemas
    var schemaBox = el('div', { class: 'schema-box' });
    row.appendChild(schemaBox);

    // manual toggle
    if (info.ok) {
      var cb = el('input', { type: 'checkbox', class: 'form-check-input', id: 'man' + id, name: 'manual_' + id, value: '1' });
      cb.checked = manual;
      cb.addEventListener('change', function () { rebuild(row, collectState(row, cb.checked)); });
      row.appendChild(el('div', { class: 'form-check mt-2 small' },
        [cb, el('label', { class: 'form-check-label', for: 'man' + id, text: "Can't find it? Enter names manually" })]));
    }

    rowsEl.appendChild(row);
    fillSchemas(row, manual, state);
    dbField.addEventListener('change', function () { fillSchemas(row, manual, {}); });
    roleSel.addEventListener('change', function () { applyDisabled(row); });
    refreshRemoveButtons();
  }

  function collectState(row, manual) {
    return { database: row.querySelector('.db-field').value, role: row.querySelector('.role-field').value,
             manual: manual, schemas: [], manual_schemas: '' };
  }

  function rebuild(row, state) {
    var next = row.nextSibling;
    row.remove();
    addRow(state);
    rowsEl.insertBefore(rowsEl.lastElementChild, next);  // keep position
  }

  function fillSchemas(row, manual, state) {
    var id = row.getAttribute('data-id');
    var box = row.querySelector('.schema-box');
    box.innerHTML = '';
    var db = row.querySelector('.db-field').value;
    if (manual) {
      box.appendChild(el('input', { class: 'form-control', name: 'manual_schemas_' + id,
        placeholder: 'Schema names, comma separated (e.g. RAW_SF, REPORTING)', value: state.manual_schemas || '' }));
      return;
    }
    if (!db || !info.databases[db]) {
      box.appendChild(el('div', { class: 'small text-body-secondary', text: 'Select a database to see its schemas.' }));
      return;
    }
    var grid = el('div', { class: 'schema-grid' });
    info.databases[db].forEach(function (s) {
      var cid = 'sc' + id + '_' + s;
      var cb = el('input', { type: 'checkbox', class: 'form-check-input', name: 'schemas_' + id, value: s, id: cid });
      cb.checked = (state.schemas || []).indexOf(s) >= 0;
      var have = (info.current[db] || {})[s];
      var label = el('label', { class: 'form-check-label', for: cid, text: s });
      var item = el('div', { class: 'form-check' }, [cb, label]);
      if (have) {
        item.setAttribute('data-have', have);
        item.appendChild(el('span', { class: 'badge text-bg-success ms-1', text: 'Has ' + have }));
      }
      grid.appendChild(item);
    });
    box.appendChild(grid);
    applyDisabled(row);
  }

  // A schema is disabled when the user already holds the selected role (or higher) on it.
  function applyDisabled(row) {
    var want = RANK[row.querySelector('.role-field').value] || 0;
    row.querySelectorAll('.schema-grid .form-check').forEach(function (item) {
      var have = item.getAttribute('data-have');
      var cb = item.querySelector('input');
      var off = !!have && want > 0 && RANK[have] >= want;
      cb.disabled = off;
      if (off) cb.checked = false;
      item.classList.toggle('text-body-secondary', off);
    });
  }

  function refreshRemoveButtons() {
    var rows = rowsEl.querySelectorAll('.item-row');
    rows.forEach(function (r) { r.querySelector('.remove-row').disabled = rows.length === 1; });
  }

  rowsEl.addEventListener('click', function (e) {
    var btn = e.target.closest('.remove-row');
    if (btn && rowsEl.querySelectorAll('.item-row').length > 1) {
      btn.closest('.item-row').remove();
      refreshRemoveButtons();
    }
  });
  document.getElementById('addRow').addEventListener('click', function () { addRow({}); });

  // ---- load access info
  function load(refresh) {
    setStatus('secondary', 'Loading your Snowflake access…');
    var saved = [].map.call(rowsEl.querySelectorAll('.item-row'), function (r) {
      return stateFromDom(r);
    });
    return fetch(window.CATALOG_URL + (refresh ? '?refresh=1' : ''), { credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .catch(function () { return { ok: false, message: 'Lookup failed. Enter names manually.', databases: {}, current: {} }; })
      .then(function (d) {
        info = d;
        if (!d.ok) setStatus('warning', d.message);
        else if (!d.mapped) setStatus('warning', d.message);
        else setStatus('success', 'Showing Snowflake access for your account. Schemas you already have are marked and disabled.');
        return saved;
      });
  }

  function stateFromDom(r) {
    var id = r.getAttribute('data-id');
    var man = r.querySelector('[name=manual_' + id + ']');
    var ms = r.querySelector('[name=manual_schemas_' + id + ']');
    return {
      database: r.querySelector('.db-field').value, role: r.querySelector('.role-field').value,
      manual: !!(man && man.checked) || !!ms, manual_schemas: ms ? ms.value : '',
      schemas: [].map.call(r.querySelectorAll('[name=schemas_' + id + ']:checked'), function (c) { return c.value; })
    };
  }

  document.getElementById('refreshAccess').addEventListener('click', function () {
    load(true).then(function (saved) {
      rowsEl.innerHTML = '';
      (saved.length ? saved : [{}]).forEach(addRow);
    });
  });

  form.addEventListener('submit', function (e) {
    if (!form.checkValidity()) { e.preventDefault(); form.classList.add('was-validated'); return; }
    var ok = [].every.call(rowsEl.querySelectorAll('.item-row'), function (r) {
      var s = stateFromDom(r);
      return s.manual ? s.manual_schemas.trim() : s.schemas.length;
    });
    if (!ok) { e.preventDefault(); alert('Choose at least one schema on every line.'); }
  });

  load(false).then(function () {
    (window.FORM_STATE && window.FORM_STATE.length ? window.FORM_STATE : [{}]).forEach(addRow);
  });
})();
