"""SQLAlchemy models."""
from datetime import datetime, timezone

from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import check_password_hash, generate_password_hash

db = SQLAlchemy()


def utcnow() -> datetime:
    """Naive UTC timestamp (SQLite friendly)."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


class User(db.Model):
    __tablename__ = "users"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(180), unique=True, nullable=False, index=True)
    password = db.Column(db.String(255), nullable=False)  # werkzeug hash
    role = db.Column(db.String(20), nullable=False, default="requestor")
    active = db.Column(db.Boolean, nullable=False, default=True)
    created_date = db.Column(db.DateTime, default=utcnow, nullable=False)

    @property
    def is_admin(self) -> bool:
        return self.role == "admin"

    def set_password(self, raw: str) -> None:
        self.password = generate_password_hash(raw)

    def check_password(self, raw: str) -> bool:
        return check_password_hash(self.password, raw)


class AccessRequest(db.Model):
    __tablename__ = "access_requests"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), index=True)
    requestor_name = db.Column(db.String(120), nullable=False)
    requestor_email = db.Column(db.String(180), nullable=False, index=True)
    team_name = db.Column(db.String(120), nullable=False)
    manager_name = db.Column(db.String(120), nullable=False)
    duration = db.Column(db.String(20), nullable=False)
    reason = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), nullable=False, default="Pending", index=True)
    created_date = db.Column(db.DateTime, default=utcnow, nullable=False)
    updated_date = db.Column(db.DateTime, default=utcnow, onupdate=utcnow, nullable=False)
    approver_comments = db.Column(db.Text)
    approved_by = db.Column(db.String(120))
    expires_date = db.Column(db.DateTime)
    admin_sql = db.Column(db.Text)  # grants the admin ran, pasted for audit (optional)

    user = db.relationship("User", backref="requests")
    items = db.relationship("RequestItem", backref="request", order_by="RequestItem.id",
                            cascade="all, delete-orphan")
    history = db.relationship(
        "ApprovalHistory", backref="request", order_by="ApprovalHistory.timestamp",
        cascade="all, delete-orphan",
    )

    def grouped_items(self):
        """[(database, role, [schemas])] for display."""
        out = {}
        for i in self.items:
            out.setdefault((i.database_name, i.role_type), []).append(i.schema_name)
        return [(d, r, s) for (d, r), s in out.items()]


class RequestItem(db.Model):
    """One database + schema + role (RO / RW / FULL) within a request."""
    __tablename__ = "request_items"
    id = db.Column(db.Integer, primary_key=True)
    request_id = db.Column(db.Integer, db.ForeignKey("access_requests.id"), nullable=False, index=True)
    database_name = db.Column(db.String(255), nullable=False)
    schema_name = db.Column(db.String(255), nullable=False, default="")
    role_type = db.Column(db.String(10), nullable=False)
    source = db.Column(db.String(10), nullable=False, default="catalog")  # catalog | manual


class NotificationEmail(db.Model):
    """Admin-team mailboxes that receive new-request notifications."""
    __tablename__ = "notification_emails"
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(180), unique=True, nullable=False)
    added_by = db.Column(db.String(180))
    created_date = db.Column(db.DateTime, default=utcnow, nullable=False)


class ApprovalHistory(db.Model):
    __tablename__ = "approval_history"
    id = db.Column(db.Integer, primary_key=True)
    request_id = db.Column(db.Integer, db.ForeignKey("access_requests.id"), nullable=False, index=True)
    actor = db.Column(db.String(180), nullable=False)
    action = db.Column(db.String(30), nullable=False)
    comment = db.Column(db.Text)
    timestamp = db.Column(db.DateTime, default=utcnow, nullable=False)


class AuditLog(db.Model):
    __tablename__ = "audit_log"
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=utcnow, nullable=False, index=True)
    actor = db.Column(db.String(180))
    action = db.Column(db.String(50), nullable=False)
    entity = db.Column(db.String(50))
    entity_id = db.Column(db.String(50))
    details = db.Column(db.Text)
    ip_address = db.Column(db.String(64))


class AccessMatrix(db.Model):
    """Pre-approved team/database/role combinations (CSV upload)."""
    __tablename__ = "access_matrix"
    id = db.Column(db.Integer, primary_key=True)
    team_name = db.Column(db.String(120), nullable=False, index=True)
    database_name = db.Column(db.String(80), nullable=False)
    role_type = db.Column(db.String(10), nullable=False)
