"""Database initialisation script.

    python init_db.py          # create tables + default users
    python init_db.py --demo   # also insert sample requests for the charts
"""
import random
import sys
from datetime import timedelta

from app import app, init_db
from config import ACCESS_ROLES, DATABASES, DURATIONS
from models import AccessRequest, RequestItem, User, db, utcnow


def seed_demo():
    with app.app_context():
        if AccessRequest.query.count():
            print("Requests already exist; skipping demo data.")
            return
        user = User.query.filter_by(role="requestor").first()
        for _ in range(25):
            when = utcnow() - timedelta(days=random.randint(0, 300))
            dbs = random.sample(DATABASES, random.randint(1, 2))
            schemas = ["RAW_SF", "REPORTING", "ANALYTICS"]
            db.session.add(AccessRequest(
                user_id=user.id, requestor_name=user.name, requestor_email=user.email,
                team_name=random.choice(["Analytics", "BI", "Finance"]), manager_name="Jane Manager",
                duration=random.choice(DURATIONS), reason="Demo data",
                status=random.choice(["Pending", "Approved", "Rejected", "Completed"]),
                created_date=when, updated_date=when,
                items=[RequestItem(database_name=d, schema_name=sc, role_type=role)
                       for d in dbs for role in [random.choice(list(ACCESS_ROLES))]
                       for sc in random.sample(schemas, random.randint(1, 2))]))
        db.session.commit()
        print("Inserted 25 demo requests.")


if __name__ == "__main__":
    init_db(app)
    print("Database initialised.")
    if "--demo" in sys.argv:
        seed_demo()
