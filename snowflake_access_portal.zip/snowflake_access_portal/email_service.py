"""Email notifications (company mailbox via SMTP / Outlook).

When ``MAIL_ENABLED`` is false the message is written as an ``.eml`` file to
``database/outbox`` instead of being sent, so the portal runs without SMTP.
"""
import logging
import re
import smtplib
import time
from email.message import EmailMessage

from flask import current_app, render_template

from config import OUTBOX_DIR
from models import AuditLog, NotificationEmail, db

log = logging.getLogger(__name__)


def admin_emails() -> list[str]:
    """Admin-team recipients: the managed list, else the .env fallback."""
    emails = [n.email for n in NotificationEmail.query.order_by(NotificationEmail.id)]
    return emails or list(current_app.config["ADMIN_TEAM_EMAILS"])


def _html_to_text(html: str) -> str:
    text = re.sub(r"<(style|script).*?</\1>", "", html, flags=re.S)
    text = re.sub(r"<br\s*/?>|</(p|tr|div|h\d|li)>", "\n", text)
    text = re.sub(r"<[^>]+>", "", text)
    text = text.replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&")
    return re.sub(r"\n\s*\n+", "\n\n", text).strip()


def send_email(to, subject, html, cc=None) -> bool:
    """``to`` / ``cc`` are lists of addresses."""
    cfg = current_app.config
    to, cc = list(to), [c for c in (cc or []) if c not in to]
    msg = EmailMessage()
    msg["From"] = cfg["MAIL_SENDER"]
    msg["To"] = ", ".join(to)
    if cc:
        msg["Cc"] = ", ".join(cc)
    msg["Subject"] = subject
    msg.set_content(_html_to_text(html))
    msg.add_alternative(html, subtype="html")
    recipients = to + cc

    try:
        if cfg["MAIL_ENABLED"]:
            with smtplib.SMTP(cfg["MAIL_SERVER"], cfg["MAIL_PORT"], timeout=20) as smtp:
                if cfg["MAIL_USE_TLS"]:
                    smtp.starttls()
                if cfg["MAIL_USERNAME"]:
                    smtp.login(cfg["MAIL_USERNAME"], cfg["MAIL_PASSWORD"])
                smtp.send_message(msg, to_addrs=recipients)
            outcome = "EMAIL_SENT"
        else:
            OUTBOX_DIR.mkdir(parents=True, exist_ok=True)
            (OUTBOX_DIR / f"{int(time.time() * 1000)}.eml").write_bytes(bytes(msg))
            outcome = "EMAIL_SAVED_TO_OUTBOX"
        ok, detail = True, ""
    except Exception as exc:  # never let mail problems break the workflow
        log.exception("Email failed")
        outcome, ok, detail = "EMAIL_FAILED", False, f" error={exc}"
    db.session.add(AuditLog(actor="system", action=outcome, entity="email",
                            details=f"to={recipients} subject={subject}{detail}"))
    db.session.commit()
    return ok


def notify_submitted(req) -> bool:
    """TO admin team, CC requestor."""
    html = render_template("email/request_submitted.html", r=req,
                           portal_url=current_app.config["PORTAL_URL"])
    return send_email(admin_emails(), f"Snowflake Access Request #{req.id}", html,
                      cc=[req.requestor_email])


def notify_decision(req) -> bool:
    """TO requestor, CC admin team."""
    html = render_template("email/decision.html", r=req,
                           portal_url=current_app.config["PORTAL_URL"])
    return send_email([req.requestor_email], f"Snowflake Access Request #{req.id} - {req.status}",
                      html, cc=admin_emails())
