# Snowflake Access Request Portal

Internal Flask app that replaces ad-hoc Teams requests for Snowflake access.

**Workflow**

1. A user (e.g. a new joiner) logs in and raises **one request for one or more databases**. For each database they
   tick the **schemas** and choose a role: **RO** (Read Only), **RW** (Read Write) or **FULL**. The lists come live from
   Snowflake, and schemas the user already has are badged and disabled (see below).
2. The portal emails the **admin team** (addresses you manage in the portal) and **CC's the requestor**, and stores the request for audit.
3. An admin reviews it, approves or rejects (with comments), writes and runs the grants **in Snowflake themselves**,
   then marks the request **Completed** (optionally pasting the SQL they ran, for the audit trail).
4. The requestor is emailed on approval, rejection and completion (CC the admin team).

The portal does not generate or execute any SQL.

## Setup (Windows)

```powershell
cd snowflake_access_portal
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env      # optional; edit mail settings
python app.py
```

Open <http://localhost:5000>. Tables and default users are created on first start
(or run `python init_db.py`; add `--demo` for 25 sample requests).

| Role | Email | Password |
|---|---|---|
| Admin | admin@company.com | Admin@123 |
| Requestor | user@company.com | User@123 |

**Change these passwords** (Users page / `.env`) before real use. If you upgrade from an earlier version of this
project, delete `database/requests.db` once: the schema changed.
Bootstrap, Bootstrap Icons and Chart.js load from the jsDelivr CDN, so browsers need internet access.

## Snowflake lookup (databases, schemas, current access)

With `SNOWFLAKE_ENABLED=true` the request form lists every database and schema (minus `EXCLUDED_DATABASES` /
`EXCLUDED_SCHEMAS`) and marks what the signed-in user already holds. Only `SHOW` commands are run; nothing is changed.

1. `python generate_rsa_key.py --passphrase` creates `keys/rsa_key.p8` and prints an `ALTER USER <PORTAL_SERVICE_USER> SET RSA_PUBLIC_KEY=...`
   statement for a Snowflake admin to run.
2. The service user's role needs USAGE on the databases/schemas to be listed (`SHOW DATABASES` only returns what its role can see)
   and MANAGE GRANTS (or equivalent) so `SHOW GRANTS TO USER/ROLE` works for other users.
3. Set `SNOWFLAKE_ENABLED`, `SNOWFLAKE_ACCOUNT`, `SNOWFLAKE_USER`, `SNOWFLAKE_ROLE`, `SNOWFLAKE_WAREHOUSE`,
   `SNOWFLAKE_PRIVATE_KEY_PATH` (and `..._PASSPHRASE`) in `.env`.
4. Test: `python test_integrations.py snowflake`, then `python test_integrations.py lookup user@company.com`.

How it works: the portal email is matched to a Snowflake user (LOGIN_NAME, EMAIL or NAME). The user's roles, including
inherited ones, are read with `SHOW GRANTS TO ROLE` / `SHOW FUTURE GRANTS TO ROLE`, and each schema is classified:
**FULL** = schema OWNERSHIP (or CREATE TABLE plus write), **RW** = INSERT/UPDATE/DELETE/TRUNCATE, **RO** = SELECT.
A schema is disabled when the user already has the selected role or higher, so an upgrade (RO to RW) is still possible.
Results are cached for `SNOWFLAKE_CACHE_MINUTES` (default 15), cleared on login and by the form's Refresh button.
Users see only their own access; admins can load a requestor's access from the request page.

If Snowflake is unreachable the form falls back to **manual entry** (names are validated for format only and flagged
for admins and in the email). If no Snowflake user matches the email, the catalog still shows and manual entry is available.

## Admin team email addresses

Log in as admin, open **Notification Emails**, and add one or more addresses (comma separated). New requests go
**TO** these addresses and **CC** the requestor. `ADMIN_TEAM_EMAILS` in `.env` only seeds the list on first run.

## Company mail (SMTP)

By default `MAIL_ENABLED=false`: messages are saved as `.eml` files in `database/outbox/` and nothing is sent.
To send real mail set in `.env`:

```
MAIL_ENABLED=true
MAIL_SERVER=smtp.office365.com
MAIL_PORT=587
MAIL_USERNAME=svc-snowflake-portal@company.com
MAIL_PASSWORD=...
MAIL_SENDER=svc-snowflake-portal@company.com
```

The mailbox needs SMTP AUTH enabled. For an internal relay that needs no login, set the relay host/port,
`MAIL_USE_TLS=false` and leave `MAIL_USERNAME` empty. Test with `python test_integrations.py mail you@company.com`.
Templates are in `templates/email/`; every send (or failure) is written to the audit log.

## Other features

- Requestor: submit requests, view own history, status and approver comments.
- Admin: all requests, approve / reject / complete, CSV export (one row per database), users, audit log,
  access-matrix CSV upload (`team,database,role`; flags requests that are pre-approved for the team).
- Dashboard: stat cards, Chart.js charts, search, sortable columns, pagination, dark mode.
- Security: CSRF protection, hashed passwords, login throttling, role-based access.
- Active Directory login placeholder: `pip install ldap3`, set `AUTH_MODE=ad` and `LDAP_SERVER`.

## Production notes

Run behind a real WSGI server, e.g. `pip install waitress` then `waitress-serve --port=5000 app:app`.
Set `SECRET_KEY`, `SESSION_COOKIE_SECURE=true` (with HTTPS) and change the default passwords.
The SQLite file is `database/requests.db`; back it up regularly.
