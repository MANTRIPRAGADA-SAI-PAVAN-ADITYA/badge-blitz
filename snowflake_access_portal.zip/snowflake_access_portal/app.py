"""Snowflake Access Request Portal - Flask application.

Requestors raise access requests (one or more databases, each with an RO / RW / FULL
role). The admin team is emailed, reviews the request and applies the grants in
Snowflake themselves; the portal only tracks the request.

Run with:  python app.py   ->  http://localhost:5000
"""
import csv
import hmac
import io
import re
import secrets
import time
from collections import Counter, defaultdict
from datetime import timedelta
from functools import wraps
from urllib.parse import urlparse

from flask import (Flask, Response, abort, flash, g, jsonify, redirect, render_template,
                   request, session, url_for)
from sqlalchemy import or_

import auth_service
import email_service
import snowflake_service
from config import (ACCESS_ROLES, DATABASES, DURATIONS, ROLES, STATUSES, Config)
from models import (AccessMatrix, AccessRequest, ApprovalHistory, AuditLog,
                    NotificationEmail, RequestItem, User, db, utcnow)

IDENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_$]{0,254}$")
EMAIL_RE = re.compile(r"^[^@\s,;]+@[^@\s,;]+\.[^@\s,;]+$")
SORT_COLUMNS = {
    "id": AccessRequest.id, "requestor": AccessRequest.requestor_name,
    "team": AccessRequest.team_name, "status": AccessRequest.status,
    "created": AccessRequest.created_date,
}
_failed_logins: dict[str, list[float]] = defaultdict(list)


# ---------------------------------------------------------------- helpers
def audit(action, entity=None, entity_id=None, details=None, actor=None, commit=True):
    db.session.add(AuditLog(
        actor=actor or (g.user.email if getattr(g, "user", None) else "anonymous"),
        action=action, entity=entity, entity_id=str(entity_id) if entity_id else None,
        details=details, ip_address=request.remote_addr))
    if commit:
        db.session.commit()


def csv_safe(value) -> str:
    """Neutralise CSV/Excel formula injection."""
    s = "" if value is None else str(value)
    return "'" + s if s[:1] in ("=", "+", "-", "@", "\t", "\r") else s


def csrf_token() -> str:
    if "_csrf" not in session:
        session["_csrf"] = secrets.token_hex(16)
    return session["_csrf"]


def login_required(fn):
    @wraps(fn)
    def wrapper(*a, **kw):
        if g.user is None:
            return redirect(url_for("login", next=request.full_path.rstrip("?")))
        return fn(*a, **kw)
    return wrapper


def role_required(*roles):
    """RBAC decorator."""
    def deco(fn):
        @wraps(fn)
        @login_required
        def wrapper(*a, **kw):
            if g.user.role not in roles:
                abort(403)
            return fn(*a, **kw)
        return wrapper
    return deco


def get_request_or_404(req_id) -> AccessRequest:
    r = db.session.get(AccessRequest, req_id)
    if r is None or (not g.user.is_admin and r.user_id != g.user.id):
        abort(404)
    return r


def matrix_match(r: AccessRequest) -> bool:
    """True when every requested database/role is pre-approved for the team."""
    if not r.items:
        return False
    return all(AccessMatrix.query.filter(
        db.func.lower(AccessMatrix.team_name) == r.team_name.lower(),
        AccessMatrix.database_name == i.database_name,
        AccessMatrix.role_type == i.role_type).first() for i in r.items)


def create_app() -> Flask:
    app = Flask(__name__)
    app.config.from_object(Config)
    db.init_app(app)

    # ------------------------------------------------------------ hooks
    @app.before_request
    def load_user():
        g.user = None
        uid = session.get("uid")
        if uid:
            u = db.session.get(User, uid)
            if u and u.active:
                g.user = u
            else:
                session.clear()
        if request.method == "POST":
            sent = request.form.get("csrf_token") or request.headers.get("X-CSRF-Token", "")
            if not hmac.compare_digest(sent, session.get("_csrf", "")):
                abort(400, "Invalid or missing CSRF token.")

    @app.after_request
    def security_headers(resp):
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("X-Frame-Options", "DENY")
        return resp

    @app.context_processor
    def inject():
        def url_with(**kw):
            args = request.args.to_dict()
            args.update(kw)
            return url_for(request.endpoint, **args)
        return dict(csrf_token=csrf_token, url_with=url_with, current_user=g.user,
                    STATUSES=STATUSES, ACCESS_ROLES=ACCESS_ROLES)

    @app.errorhandler(403)
    @app.errorhandler(404)
    @app.errorhandler(400)
    def error_page(e):
        return render_template("error.html", error=e), e.code

    # ------------------------------------------------------------- auth
    @app.route("/")
    def index():
        return redirect(url_for("dashboard" if g.user else "login"))

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if g.user:
            return redirect(url_for("dashboard"))
        if request.method == "POST":
            email = request.form.get("email", "").strip().lower()
            key = f"{email}|{request.remote_addr}"
            now = time.time()
            _failed_logins[key] = [t for t in _failed_logins[key] if now - t < 300]
            if len(_failed_logins[key]) >= 5:
                flash("Too many failed attempts. Try again in a few minutes.", "danger")
                return render_template("login.html"), 429
            user = auth_service.authenticate(email, request.form.get("password", ""))
            if user:
                session.clear()
                session["uid"] = user.id
                session.permanent = True
                _failed_logins.pop(key, None)
                g.user = user
                snowflake_service.clear_user_cache(user.email)  # refresh access list on login
                audit("LOGIN", "user", user.id)
                nxt = request.args.get("next", "")
                p = urlparse(nxt)
                if nxt.startswith("/") and not nxt.startswith("//") and not p.netloc:
                    return redirect(nxt)
                return redirect(url_for("dashboard"))
            _failed_logins[key].append(now)
            audit("LOGIN_FAILED", "user", None, f"email={email}", actor=email)
            flash("Invalid email or password.", "danger")
        return render_template("login.html")

    @app.route("/logout", methods=["POST"])
    @login_required
    def logout():
        audit("LOGOUT", "user", g.user.id)
        session.clear()
        return redirect(url_for("login"))

    # -------------------------------------------------------- dashboard
    @app.route("/dashboard")
    @login_required
    def dashboard():
        base = AccessRequest.query
        if not g.user.is_admin:
            base = base.filter(AccessRequest.user_id == g.user.id)

        counts = Counter(s for (s,) in base.with_entities(AccessRequest.status).all())
        stats = {"total": sum(counts.values()), "pending": counts["Pending"],
                 "approved": counts["Approved"] + counts["Completed"],
                 "rejected": counts["Rejected"]}
        item_q = db.session.query(RequestItem.request_id, RequestItem.database_name).join(
            AccessRequest, AccessRequest.id == RequestItem.request_id)
        if not g.user.is_admin:
            item_q = item_q.filter(AccessRequest.user_id == g.user.id)
        by_db = Counter(d for _, d in set(item_q.all()))  # distinct requests per database
        monthly = Counter(c.strftime("%Y-%m") for (c,) in base.with_entities(AccessRequest.created_date).all())
        months, cur = [], utcnow().replace(day=1)
        for _ in range(12):
            months.append(cur.strftime("%Y-%m"))
            cur = (cur - timedelta(days=1)).replace(day=1)
        months.reverse()
        charts = {
            "database": {"labels": list(by_db), "data": list(by_db.values())},
            "status": {"labels": STATUSES, "data": [counts[s] for s in STATUSES]},
            "monthly": {"labels": months, "data": [monthly[m] for m in months]},
        }

        q = request.args.get("q", "").strip()
        status = request.args.get("status", "")
        sort = request.args.get("sort", "created")
        direction = request.args.get("dir", "desc")
        query = base
        if q:
            like = f"%{q}%"
            conds = [AccessRequest.requestor_name.ilike(like), AccessRequest.requestor_email.ilike(like),
                     AccessRequest.team_name.ilike(like),
                     AccessRequest.items.any(RequestItem.database_name.ilike(like))]
            if q.lstrip("#").isdigit():
                conds.append(AccessRequest.id == int(q.lstrip("#")))
            query = query.filter(or_(*conds))
        if status in STATUSES:
            query = query.filter(AccessRequest.status == status)
        col = SORT_COLUMNS.get(sort, AccessRequest.created_date)
        query = query.order_by(col.asc() if direction == "asc" else col.desc(), AccessRequest.id.desc())
        page = request.args.get("page", 1, type=int)
        pagination = query.paginate(page=page, per_page=app.config["PER_PAGE"], error_out=False)
        return render_template("dashboard.html", stats=stats, charts=charts, pagination=pagination,
                               q=q, status=status, sort=sort, direction=direction)

    # ----------------------------------------------------- new request
    @app.route("/api/access-catalog")
    @login_required
    def access_catalog():
        """Databases/schemas plus the caller's current access. Admins may pass ?email=."""
        email = g.user.email
        target = request.args.get("email", "").strip()
        if target and target.lower() != email.lower():
            if not g.user.is_admin:
                abort(403)
            email = target
        return jsonify(snowflake_service.lookup(email, refresh=request.args.get("refresh") == "1"))

    def _parse_rows(f, info):
        """Turn posted rows into [(db, schema, role, source)] plus errors."""
        rows, errors, seen = [], [], set()
        for rid in f.getlist("row_id"):
            db_name = f.get(f"database_{rid}", "").strip()
            role = f.get(f"role_{rid}", "").strip()
            manual = f.get(f"manual_{rid}") == "1" or not info["ok"]
            schemas = [x.strip() for x in f.getlist(f"schemas_{rid}")]
            if manual:
                schemas += [x.strip() for x in re.split(r"[,;\s]+", f.get(f"manual_schemas_{rid}", "")) if x.strip()]
            schemas = list(dict.fromkeys(schemas))
            if not db_name or role not in ACCESS_ROLES or not schemas:
                errors.append("Each line needs a database, at least one schema and a role.")
                continue
            if not IDENT_RE.match(db_name) or not all(IDENT_RE.match(x) for x in schemas):
                errors.append("Database and schema names may only contain letters, digits, _ and $.")
                continue
            for sc in schemas:
                key = (db_name.upper(), sc.upper())
                if key in seen:
                    errors.append(f"{db_name}.{sc} is listed more than once.")
                    continue
                seen.add(key)
                in_catalog = db_name in info["databases"] and sc in info["databases"].get(db_name, [])
                if not manual and not in_catalog:
                    errors.append(f"{db_name}.{sc} was not found in Snowflake.")
                    continue
                have = info["current"].get(db_name, {}).get(sc) if in_catalog else None
                if have and snowflake_service.RANK[have] >= snowflake_service.RANK[role]:
                    errors.append(f"You already have {have} on {db_name}.{sc}.")
                    continue
                rows.append((db_name, sc, role, "manual" if manual else "catalog"))
        if not f.getlist("row_id"):
            errors.append("Add at least one database.")
        return rows, list(dict.fromkeys(errors))

    @app.route("/request/new", methods=["GET", "POST"])
    @login_required
    def new_request():
        v = {"requestor_name": g.user.name, "requestor_email": g.user.email, "duration": "Permanent", "items": []}
        if request.method == "POST":
            f = request.form
            v = {k: f.get(k, "").strip() for k in
                 ("requestor_name", "requestor_email", "team_name", "manager_name", "duration", "reason")}
            v["items"] = [{"database": f.get(f"database_{rid}", ""), "role": f.get(f"role_{rid}", ""),
                           "schemas": f.getlist(f"schemas_{rid}"), "manual": f.get(f"manual_{rid}") == "1",
                           "manual_schemas": f.get(f"manual_schemas_{rid}", "")} for rid in f.getlist("row_id")]
            info = snowflake_service.lookup(g.user.email)
            rows, errors = _parse_rows(f, info)
            for k, label in (("requestor_name", "Name"), ("team_name", "Team"),
                             ("manager_name", "Manager name"), ("reason", "Business justification")):
                if not v[k]:
                    errors.append(f"{label} is required.")
            if not EMAIL_RE.match(v["requestor_email"]):
                errors.append("A valid email is required.")
            if len(v["reason"]) > 2000:
                errors.append("Justification is too long (max 2000 characters).")
            if v["duration"] not in DURATIONS:
                errors.append("Invalid duration.")
            if not errors:
                r = AccessRequest(
                    user_id=g.user.id, requestor_name=v["requestor_name"],
                    requestor_email=v["requestor_email"].lower(), team_name=v["team_name"],
                    manager_name=v["manager_name"], duration=v["duration"], reason=v["reason"],
                    status="Pending",
                    items=[RequestItem(database_name=d, schema_name=sc, role_type=ro, source=src)
                           for d, sc, ro, src in rows])
                db.session.add(r)
                db.session.flush()
                db.session.add(ApprovalHistory(request_id=r.id, actor=g.user.email, action="Submitted"))
                audit("REQUEST_SUBMITTED", "access_request", r.id,
                      ", ".join(f"{d}.{sc}:{ro}" for d, sc, ro, _ in rows), commit=False)
                db.session.commit()
                email_service.notify_submitted(r)
                flash(f"Request #{r.id} submitted. The admin team has been notified and you were copied.", "success")
                return redirect(url_for("request_details", req_id=r.id))
            for e in errors:
                flash(e, "danger")
        return render_template("request_form.html", v=v, DATABASES=DATABASES, DURATIONS=DURATIONS)

    # ---------------------------------------------------- request views
    @app.route("/request/<int:req_id>")
    @login_required
    def request_details(req_id):
        r = get_request_or_404(req_id)
        return render_template("request_details.html", r=r, matrix_ok=matrix_match(r))

    @app.route("/request/<int:req_id>/action", methods=["POST"])
    @role_required("admin")
    def request_action(req_id):
        r = get_request_or_404(req_id)
        transitions = {"approve": ("Pending", "Approved"), "reject": ("Pending", "Rejected"),
                       "complete": ("Approved", "Completed")}
        action = request.form.get("action", "")
        comment = request.form.get("comment", "").strip()[:2000]
        admin_sql = request.form.get("admin_sql", "").strip()[:10000]
        if action not in transitions:
            abort(400)
        required, new_status = transitions[action]
        if r.status != required:
            flash(f"Request is {r.status}; cannot {action}.", "warning")
            return redirect(url_for("request_details", req_id=r.id))
        if action == "reject" and not comment:
            flash("A comment is required when rejecting a request.", "danger")
            return redirect(url_for("request_details", req_id=r.id))
        r.status = new_status
        if comment:
            r.approver_comments = comment
        if admin_sql and action == "complete":
            r.admin_sql = admin_sql
        r.approved_by = g.user.name
        if action == "approve":
            days = None if r.duration == "Permanent" else int(r.duration.split()[0])
            r.expires_date = utcnow() + timedelta(days=days) if days else None
        db.session.add(ApprovalHistory(request_id=r.id, actor=g.user.email, action=new_status, comment=comment))
        audit(f"REQUEST_{new_status.upper()}", "access_request", r.id, comment, commit=False)
        db.session.commit()
        if new_status in ("Approved", "Rejected", "Completed"):
            email_service.notify_decision(r)
        flash(f"Request #{r.id} marked {new_status}.", "success")
        return redirect(url_for("request_details", req_id=r.id))

    # ------------------------------------------------------------ admin
    @app.route("/admin/export")
    @role_required("admin")
    def export_csv():
        status = request.args.get("status", "")
        q = AccessRequest.query.order_by(AccessRequest.id)
        if status in STATUSES:
            q = q.filter_by(status=status)
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["Request ID", "Requestor", "Email", "Database", "Schema", "Role", "Status", "Created Date"])
        for r in q:
            for i in r.items:
                w.writerow([r.id, csv_safe(r.requestor_name), csv_safe(r.requestor_email), i.database_name, i.schema_name,
                            ACCESS_ROLES.get(i.role_type, i.role_type), r.status,
                            r.created_date.strftime("%Y-%m-%d %H:%M:%S")])
        audit("CSV_EXPORT", "access_request", None, f"status={status or 'all'}")
        return Response("﻿" + buf.getvalue(), mimetype="text/csv", headers={
            "Content-Disposition": "attachment; filename=access_requests.csv"})

    @app.route("/admin/audit")
    @role_required("admin")
    def audit_log():
        page = request.args.get("page", 1, type=int)
        q = AuditLog.query.order_by(AuditLog.id.desc())
        term = request.args.get("q", "").strip()
        if term:
            like = f"%{term}%"
            q = q.filter(or_(AuditLog.actor.ilike(like), AuditLog.action.ilike(like),
                             AuditLog.details.ilike(like)))
        return render_template("audit.html", pagination=q.paginate(page=page, per_page=25, error_out=False), q=term)

    @app.route("/admin/notifications", methods=["GET", "POST"])
    @role_required("admin")
    def notifications():
        """Manage the admin-team mailboxes that receive new-request emails."""
        if request.method == "POST":
            op = request.form.get("op")
            if op == "add":
                raw = re.split(r"[,;\s]+", request.form.get("emails", ""))
                added = 0
                for e in {x.strip().lower() for x in raw if x.strip()}:
                    if not EMAIL_RE.match(e):
                        flash(f"'{e}' is not a valid email.", "danger")
                    elif NotificationEmail.query.filter_by(email=e).first() is None:
                        db.session.add(NotificationEmail(email=e, added_by=g.user.email))
                        added += 1
                audit("NOTIFY_EMAIL_ADDED", "notification_email", None, f"{added} added", commit=False)
                db.session.commit()
                if added:
                    flash(f"Added {added} address(es).", "success")
            elif op == "delete":
                n = db.session.get(NotificationEmail, request.form.get("id", type=int))
                if n:
                    audit("NOTIFY_EMAIL_REMOVED", "notification_email", n.id, n.email, commit=False)
                    db.session.delete(n)
                    db.session.commit()
                    flash("Address removed.", "success")
            return redirect(url_for("notifications"))
        return render_template("notifications.html", emails=NotificationEmail.query.order_by(NotificationEmail.id).all(),
                               effective=email_service.admin_emails(), mail_enabled=app.config["MAIL_ENABLED"])

    @app.route("/admin/users", methods=["GET", "POST"])
    @role_required("admin")
    def users():
        if request.method == "POST":
            name, email = request.form.get("name", "").strip(), request.form.get("email", "").strip().lower()
            pw, role = request.form.get("password", ""), request.form.get("role", "requestor")
            if not name or not EMAIL_RE.match(email) or len(pw) < 8 or role not in ROLES:
                flash("Name, valid email, role and a password of 8+ characters are required.", "danger")
            elif User.query.filter_by(email=email).first():
                flash("A user with that email already exists.", "danger")
            else:
                u = User(name=name, email=email, role=role)
                u.set_password(pw)
                db.session.add(u)
                audit("USER_CREATED", "user", None, f"{email} ({role})", commit=False)
                db.session.commit()
                flash(f"User {email} created.", "success")
            return redirect(url_for("users"))
        return render_template("users.html", users=User.query.order_by(User.id).all(), ROLES=ROLES)

    @app.route("/admin/matrix", methods=["GET", "POST"])
    @role_required("admin")
    def matrix():
        if request.method == "POST":
            f = request.files.get("file")
            if not f or not f.filename.lower().endswith(".csv"):
                flash("Please choose a .csv file.", "danger")
                return redirect(url_for("matrix"))
            try:
                text = f.read(1_000_000).decode("utf-8-sig")
                reader = csv.DictReader(io.StringIO(text))
                reader.fieldnames = [(h or "").strip().lower() for h in (reader.fieldnames or [])]
                if not {"team", "database", "role"} <= set(reader.fieldnames):
                    raise ValueError("CSV must have columns: team, database, role (RO, RW or FULL)")
                rows, bad = [], 0
                for row in reader:
                    t, d, ro = (row["team"].strip(), row["database"].strip().upper(), row["role"].strip().upper())
                    if t and IDENT_RE.match(d) and ro in ACCESS_ROLES:
                        rows.append(AccessMatrix(team_name=t, database_name=d, role_type=ro))
                    else:
                        bad += 1
                if request.form.get("mode") == "replace":
                    AccessMatrix.query.delete()
                db.session.add_all(rows)
                audit("MATRIX_UPLOAD", "access_matrix", None, f"{len(rows)} rows, {bad} skipped", commit=False)
                db.session.commit()
                flash(f"Imported {len(rows)} row(s); {bad} invalid row(s) skipped.", "success" if rows else "warning")
            except (ValueError, UnicodeDecodeError) as e:
                flash(str(e), "danger")
            return redirect(url_for("matrix"))
        rows = AccessMatrix.query.order_by(AccessMatrix.team_name, AccessMatrix.database_name).all()
        return render_template("matrix.html", rows=rows)

    return app


def init_db(app: Flask) -> None:
    """Create tables and seed default accounts and notification mailboxes."""
    with app.app_context():
        db.create_all()
        for name, email, pw, role in (
            ("Portal Admin", Config.DEFAULT_ADMIN_EMAIL, Config.DEFAULT_ADMIN_PASSWORD, "admin"),
            ("Demo Requestor", Config.DEFAULT_USER_EMAIL, Config.DEFAULT_USER_PASSWORD, "requestor"),
        ):
            if not User.query.filter_by(email=email).first():
                u = User(name=name, email=email, role=role)
                u.set_password(pw)
                db.session.add(u)
        if NotificationEmail.query.count() == 0:
            for e in Config.ADMIN_TEAM_EMAILS:
                db.session.add(NotificationEmail(email=e.lower(), added_by="system"))
        db.session.commit()


app = create_app()
init_db(app)

if __name__ == "__main__":
    app.run(host=Config.HOST, port=Config.PORT, debug=Config.DEBUG)
